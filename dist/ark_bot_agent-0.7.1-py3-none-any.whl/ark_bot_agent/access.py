"""存取控制 —— 權限等級 + 執行期增刪 + 持久化（[R7]）。

## 🔴 為什麼這個模組存在（不只是「功能升級」）

0.5.2 之前的 `handlers._ALLOWED_USERS` **只從環境變數讀**：

```python
_admin_env = os.getenv("ADMIN_CHAT_IDS", "")
if _admin_env:
    _ALLOWED_USERS = {...}
# ↑ bot.yaml 的 access.admin_chat_ids 從來沒被讀取
```

註解寫著「bot.yaml 的 access.admin_chat_ids；env 可覆寫」，
**但實作只有 env 那一半**。而 `.env` 沒設 `ADMIN_CHAT_IDS` 時
`_ALLOWED_USERS` 是空集合 → `_is_authorized()` 回 `True`（設計上「空＝不限制」）
→ **設定了白名單卻對所有人開放**。

> 這是「設定宣告了但沒接上」最危險的形狀 ——
> 不是功能沒生效，而是**安全設定沒生效而且看起來生效了**。
> 與 `modes.chat.tools`（工具白名單假限制）同型，但後果更嚴重。

## 靜態 + 動態兩層

| 來源 | 誰維護 | 為什麼分開 |
|------|--------|-----------|
| `bot.yaml` 的 `access` | 人手寫 | 進版控、有註解 |
| `state/access.json` | 執行期增刪 | **不回寫 yaml** —— 那會動到人寫的註解與排版 |

載入時把舊格式（`admin_chat_ids: [int]`）**正規化**成 `{id: level}`，
執行期只看一種形狀 —— 兩種格式並存等於每個讀取點判斷兩次。
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)

ADMIN = "admin"
USER = "user"
LEVELS = (ADMIN, USER)

#: 群組策略。未知值 → warning + 用 `mention_only`（不拋例外）。
GROUP_POLICIES = ("mention_only", "all", "off")
DEFAULT_GROUP_POLICY = "mention_only"
GROUP_CHAT_TYPES = frozenset({"group", "supergroup"})


class AccessControl:
    """白名單 + 等級。**空白名單 = 不限制**（開發模式，維持 0.5.2 的語意）。"""

    def __init__(self, static: dict[int, str] | None = None,
                 state_path: Path | None = None,
                 group_policy: str | None = None) -> None:
        self._group_policy = group_policy
        self._static: dict[int, str] = dict(static or {})
        self._dynamic: dict[int, str] = {}
        self._state_path = state_path
        self._load_dynamic()

    # ── 建構 ────────────────────────────────────────────────

    @classmethod
    def from_config(cls) -> AccessControl:
        """從 `bot.yaml` + 環境變數 + `state/access.json` 組出來。

        env 的 `ADMIN_CHAT_IDS` **疊加**而非取代 —— 取代會讓「設了 env
        就把 yaml 的白名單清空」，那是先前那個 bug 的反向版本。
        """
        from ark_bot_agent.config import get_config
        from ark_bot_agent.paths import get_state_dir

        acc = get_config().access
        static: dict[int, str] = {}

        # 舊格式正規化：admin_chat_ids: [int] → {id: "admin"}
        for uid in getattr(acc, "admin_chat_ids", None) or []:
            try:
                static[int(uid)] = ADMIN
            except (TypeError, ValueError):
                log.warning("access.admin_chat_ids 有非數字項目，已忽略：%r", uid)

        # 新格式（若有）：users: {id: level}
        for uid, level in (getattr(acc, "users", None) or {}).items():
            try:
                static[int(uid)] = level if level in LEVELS else USER
            except (TypeError, ValueError):
                log.warning("access.users 的 key 不是數字，已忽略：%r", uid)

        for raw in os.getenv("ADMIN_CHAT_IDS", "").split(","):
            if (raw := raw.strip()).isdigit():
                static[int(raw)] = ADMIN

        if not static:
            log.warning("⚠️ 白名單為空 —— Bot 對所有人開放（開發模式）。"
                        "要限制請設 bot.yaml 的 access.admin_chat_ids")
        else:
            log.info("🔒 白名單 %d 人（admin %d）", len(static),
                     sum(1 for v in static.values() if v == ADMIN))

        policy = getattr(acc, "group_policy", None)
        if policy and policy != DEFAULT_GROUP_POLICY:
            log.info("🔒 群組策略: %s", policy)
        return cls(static, state_path=get_state_dir() / "access.json",
                   group_policy=policy)

    # ── 查詢 ────────────────────────────────────────────────

    @property
    def _all(self) -> dict[int, str]:
        """靜態為底、動態疊加。"""
        return {**self._static, **self._dynamic}

    def is_empty(self) -> bool:
        return not self._all

    def level_of(self, user_id: int) -> str | None:
        return self._all.get(int(user_id))

    def is_allowed(self, user_id: int) -> bool:
        """空白名單 = 不限制（維持既有語意，不得改變現有部署行為）。"""
        return True if self.is_empty() else int(user_id) in self._all

    def is_admin(self, user_id: int) -> bool:
        """空白名單時**不當成 admin** —— 「不限制使用」不等於「都是管理員」。"""
        return self.level_of(user_id) == ADMIN

    # ── 群組策略（[R1]）────────────────────────────────────

    @property
    def group_policy(self) -> str:
        """有效策略。未知值 **warning + 回預設**，不拋例外（設定錯不該讓 Bot 掛）。"""
        raw = (self._group_policy or DEFAULT_GROUP_POLICY).strip()
        if raw not in GROUP_POLICIES:
            log.warning("access.group_policy 未知值 %r，改用 %r ｜ 可用：%s",
                        raw, DEFAULT_GROUP_POLICY, "、".join(GROUP_POLICIES))
            return DEFAULT_GROUP_POLICY
        return raw

    def should_reply(self, *, chat_type: str | None,
                     text: str = "", bot_username: str | None = None) -> bool:
        """這則訊息要不要回覆。

        **私訊一律回**（`chat_type` 不是群組時直接 True）——
        NFR N2 只保護私訊行為，那是絕大多數部署的實際用法。

        群組時依 `group_policy`：

        | 策略 | 行為 |
        |---|---|
        | `mention_only`（預設） | 只回被 @ 的 |
        | `all` | 每則都回（0.6.0 的行為） |
        | `off` | 完全不回 |
        """
        if (chat_type or "private") not in GROUP_CHAT_TYPES:
            return True

        policy = self.group_policy
        if policy == "all":
            return True
        if policy == "off":
            return False
        return self._is_mentioned(text, bot_username)

    @staticmethod
    def _is_mentioned(text: str, bot_username: str | None) -> bool:
        """訊息有沒有點名 bot。

        ⚠️ **取不到 `bot_username` 時降級為「只看 `@` 開頭」** ——
        那涵蓋 `@碼哥 …` 這種代號直送（本套件的 Path 1）。
        寧可多回一點，也不要在群組裡完全啞掉。降級要 log。
        """
        t = (text or "").lstrip()
        if not bot_username:
            log.debug("取不到 bot username，mention 判斷降級為 @ 前綴")
            return t.startswith("@")
        return f"@{bot_username}".lower() in t.lower() or t.startswith("@")

    # ── 執行期增刪 ──────────────────────────────────────────

    def add(self, user_id: int, level: str = USER) -> bool:
        uid, lv = int(user_id), (level if level in LEVELS else USER)
        if self._all.get(uid) == lv:
            return False
        self._dynamic[uid] = lv
        self._save_dynamic()
        log.info("🔓 白名單新增 %s（%s）", uid, lv)
        return True

    def remove(self, user_id: int) -> bool:
        """只能移除動態加入的。

        靜態的來自 `bot.yaml` —— 執行期「移除」它會讓下次重啟又出現，
        那種假成功比拒絕更糟。
        """
        uid = int(user_id)
        if uid in self._dynamic:
            del self._dynamic[uid]
            self._save_dynamic()
            log.info("🔒 白名單移除 %s", uid)
            return True
        if uid in self._static:
            log.warning("%s 來自 bot.yaml，不能在執行期移除（改設定檔並重啟）", uid)
        return False

    # ── 持久化 ──────────────────────────────────────────────

    def _load_dynamic(self) -> None:
        if not self._state_path or not self._state_path.is_file():
            return
        try:
            raw = json.loads(self._state_path.read_text(encoding="utf-8"))
            self._dynamic = {int(k): (v if v in LEVELS else USER) for k, v in raw.items()}
        except Exception as e:                             # noqa: BLE001
            # 壞掉的狀態檔不該讓 Bot 起不來，但**一定要講** ——
            # 靜默忽略等於白名單被悄悄清空
            log.error("讀 %s 失敗，動態白名單以空的起始：%s", self._state_path, e)

    def _save_dynamic(self) -> None:
        if not self._state_path:
            return
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            self._state_path.write_text(
                json.dumps({str(k): v for k, v in self._dynamic.items()},
                           ensure_ascii=False, indent=2),
                encoding="utf-8")
        except OSError as e:
            log.error("寫 %s 失敗，這次增刪重啟後會消失：%s", self._state_path, e)


_shared: AccessControl | None = None


def get_access() -> AccessControl:
    """共用實例 —— 白名單是全域事實，不該一個呼叫點一份。"""
    global _shared
    if _shared is None:
        _shared = AccessControl.from_config()
    return _shared


def reset_access() -> None:
    """測試用。"""
    global _shared
    _shared = None


__all__ = ["ADMIN", "USER", "LEVELS", "GROUP_POLICIES", "DEFAULT_GROUP_POLICY",
           "AccessControl", "get_access", "reset_access"]
