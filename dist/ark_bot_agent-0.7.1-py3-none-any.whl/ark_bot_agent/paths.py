"""路徑解析的**唯一出口** —— 所有目錄位置都從這裡拿。

## 為什麼所有路徑都得經過這一層

套件安裝後，程式碼在 `site-packages/ark_bot_agent/`，而資料在**消費端專案根**。
兩個常見寫法在這種情況下都會壞，而且**都不會拋例外**：

| 寫法 | 套件化後 | 症狀 |
|------|---------|------|
| `Path(__file__).resolve().parents[2]` | 指到 `site-packages/` | 「wiki 0 篇」「memory 讀不到」 |
| `Path("knowledge")` | 依賴 cwd | 從別的目錄啟動就找不到 |

實測 nana-bot 的 `src/` 有 **24 處** `parents[N]`（N 值還不一致，2 和 3 混用）
與 **37 處** 硬編相對路徑。`N` 值不一致本身就證明那個寫法依賴「檔案在第幾層」，
而套件化必然改變層數。

> MEMORY 記載的同型事故：ninja 全 repo 10 處 `.parent` 鏈、**4 處是錯的**，
> 而且「只修數字」事後證實同型錯誤當時已存在於另外四處。
> **所以不修數字，改用哨兵搜尋。**

## 用法

    from ark_bot_agent.paths import get_home, get_knowledge_dir

    wiki = get_knowledge_dir() / "shared" / "wiki"

**不要**在別的模組自己組 `get_home() / "某個標準目錄"` —— 幫它加一個出口，
這樣改結構時只要動這個檔案。
"""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path

# 哨兵檔：消費端專案根的判斷依據。
# 用 `agents.yaml` 而不是新造一個檔案 —— 它**本來就存在**（agent 定義的唯一來源），
# 消費端不必為了套件化多一份東西。
SENTINEL = "agents.yaml"

# 設定檔分工（**各自單一職責，不合併**）：
#   agents.yaml     agent 定義（誰、代號、工作目錄、可否派工、group_members）← 哨兵
#   bot.yaml        Bot 層設定（server / modes / llm / backend / report / features）
#   scheduler.yaml  排程（選用）
#   .env            **只放機密**（token / api key）
CONFIG_FILES = ("agents.yaml", "bot.yaml", "scheduler.yaml")

# 環境變數覆寫（部署時建議明設，見 plan M5.7 —— systemd 的
# WorkingDirectory 若沒設對，cwd fallback 會安靜地拿到錯的 home）
log = logging.getLogger(__name__)

HOME_ENV = "ARK_BOT_HOME"


@lru_cache(maxsize=1)
def get_home() -> Path:
    """定位消費端專案根。

    順序：
    1. `ARK_BOT_HOME` 環境變數（部署時最可靠）
    2. 從 cwd 往上找 `agents.yaml`（開發時方便）
    3. 退回 cwd（不拋例外 —— 讓 `agents.yaml` 缺失由 config 層去報，
       那裡的錯誤訊息才能講清楚該建什麼檔）

    結果會被快取。測試中若需要切換 home，呼叫 `reset_home_cache()`。
    """
    if env := os.environ.get(HOME_ENV):
        return Path(env).expanduser().resolve()

    cwd = Path.cwd().resolve()
    for p in [cwd, *cwd.parents]:
        if (p / SENTINEL).is_file():
            return p
    return cwd


def reset_home_cache() -> None:
    """清掉 `get_home()` 的快取。**只給測試用**。

    執行期不該切換 home —— 那會讓已開啟的 SQLite 連線與已載入的設定不一致。
    """
    get_home.cache_clear()


def _ensure(p: Path) -> Path:
    """建目錄（含父層）後回傳。讀寫兩用的出口都經過這裡。"""
    p.mkdir(parents=True, exist_ok=True)
    return p


# ── 標準目錄 ────────────────────────────────────────────────


STATE_DIR_ENV = "ARK_BOT_STATE_DIR"


def get_state_dir() -> Path:
    """SQLite 等執行期狀態（sessions.db / chat_trace.db / FTS5 索引）。

    [R3] 解析順序：`ARK_BOT_STATE_DIR`（env）→ `backend.state_dir`（設定）
    → `get_home()/state`（預設，與 0.6.0 同值）。

    env 給部署期（systemd / 容器）用，設定給版控用。

    🔴 **相對路徑一律相對 `get_home()`，不相對 cwd** ——
    相對 cwd 是本套件修掉最多次的 bug 類型（M2 平移時 37 處），
    症狀是「從別的目錄啟動就讀不到，而且不報錯」。

    ⚠️ 指定的路徑建不起來時 **error log + 沿用預設**，不讓 Bot 起不來 ——
    但一定要講，否則部署者不知道資料實際去了哪裡。
    """
    if raw := _state_dir_override():
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = get_home() / candidate          # 相對 home，不是 cwd
        try:
            return _ensure(candidate)
        except OSError as e:
            log.error("state_dir %s 不可用，沿用預設 %s：%s",
                      candidate, get_home() / "state", e)
    return _ensure(get_home() / "state")


def _state_dir_override() -> str:
    """取覆寫值。設定讀不到時當作沒設（不讓設定問題擋住路徑解析）。"""
    if env := os.environ.get(STATE_DIR_ENV):
        return env
    try:
        from ark_bot_agent.config import get_config

        return str(getattr(get_config().backend, "state_dir", "") or "")
    except Exception:                                     # noqa: BLE001
        return ""


def get_data_dir() -> Path:
    """結構化資料（todo.json / skill_stats.json / growth_patterns.json…）。"""
    return _ensure(get_home() / "data")


def get_logs_dir() -> Path:
    """日誌。"""
    return _ensure(get_home() / "logs")


def get_output_dir(sub: str = "") -> Path:
    """一次性產出。`sub` 例：`reports` / `images` / `exports` / `drafts`。

    分類與 TTL 慣例見 steering 的 BRAIN.md（reports/drafts 30 天、
    exports 14 天、skills 7 天）。
    """
    return _ensure(get_home() / "output" / sub if sub else get_home() / "output")


def get_knowledge_dir() -> Path:
    """知識庫根。

    標準結構（Wiki 引擎與統計讀的是 `shared/`，不是扁平的 `wiki/`）：

        knowledge/
        ├── shared/{wiki,raw}/   ← 跨 agent 共用
        ├── wiki/                ← 根層私有
        └── raw/memory-archive/  ← MEMORY.md 歸檔（路徑寫死，不可搬）
    """
    return _ensure(get_home() / "knowledge")


def get_agents_dir() -> Path:
    """各 agent 的工作目錄根（`agents/<name>-agent/`）。"""
    return _ensure(get_home() / "agents")


def get_memory_dir() -> Path:
    """根層工作記憶（`memory.md` / `recent.md` / `daily/`）。"""
    return _ensure(get_home() / "memory")


# ── 檔案層出口 ──────────────────────────────────────────────


def get_steering(name: str = "") -> Path:
    """`.kiro/steering/` 或其下某個檔案。

    Args:
        name: 檔名（如 `SOUL.md`）。留空回目錄本身。

    ⚠️ **不建立目錄** —— steering 檔案是人維護的，缺了要讓呼叫端知道
    （自動建空目錄會讓「讀不到人格」看起來像「檔案是空的」）。
    """
    d = get_home() / ".kiro" / "steering"
    return d / name if name else d


def get_skills_dir() -> Path:
    """`.kiro/skills/` —— IDE skill 定義（`ark-*/SKILL.md`）。

    ⚠️ **不建立目錄**（同 `get_steering()`）—— skills 通常是外部 clone
    （`ark-agent-skills`），自動建空目錄會讓「skill 沒載到」看起來像「一個都沒有」。
    """
    return get_home() / ".kiro" / "skills"


def get_agent_skills_dir(agent_dir: str) -> Path:
    """某個 agent 私有的 `.kiro/skills/`。

    Args:
        agent_dir: `agents.yaml` 的 `dir` 欄位（相對於 home）。
    """
    return get_home() / agent_dir / ".kiro" / "skills"


def get_agent_steering(agent_dir: str, name: str = "") -> Path:
    """某個 agent 的 steering 路徑。

    Args:
        agent_dir: `agents.yaml` 的 `dir` 欄位（如 `agents/admin-agent`），
            **相對於 home**。不要自己拼 `agents/{id}-agent` ——
            id 與目錄名的對應由 `agents.yaml` 決定，不是慣例。
        name: 檔名，留空回目錄。
    """
    d = get_home() / agent_dir / ".kiro" / "steering"
    return d / name if name else d


def get_templates_dir() -> Path:
    """Web UI 模板。**消費端的 `templates/` 優先，否則用套件內建。**

    這樣消費端要客製介面時只要放同名檔案，不必 fork 套件。
    """
    local = get_home() / "templates"
    if local.is_dir():
        return local
    return Path(__file__).resolve().parent / "templates"


def config_status() -> dict[str, bool]:
    """各設定檔是否存在。給 `python -m ark_bot_agent paths` 與啟動自檢用。

    只有 `agents.yaml` 是必要的（它是哨兵）；`bot.yaml` 缺少時全部走預設值，
    `scheduler.yaml` 缺少就是不排程。**缺檔不該讓服務起不來** ——
    但要在啟動訊息裡講清楚哪些用了預設。
    """
    home = get_home()
    return {name: (home / name).is_file() for name in CONFIG_FILES}


def get_config_file(name: str) -> Path:
    """消費端的設定檔（`agents.yaml` / `bot.yaml` / `scheduler.yaml` / `config/*.yaml`）。

    設定檔**各自單一職責，刻意不合併** —— 見 `CONFIG_FILES` 的說明。

    `name` 可含子目錄，如 `config/news_sources.yaml`。
    """
    return get_home() / name


__all__ = [
    "SENTINEL",
    "CONFIG_FILES",
    "HOME_ENV",
    "get_home",
    "reset_home_cache",
    "get_state_dir",
    "get_data_dir",
    "get_logs_dir",
    "get_output_dir",
    "get_knowledge_dir",
    "get_agents_dir",
    "get_memory_dir",
    "get_steering",
    "get_skills_dir",
    "get_agent_skills_dir",
    "get_agent_steering",
    "get_templates_dir",
    "config_status",
    "get_config_file",
]
