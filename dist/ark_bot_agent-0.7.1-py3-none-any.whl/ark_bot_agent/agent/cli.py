"""Agent CLI — Agent 常駐服務（使用 AgentProcess）。

啟動時從 agents.yaml 載入 Agent 定義，建立 AgentProcess 常駐服務。
對話時透過 send() 排隊執行。
"""
from __future__ import annotations

import asyncio
import logging
import time
import os
import shutil
from pathlib import Path

from ark_bot_agent.paths import get_agents_dir, get_home

from ark_bot_agent.agent.errors import classify, describe, is_retryable
from ark_bot_agent.agent.process import AgentProcess
from ark_bot_agent.agent.result import CliResult

log = logging.getLogger("agent-cli")

# ── 從 agents.yaml 載入 Agent 定義 ──



def _load_agents_config() -> dict:
    """Agent 定義 —— **實作在 `config.load_agents()`**，這裡只轉成舊的 dict 格式。

    原本自己讀一次 `agents.yaml`，與 `config.py` 是**重複邏輯**（兩處各自解析
    同一個檔案必然漂移）。現在單一來源是 config，這裡只做格式轉接，
    讓既有的 `AVAILABLE_AGENTS["coder"]["codename"]` 寫法繼續可用。
    """
    from ark_bot_agent.config import get_config

    out: dict[str, dict] = {}
    for aid, a in get_config().agents.items():
        out[aid] = {
            "dir": a.dir, "name": a.name, "codename": a.codename, "emoji": a.emoji,
            "desc": a.desc, "dispatchable": a.dispatchable, "persistent": a.persistent,
            "skip_resume": a.skip_resume, "role": a.role,
            "group_members": a.group_members,
        }
    return out


def _get_available_agents() -> dict:
    """取得 AVAILABLE_AGENTS dict（快取）。"""
    global _agents_cache
    if _agents_cache is not None:
        return _agents_cache
    _agents_cache = _load_agents_config()
    return _agents_cache


_agents_cache: dict | None = None

# 向後相容：模組層級 AVAILABLE_AGENTS（lazy property 不可能，用函式 + 延遲載入）
# 其他模組 import AVAILABLE_AGENTS 時會拿到這個 dict
AVAILABLE_AGENTS = _load_agents_config()


def get_dispatchable_agents() -> list[str]:
    """取得可被 dispatch_to_agent 派工的 agent ID 列表。"""
    agents = _get_available_agents()
    return [
        f"{aid}-agent" for aid, info in agents.items()
        if info.get("dispatchable", False)
    ]


def get_group_members(leader_id: str | None = None) -> list[str]:
    """⚔️ 團隊模式下該 leader 可派工的成員短名。

    **實作在 `config.BotConfig.group_members()`** —— 這裡只是薄封裝，
    保留既有呼叫端的 API。清單類邏輯只能有一個來源，
    兩處各自實作必然漂移（`TEAM.md` 凍結就是那樣來的）。
    """
    from ark_bot_agent.config import get_config

    return get_config().group_members(leader_id)


def describe_agents(agent_ids: list[str]) -> str:
    """把 agent id 列表組成給 prompt 用的多行說明。

    **實作在 `config.BotConfig.describe()`**（同上，薄封裝）。
    """
    from ark_bot_agent.config import get_config

    return get_config().describe(agent_ids)


# ── Agent 服務管理 ──

_agents: dict[str, AgentProcess] = {}
_started: bool = False


def is_cli_available() -> bool:
    """檢查指定的 CLI backend 是否已安裝。"""
    backend = get_available_backend()
    cmd = _resolve_cmd(backend)
    return cmd is not None


def get_available_backend() -> str:
    """從 CLI_BACKEND 環境變數取得 backend，未設定則自動偵測。"""
    from ark_bot_agent.config import get_config

    # bot.yaml 的 backend.cli（`auto` 表示自動偵測）；env 可臨時覆寫
    cfg_val = get_config().backend.cli
    env_val = (os.getenv("CLI_BACKEND") or ("" if cfg_val == "auto" else cfg_val)).strip().lower()
    if env_val in ("kiro", "agy", "claude"):
        return env_val
    # 自動偵測
    if _resolve_cmd("kiro"):
        return "kiro"
    if _resolve_cmd("agy"):
        return "agy"
    if _resolve_cmd("claude"):
        return "claude"
    return "kiro"


def _resolve_cmd(backend: str) -> str | None:
    """解析 backend 對應的可執行檔完整路徑，找不到回傳 None。"""
    cmd_map = {"kiro": "kiro-cli", "agy": "agy", "claude": "claude"}
    cmd = cmd_map.get(backend, backend)
    # 先查 PATH
    found = shutil.which(cmd)
    if found:
        return found
    # Fallback: 已知安裝路徑（不自動加 PATH 的工具）
    fallback_paths = {
        "agy": os.path.join(os.environ.get("LOCALAPPDATA", ""), "agy", "bin", "agy.exe"),
    }
    fallback = fallback_paths.get(backend)
    if fallback and os.path.isfile(fallback):
        return fallback
    return None


async def start_all_agents() -> int:
    """啟動 8 個 Agent 常駐服務。回傳成功數量。"""
    global _started
    if _started:
        return len(_agents)
    if not is_cli_available():
        log.info("未偵測到任何 CLI backend（kiro-cli / agy / claude），跳過 Agent 服務啟動")
        return 0

    backend = get_available_backend()
    from ark_bot_agent.config import get_config

    _bk = get_config().backend
    cli_model = os.getenv("CLI_MODEL") or _bk.model
    log.info("使用 CLI backend: %s, model: %s", backend, cli_model)

    count = 0
    for agent_id, info in AVAILABLE_AGENTS.items():
        # Default (Ark Agent) 走 Gemini agent_loop，不需要 CLI 進程
        if agent_id == "default":
            continue
        name = f"{agent_id}-agent"
        working_dir = info["dir"]
        # 讀取 persistent / skip_resume 設定（預設 Workers 每次 fresh start）
        skip_resume = info.get("skip_resume", True)
        persistent = info.get("persistent", False)
        proc = AgentProcess(
            name=name,
            working_dir=working_dir,
            model=cli_model,
            skip_resume=skip_resume,
            backend=backend,
            # [R3] 三個池參數由 bot.yaml 驅動，不寫死
            max_queue=_bk.max_queue,
            idle_timeout=_bk.idle_timeout,
            crash_window=_bk.crash_window,
        )
        # 常駐 Agent 給更長 timeout（不容易超時）；per-agent 設定可覆蓋
        proc.timeout = _resolve_timeout(agent_id, None) if info.get("timeout") else (
            600 if persistent else 180
        )
        # [M2/R3] persistent 的 agent 不受 idle 回收（沿用 ark_team_agent 已驗證的語意）
        _persistent[agent_id] = persistent
        await proc.start()
        _agents[agent_id] = proc
        count += 1
        if persistent:
            log.info("  ⭐ %s: persistent=true, skip_resume=false", name)

    _started = True
    _start_health_loop()
    log.info("All %d agents registered", count)
    return count


# ── [M2/R3] health loop：崩潰偵測 + idle 回收 ──────────────

_persistent: dict[str, bool] = {}
_health_task: asyncio.Task | None = None
HEALTH_INTERVAL = 60


def _start_health_loop() -> None:
    """啟動 health loop（重複呼叫只會有一個）。"""
    global _health_task
    if _health_task and not _health_task.done():
        return
    try:
        _health_task = asyncio.create_task(_health_loop())
    except RuntimeError:                                  # 沒有 event loop（測試環境）
        log.debug("無 event loop，跳過 health loop")


async def _health_loop(interval: int = HEALTH_INTERVAL) -> None:
    """週期檢查：死亡記 crash、閒置過久回收。

    🔴 **回收 ≠ 永久消失** —— 移出 `_agents` 後，下次 `agent_cli_chat()`
    走 fallback subprocess 路徑仍然能服務，而 `start_instance` 也叫得回來。
    slot 踩過的坑是 `auto_start: false` 讓進程**連 lazy spawn 都叫不起來**，
    本迴圈不得重現那個形狀。
    """
    while _started:
        try:
            await asyncio.sleep(interval)
            for agent_id, proc in list(_agents.items()):
                if not proc.is_alive():
                    proc._record_crash()
                    continue
                if _persistent.get(agent_id):
                    continue                              # persistent 不因閒置被回收
                idle = proc.idle_seconds
                if proc.idle_timeout and idle > proc.idle_timeout:
                    log.info("♻️  回收 %s（閒置 %.0fs > %ds）",
                             agent_id, idle, proc.idle_timeout)
                    await proc.kill()
                    _agents.pop(agent_id, None)
        except asyncio.CancelledError:
            raise
        except Exception as e:                            # noqa: BLE001
            log.error("health loop 異常（繼續執行）：%s", e)


def pool_status() -> dict:
    """給 `/api` 與啟動橫幅用的池狀態。"""
    return {
        "total": len(_agents),
        "alive": sum(1 for p in _agents.values() if p.is_alive()),
        "persistent": sum(1 for k in _agents if _persistent.get(k)),
        "crashes": {k: p.crash_count for k, p in _agents.items() if p.crash_count},
        "idle": {k: round(p.idle_seconds) for k, p in _agents.items()},
    }


_DEFAULT_TIMEOUT = 120
_RETRY_DELAY = 2.0


def _resolve_retries(explicit: int | None) -> int:
    """重試次數：呼叫端指定 → `bot.yaml` 的 `backend.retries` → 0（不重試）。

    預設 0 是刻意的 —— 0.4.3 沒有重試，**開新行為要由設定明示**，
    不能因為升版就默默多花時間。
    """
    if explicit is not None:
        return max(0, explicit)
    try:
        from ark_bot_agent.config import get_config

        return max(0, int(getattr(get_config().backend, "retries", 0)))
    except Exception:                                     # noqa: BLE001
        return 0


async def stop_all_agents() -> None:
    """停止所有 Agent。"""
    global _started, _health_task
    _started = False                                      # 先停迴圈條件再收 task
    if _health_task and not _health_task.done():
        _health_task.cancel()
    _health_task = None
    for proc in _agents.values():
        await proc.kill()
    _agents.clear()
    _persistent.clear()


def _resolve_timeout(agent_id: str, explicit: int | None) -> int:
    """逾時解析順序：呼叫端指定 → per-agent → 全域預設。

    [R4] per-agent 是必要的 —— 實測三人派工 `data` 37s / `report` 50s /
    **`ai-dev` 123s**，全體共用一個值必然有一邊不對。
    **未設定時要與 0.4.3 完全同值**（120s），不得改變既有部署的行為。
    """
    if explicit is not None:
        return explicit
    try:
        from ark_bot_agent.config import get_config

        cfg = get_config()
        if (a := cfg.agent(agent_id)) and getattr(a, "timeout", None):
            return int(a.timeout)
        return int(getattr(cfg.backend, "timeout", _DEFAULT_TIMEOUT))
    except Exception:                                     # noqa: BLE001
        return _DEFAULT_TIMEOUT


async def agent_cli_chat(
    message: str,
    *,
    agent_id: str = "admin",
    timeout: int | None = None,
    session=None,
    retries: int | None = None,
    fresh: bool = False,
) -> CliResult:
    """透過 AgentProcess 執行對話，回 `CliResult`。

    常駐服務已啟動 → 用 `send()`（排隊執行）；沒啟動 → fallback 直接 subprocess。

    🔴 **0.5.0 起回 `CliResult` 而不是 `str | None`** ——
    舊型別讓呼叫端分不出「空回覆／崩潰／逾時／CLI 沒安裝」，
    而失敗是用回傳值表示的，`try/except` 抓不到。
    舊呼叫端改成 `.reply_text()` 即語意等價。

    重試只對 `retryable` 的分類做 —— `not_found`（CLI 沒安裝）與 `permission`
    重試一百次也不會好，那是設定問題不是暫時故障。

    [R5] `fresh=True` —— **不帶對話歷史的一次性呼叫**。

    `skip_resume: false` 的 agent（如 leader）每次都跑 `kiro-cli chat --resume`，
    把**整段累積歷史**重播一次。規劃這種階段的 prompt 是自足的
    （任務 + 成員清單），歷史只是成本。

    💡 而且**不會多付冷啟成本** —— `AgentProcess._execute()` 本來就是
    每則訊息 spawn 一個新 process，所謂「常駐」是佇列與設定，不是長駐 REPL。
    """
    t = _resolve_timeout(agent_id, timeout)
    n = _resolve_retries(retries)
    last: CliResult | None = None

    for attempt in range(1, n + 2):                       # n 次重試 = n+1 次嘗試
        last = await _cli_attempt(message, agent_id=agent_id, timeout=t,
                                  session=session, fresh=fresh)
        if last.is_ok() or not last.retryable:
            break
        if attempt <= n:
            # 🔴 重試一定要留 log —— 靜默重試會讓「慢」看起來像「當」
            log.warning("agent_cli_chat 第 %d/%d 次重試 %s：%s",
                        attempt, n, agent_id, last.error)
            await asyncio.sleep(_RETRY_DELAY * attempt)   # 線性退避
    return last                                          # type: ignore[return-value]


async def _cli_attempt(
    message: str, *, agent_id: str, timeout: int, session=None, fresh: bool = False
) -> CliResult:
    """單次嘗試（不重試）。**所有失敗路徑都回 `CliResult`，不回 `None`。**

    `fresh=True` 走 one-shot 路徑（該路徑本來就不帶 `--resume`）。
    """
    started = time.monotonic()
    backend = get_available_backend()

    def _elapsed() -> int:
        return int((time.monotonic() - started) * 1000)

    # 注入 SOUL + Context（僅 agy/claude 需要；kiro-cli 自動讀 .kiro/steering）
    injected = message if backend == "kiro" else _inject_context(message, agent_id, session)

    # 優先用常駐服務（`fresh` 刻意跳過 —— 常駐進程帶 `--resume`）
    proc = None if fresh else _agents.get(agent_id)
    if proc and proc.is_alive():
        got = await proc.send(injected)
        # [M2] `proc.send()` 之後也會回 CliResult；同時相容兩種形狀，
        #      避免 M1/M2 之間的中間狀態爆掉。
        if isinstance(got, CliResult):
            got.elapsed_ms = got.elapsed_ms or _elapsed()
            got.backend = got.backend or backend
            return got
        return (CliResult.ok(got, elapsed_ms=_elapsed(), backend=backend) if got
                else CliResult.fail("常駐進程無回覆", retryable=True,
                                    elapsed_ms=_elapsed(), backend=backend))

    # Fallback: 直接 subprocess（相容舊行為）
    if not is_cli_available():
        kind = "not_found"
        return CliResult.fail(describe(kind, "kiro/claude/agy 都不可用"),
                              retryable=is_retryable(kind), elapsed_ms=_elapsed())

    info = AVAILABLE_AGENTS.get(agent_id, AVAILABLE_AGENTS["admin"])
    # `dir` 是相對 home 的路徑 —— 直接 Path() 會變成相對 cwd，
    # 從別的目錄啟動就找不到 agent 工作區（而且不報錯）。
    working_dir = get_home() / info["dir"]
    if not (working_dir / ".kiro" / "steering" / "SOUL.md").exists():
        working_dir = get_home()

    if backend == "agy":
        cmd = ["agy", "-p", injected, "--dangerously-skip-permissions",
               "--add-dir", str(working_dir.resolve())]
    elif backend == "claude":
        cmd = ["claude", "-p", injected]
    else:
        cmd = ["kiro-cli", "chat", "--no-interactive", "--trust-all-tools", injected]

    proc_sub = None
    try:
        proc_sub = await asyncio.create_subprocess_exec(
            *cmd, cwd=str(working_dir),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc_sub.communicate(), timeout=timeout)
    except Exception as e:                                # noqa: BLE001
        if proc_sub is not None and proc_sub.returncode is None:
            proc_sub.kill()                               # 逾時要收屍，否則子進程留著
        kind = classify(exc=e)
        detail = type(e).__name__ + (f" {timeout}s" if kind == "timeout" else "")
        log.warning("agent_cli_chat %s：%s", agent_id, describe(kind, detail))
        return CliResult.fail(describe(kind, detail), retryable=is_retryable(kind),
                              elapsed_ms=_elapsed(), backend=backend)

    output = _clean_stdout(stdout)
    if proc_sub.returncode != 0:
        kind = classify(returncode=proc_sub.returncode)
        detail = f"rc={proc_sub.returncode}"
        if err := stderr.decode("utf-8", "replace").strip():
            detail += f" {err[:120]}"
        log.warning("agent_cli_chat %s：%s", agent_id, describe(kind, detail))
        # 有部分輸出就降為 partial，不丟掉 —— 部分結果比沒結果好
        return CliResult.fail(describe(kind, detail), retryable=is_retryable(kind),
                              output=output, elapsed_ms=_elapsed(), backend=backend)

    return CliResult.ok(output, elapsed_ms=_elapsed(), backend=backend)


def _clean_stdout(raw: bytes) -> str:
    """去 ANSI + 去空行。"""
    import re

    text = re.sub(r"\x1b\[[0-9;]*m", "", raw.decode("utf-8", "replace").strip())
    return "\n".join(line for line in text.split("\n") if line.strip())


def _inject_context(message: str, agent_id: str, session=None) -> str:
    """注入 SOUL + MEMORY + 對話脈絡到 prompt。

    結構：
      1. SOUL.md 內容（人格注入）
      2. MEMORY.md 內容（專案狀態 + 踩坑紀錄）
      3. 最近 4 輪對話（Context 鏈）
      4. 當前使用者訊息
    """
    parts: list[str] = []

    # 1. SOUL
    # ⚠️ 這裡用 id 拼目錄名（`{id}-agent`）是既有寫法。正解是讀 agents.yaml 的
    #    `dir` 欄位（改名時才不會壞）—— 列入 M3 的設定層一併處理。
    steering_dir = get_agents_dir() / f"{agent_id}-agent" / ".kiro" / "steering"
    soul_path = steering_dir / "SOUL.md"
    if soul_path.exists():
        parts.append(soul_path.read_text(encoding="utf-8"))

    # 2. MEMORY（專案狀態，≤ 1500 chars）
    memory_path = steering_dir / "MEMORY.md"
    if memory_path.exists():
        content = memory_path.read_text(encoding="utf-8")
        # 移除 frontmatter
        if content.startswith("---"):
            _, _, content = content.split("---", 2)
        content = content.strip()
        if content and len(content) > 20:
            parts.append(content[:1500])

    # 3. 最近對話（限 4 輪 = 2 來回）
    if session and hasattr(session, "history") and session.history:
        recent = session.history[-4:]
        if recent:
            context_lines = ["## 對話脈絡"]
            for turn in recent:
                prefix = "User" if turn.role == "user" else "Agent"
                context_lines.append(f"{prefix}: {turn.content[:200]}")
            parts.append("\n".join(context_lines))

    # 4. 當前問題
    parts.append(f"## 當前問題\n{message}")

    return "\n\n---\n\n".join(parts)
