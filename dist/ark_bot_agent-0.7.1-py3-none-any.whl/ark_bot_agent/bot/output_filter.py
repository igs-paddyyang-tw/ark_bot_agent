"""三層輸出過濾管線 — 移植自 ark_team_agent。

Layer 1: clean_output(raw)   → 移除 ANSI/XML/工具噪音
Layer 2: extract_final_reply(cleaned) → 精確提取 `> ` 回覆 or fallback
Layer 3: (由 handlers.py 的 _format_telegram 處理)

Usage:
    from .output_filter import clean_output, extract_final_reply
    final = extract_final_reply(clean_output(raw_stdout))
"""

from __future__ import annotations

import re

# ── ANSI / 控制字元清理 ──────────────────────────────────────

_ANSI_CSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
_ANSI_OSC_RE = re.compile(r"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")
_ANSI_OTHER_RE = re.compile(r"\x1b[^[\]A-Za-z]?[A-Za-z]?")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


# ── Shell stdout 黑名單 ──────────────────────────────────────

_SHELL_LINE_PATTERNS = [
    # git
    re.compile(r"^\s*\d+ files? changed"),
    re.compile(r"^\s*create mode \d+ "),
    re.compile(r"^\s*delete mode \d+ "),
    re.compile(r"^\s*rename \S+ => \S+"),
    re.compile(r"^\s*\d+ insertions?\(\+\)"),
    re.compile(r"^\s*\d+ deletions?\(-\)"),
    re.compile(r"^To https?://.+\.git$"),
    re.compile(r"^Updating [0-9a-f]{7,}\.\.[0-9a-f]{7,}$"),
    re.compile(r"^Fast-forward$"),
    re.compile(r"^Initialized empty Git repository"),
    re.compile(r"^Cloning into '.+'\.{3}$"),
    re.compile(r"^From https?://\S+$"),
    re.compile(r"^\s*\*\s+\[new branch\]\s"),
    re.compile(r"^\s*\*\s+\[new tag\]\s"),
    re.compile(r"^[AMD]\s{2,}\S+"),
    re.compile(r"^remote: "),
    re.compile(r"^Branch '.+' set up to track"),
    re.compile(r"^Switched to (a new )?branch "),
    re.compile(r"^\s+\S+\s+\|\s+\d+\s+[+-]+\s*$"),
    re.compile(r"^Counting objects: "),
    re.compile(r"^Compressing objects: "),
    re.compile(r"^Writing objects: "),
    re.compile(r"^Resolving deltas: "),
    re.compile(r"^Enumerating objects: "),
    re.compile(r"^Total \d+ \(delta \d+\)"),
    # npm / yarn
    re.compile(r"^\s*added \d+ packages"),
    re.compile(r"^\s*removed \d+ packages"),
    re.compile(r"^\s*changed \d+ packages"),
    # docker
    re.compile(r"^Successfully built [0-9a-f]{12}"),
    re.compile(r"^Successfully tagged "),
    # Kiro CLI tool timer
    re.compile(r"^\s*-\s*Completed in [\d.]+s$"),
    re.compile(r"^\s*▸\s+Time: "),
]


# ── 截斷設定 ─────────────────────────────────────────────────

_MAX_REPLY_CHARS = 3500
_TRUNCATE_HINT = "\n\n📎 原文過長已截斷"


# ── Layer 1: clean_output ────────────────────────────────────

def clean_output(raw: str) -> str:
    """擷取 agent 有意義的回覆，過濾工具呼叫與執行雜訊。

    移植自 ark_team_agent.telegram.TelegramAdapter._clean_output，
    完整覆蓋 XML block、spinner、Kiro CLI 工具 UI、Shell/Docker/pytest 噪音。
    """
    # 去除 ANSI escape codes
    text = _ANSI_CSI_RE.sub("", raw)
    text = _ANSI_OSC_RE.sub("", text)
    text = _ANSI_OTHER_RE.sub("", text)
    text = _CONTROL_RE.sub("", text)

    lines = text.splitlines()
    result: list[str] = []
    skip = False

    for line in lines:
        stripped = line.strip()

        if not stripped:
            if result and result[-1] != "":
                result.append("")
            continue

        # 裝飾線
        if all(c in "─━═│┌┐└┘├┤┬┴┼╭╮╰╯▀▄█░▒▓● " for c in stripped):
            continue

        # XML tool_use / function_calls 區塊
        if stripped in (
            "<function_calls>", "</function_calls>",
            "<function_results>", "</function_results>",
        ):
            skip = True
            continue
        if stripped.startswith("<invoke") or stripped.startswith("<parameter") or stripped.startswith("</"):
            skip = True
            continue
        if re.match(r"^(Tool Use|Tool Result)\b", stripped):
            skip = True
            continue
        if stripped.startswith("tool_use") or stripped.startswith("tool_result"):
            skip = True
            continue

        # Spinner 字元（⠧ Thinking...）
        if stripped and stripped[0] in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏⣾⣽⣻⢿⡿⣟⣯⣷":
            continue

        # Kiro CLI 工具呼叫 UI
        if re.match(r"^Running tool\s+\w+", stripped, re.I):
            continue
        if re.match(r"^[â®⋮]\s*[\{\"]", stripped) or stripped in ("⋮ {}", "â® {}", "⋮  }", "â®  }"):
            continue
        if re.match(r"^[â®⋮]\s+\"(text|instance|message|task)\"\s*:", stripped):
            continue

        # MCP tool call JSON block
        if re.match(r"^[⋮â®]\s*\{", stripped):
            skip = True
            continue
        if skip and re.match(r"^[⋮â®]\s*\}", stripped):
            skip = False
            continue
        if skip and re.match(r"^[⋮â®]\s", stripped):
            continue

        # Kiro 工具執行失敗訊息
        if re.match(r"^● Execution failed after", stripped):
            continue
        if re.match(r"^no occurrences of", stripped, re.I):
            continue
        if re.match(r"^❗\s*(No files found|File not found|Path not found)", stripped, re.I):
            continue

        # Thinking / spinner 動畫文字
        clean_stripped = re.sub(r"^[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏⣾⣽⣻⢿⡿⣟⣯⣷\s]+", "", stripped).rstrip(">").strip()
        if re.match(r"^\.{1,3}$", clean_stripped) or re.match(
            r"^\.*(T(h(i(n(k(i(n(g\.*)?)?)?)?)?)?)?)\.{0,3}$", clean_stripped, re.I
        ):
            continue

        # 工具呼叫區塊
        if re.match(
            r"^(Tool Use|Tool Result|Running|Executing|Reading|Writing|Searching|Created|Modified)\b",
            stripped,
        ):
            skip = True
            continue

        # 工具執行摘要
        if re.match(r"^[•·\-\*]?\s*Summary:\s*\d+", stripped, re.I):
            continue
        if re.match(r"^\d+\s+(operations?|files?|items?)\s+(processed|successful|failed)", stripped, re.I):
            continue

        # pytest / 測試框架
        if re.match(r"^(FAILED|PASSED|ERROR|SKIPPED)\s+.*::", stripped):
            continue
        if re.match(r"^(TimeoutError|AssertionError|RuntimeError|ValueError|KeyError|TypeError):", stripped):
            continue
        if re.match(r"^=+\s*(FAILURES|ERRORS|WARNINGS|short test summary|passed|failed|error)", stripped, re.I):
            continue
        if re.match(r"^=+$", stripped):
            continue
        if re.match(r"^\d+\s+(failed|passed|error|warning)", stripped, re.I):
            continue
        if re.match(r"^[\.FEsxX]+\s*\[\s*\d+%\]", stripped):
            continue

        # Shell 指令行
        if re.match(r"^cd\s+\S+\s*&&", stripped):
            continue
        if re.match(r"^(git|go|npm|pip|docker|kubectl|helm)\s+(push|pull|build|run|deploy|install)", stripped):
            continue

        # git status / diff stat
        if re.match(r"^[MADRCU\?!]{1,2}\s+\S+\.\w+$", stripped):
            continue
        if re.match(r"^\S+\s*\|\s*\d+\s*[\+\-]+", stripped):
            continue
        if re.match(r"^(fatal|error|remote):\s+", stripped, re.I):
            continue
        if re.match(r"^hint:\s+", stripped, re.I):
            continue

        # Docker build
        if re.match(r"^#\d+\s+\[", stripped):
            continue
        if re.match(r"^#\d+\s+(transferring|load|DONE|CACHED|ERROR)", stripped, re.I):
            continue

        # Kiro CLI 啟動訊息
        if re.match(
            r"^(KIRO|Welcome|Prefer the classic|Warning:|In this mode|"
            r"This mode is|By proceeding|trust all tools|Yes, I accept|"
            r"No, exit|Credits:|ask a question)",
            stripped, re.I,
        ):
            continue

        # Purpose marker
        if re.match(r"^Purpose:\s+", stripped):
            continue

        # Time / tool completion
        if re.match(r"^[▸▹►]?\s*Time:", stripped):
            continue
        if stripped.startswith(("✓", "✔", "☑")):
            continue
        if re.match(r"^[•·\-\*]\s*Completed", stripped):
            continue
        if "Completed in " in stripped:
            continue

        # 單字元噪音
        if stripped in ("⋮", "…", "·", "•", "‥"):
            continue

        # File listing
        if re.match(r"^(Mode|----)\s+(LastWriteTime|-----)", stripped):
            continue
        if re.match(r"^[d-]{6}\s+\d{4}/\d{1,2}/\d{1,2}", stripped):
            continue

        # PowerShell 錯誤
        if re.match(r"^At line:\d+", stripped):
            continue
        if re.match(r"^\s+\+\s+CategoryInfo\s*:", stripped):
            continue
        if re.match(r"^\s+\+\s+FullyQualifiedErrorId\s*:", stripped):
            continue

        # 偵測到正常文字，停止跳過
        if skip and not re.match(r"^[\s│├└┌\d]+$", stripped):
            skip = False

        if not skip:
            # 保留 `> ` 前綴原文（Layer 2 需要它做精確提取）
            if line.strip().startswith("> ") or line.startswith("> "):
                result.append(line.rstrip())
            else:
                result.append(stripped)

    # 清理首尾空行
    while result and result[0] == "":
        result.pop(0)
    while result and result[-1] == "":
        result.pop()

    return "\n".join(result)


# ── Layer 2: extract_final_reply ─────────────────────────────

def extract_final_reply(cleaned: str) -> str:
    """從 cleaned 輸出中擷取 agent 的最終回覆。

    策略：
    1. 有 [DONE] summary= → 直接用
    2. 有 reply() 工具呼叫 → 提取最後一個 reply 內容
    3. 有 `> ` 前綴 → 只取最後一段 `> ` 區塊
    4. 無 `> ` 前綴 → fallback 用 _drop_shell_output 再過濾
    5. 套用硬截斷
    """
    if not cleaned.strip():
        return ""

    # 策略 1: [DONE] 標記
    done_match = re.search(r"\[DONE\]\s*summary=(.+)", cleaned)
    if done_match:
        return done_match.group(1).strip()

    # 策略 2: reply() 工具呼叫
    reply_matches = re.findall(
        r'reply\s*\(\s*(?:text\s*=\s*)?["\'](.+?)["\']',
        cleaned, re.DOTALL,
    )
    if reply_matches:
        return reply_matches[-1].strip()

    lines = cleaned.splitlines()

    # 策略 3: `> ` agent 回覆前綴
    reply_indices = [i for i, line in enumerate(lines) if line.startswith("> ")]

    if reply_indices:
        # 從最後一個 `> ` 行往回找連續 `> ` 段落的開頭
        last_idx = reply_indices[-1]
        start = last_idx
        for i in range(len(reply_indices) - 2, -1, -1):
            # 連續（允許中間有空行）
            if reply_indices[i] >= start - 2:
                start = reply_indices[i]
            else:
                break

        collected: list[str] = []
        for ln in lines[start:]:
            if re.match(r"^\s*▸\s+Time:", ln):
                break
            if re.match(r"^\s*-\s*Completed in ", ln):
                break
            # 遇到非 `> ` 行且不是空行，停止
            if not ln.startswith("> ") and ln.strip() and collected:
                break
            collected.append(ln)
        # Strip `> ` prefix
        stripped_collected = []
        for ln in collected:
            if ln.startswith("> "):
                stripped_collected.append(ln[2:])
            else:
                stripped_collected.append(ln)
        while stripped_collected and not stripped_collected[-1].strip():
            stripped_collected.pop()
        result = "\n".join(stripped_collected)
    else:
        # 策略 4: fallback
        fallback = _drop_shell_output(cleaned)
        if not fallback.strip():
            return ""
        result = fallback

    # 硬截斷保險絲
    if len(result) > _MAX_REPLY_CHARS:
        cap = _MAX_REPLY_CHARS - len(_TRUNCATE_HINT)
        result = result[:cap].rstrip() + _TRUNCATE_HINT

    return result


# ── Helpers ──────────────────────────────────────────────────

def _drop_shell_output(text: str) -> str:
    """Drop lines matching known shell-stdout patterns. Best-effort fallback."""
    kept: list[str] = []
    for line in text.splitlines():
        if any(p.match(line) for p in _SHELL_LINE_PATTERNS):
            continue
        kept.append(line)
    # Remove duplicate blank lines
    result: list[str] = []
    for line in kept:
        if not line.strip() and result and not result[-1].strip():
            continue
        result.append(line)
    while result and not result[0].strip():
        result.pop(0)
    while result and not result[-1].strip():
        result.pop()
    return "\n".join(result)
