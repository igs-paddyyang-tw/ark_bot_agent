"""FastAPI — AI Agent 專家平台 API + Web UI。"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from ark_bot_agent.paths import get_agents_dir, get_knowledge_dir, get_templates_dir

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from ark_bot_agent.skills.registry import get_registry
from ark_bot_agent.wiki.engine import WikiEngine

log = logging.getLogger(__name__)

# 消費端的 templates/ 優先，否則用套件內建 —— 客製 UI 不必 fork 套件。
TEMPLATES_DIR = get_templates_dir()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """啟動所有服務，shutdown 時優雅關閉。"""
    # 共用 registry —— 消費端 `create_bot(skills=[...])` 注入的套件也在裡面。
    registry = get_registry()
    log.info("📦 Skills loaded: %s（來源：%s）",
             len(registry.list_skills()), "、".join(registry.packages()))

    # Wiki Engine
    wiki_engine = WikiEngine()
    app.state.wiki_engine = wiki_engine
    app.state.registry = registry

    # Agent 常駐服務（8 個 kiro-cli 子進程）
    from ark_bot_agent.agent.cli import is_cli_available, start_all_agents, stop_all_agents
    agent_count = 0
    if is_cli_available():
        agent_count = await start_all_agents()
        log.info("🧠 Agent 常駐服務: %d 個已啟動", agent_count)
    else:
        log.info("🧠 Agent 常駐服務: 跳過（CLI 不可用）")

    # Telegram Bot — 由 lifespan 統一管理 polling
    bot_app = None
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if token:
        from ark_bot_agent.bot.main import create_app, _post_init
        bot_app = create_app()
        await bot_app.initialize()
        await _post_init(bot_app)
        await bot_app.start()
        await bot_app.updater.start_polling(drop_pending_updates=False)
        log.info("🤖 Telegram Bot started polling")
    else:
        log.warning("⚠️ TELEGRAM_BOT_TOKEN 未設定，Bot 不啟動")

    yield

    # Shutdown
    if agent_count > 0:
        await stop_all_agents()
        log.info("🧠 Agent 服務已停止")
    if bot_app:
        await bot_app.updater.stop()
        await bot_app.stop()
        await bot_app.shutdown()


app = FastAPI(title="AI Agent 專家平台 API", lifespan=lifespan)
engine = WikiEngine()

# ── Memory API Router ──
from ark_bot_agent.memory.api import router as memory_router
app.include_router(memory_router)

# ── A2A Router（由 bot.yaml 的 features.a2a 決定）──
# [M3] 原本看 `_TEAM_MODE` 環境變數（由 start.py 依 team.yaml 存在與否設定）。
# 改為明確的功能開關 —— 「有沒有 team.yaml」與「要不要開 A2A」是兩件事。
from ark_bot_agent.config import get_config as _get_config
if _get_config().features.a2a:
    from ark_bot_agent.coordinator.a2a.server import router as a2a_router
    app.include_router(a2a_router)


# ─── Web UI ──────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
def chat_page():
    """聊天室首頁。"""
    html = (TEMPLATES_DIR / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    """管理介面。"""
    html = (TEMPLATES_DIR / "admin.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


@app.get("/wiki", response_class=HTMLResponse)
def wiki_page():
    """Wiki 瀏覽器。"""
    html = (TEMPLATES_DIR / "wiki.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


@app.get("/builder", response_class=HTMLResponse)
def builder_page():
    """Agent Builder。"""
    html = (TEMPLATES_DIR / "builder.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


@app.get("/graph", response_class=HTMLResponse)
def graph_page():
    """Wiki 知識圖譜。"""
    html = (TEMPLATES_DIR / "graph.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


@app.get("/api-docs", response_class=HTMLResponse)
def api_docs_page():
    """API 文件（自訂風格）。"""
    html = (TEMPLATES_DIR / "api-docs.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


# ─── Chat Trace API ──────────────────────────────────────

@app.get("/api/chat/traces")
async def get_chat_traces(limit: int = 50):
    """查詢最近 Chat Trace 記錄。"""
    from ark_bot_agent.memory.chat_trace import get_recent_traces, cleanup_old_traces
    # 順便清理過期記錄
    cleanup_old_traces()
    traces = get_recent_traces(limit=limit)
    return {"traces": traces, "count": len(traces)}


@app.get("/api/chat/stats")
async def get_chat_stats(days: int = 7):
    """路由決策的聚合統計（[R5]）。

    等價於 ninja-bot 的 `/router_stats`，但**用既有的 chat_trace 資料** ——
    不另開 JSONL（兩套儲存會讓數字對不上）。
    """
    from ark_bot_agent.memory.chat_trace import stats

    return stats(days=days)


@app.get("/api/chat/traces/{trace_id}")
async def get_chat_trace_by_id(trace_id: str):
    """取得單筆 Trace 詳情。"""
    from ark_bot_agent.memory.chat_trace import get_recent_traces
    # 簡易實作：從 recent 中找
    all_traces = get_recent_traces(limit=500)
    for t in all_traces:
        if t["trace_id"] == trace_id:
            return t
    return {"error": "not found"}


# ─── API ─────────────────────────────────────────────

@app.get("/health")
def health_root():
    """健康檢查（短路徑）。"""
    return {"status": "ok"}


@app.get("/api/v1/health")
async def health():
    return {"status": "ok", "service": "a-agent"}


@app.get("/api/v1/skills")
async def list_skills():
    return {"skills": get_registry().list_skills()}


class QueryRequest(BaseModel):
    q: str


class ChatRequest(BaseModel):
    message: str
    agent_id: str = "default"


@app.post("/api/v1/chat")
async def api_chat(req: ChatRequest):
    """統一對話 API — 走 Ark Agent ReAct Loop（與 TG handle_message 同路徑）。"""
    text = req.message.strip()

    try:
        from ark_bot_agent.llm.context_builder import build_default_system_prompt
        from ark_bot_agent.llm.agent_loop import agent_loop
        import ark_bot_agent.llm.tools  # noqa: F401 — 確保 tools 已註冊

        system_prompt = await build_default_system_prompt(query=text)
        chat = _get_config().modes.chat
        result = await agent_loop(
            user_message=text,
            system_prompt=system_prompt,
            # 讀設定，不寫死 —— 寫死時剛好同值，所以「沒接上」看不出來
            max_iterations=chat.max_iterations,
            allowed_tools=chat.tools,
        )

        reply = result.text or "⚠️ 無法回應"

        return {
            "reply": reply,
            "source": "agent_loop",
            "iterations": result.iterations,
            "tools_used": [t["tool"] for t in result.tool_calls_log],
        }
    except Exception as e:
        return {
            "reply": f"⚠️ 錯誤：{e}",
            "source": "error",
            "iterations": 0,
            "tools_used": [],
        }


@app.get("/api/v1/graph")
async def get_graph():
    """回傳完整圖譜資料（節點+連線）。"""
    from pathlib import Path
    import re

    nodes = []
    links = []

    # Agent 節點
    agents_dir = get_agents_dir()
    agent_ids = []
    if agents_dir.exists():
        for d in sorted(agents_dir.iterdir()):
            if d.is_dir() and d.name.endswith("-agent"):
                agent_id = d.name.replace("-agent", "")
                agent_ids.append(agent_id)
                # 讀 SOUL 第一行
                soul_path = d / ".kiro" / "steering" / "SOUL.md"
                soul_desc = ""
                if soul_path.exists():
                    lines = soul_path.read_text(encoding="utf-8").splitlines()
                    for line in lines:
                        if line.strip() and not line.startswith("---") and not line.startswith("#"):
                            soul_desc = line.strip()[:80]
                            break
                nodes.append({"id": f"agent:{agent_id}", "type": "agent", "label": f"{agent_id}-agent", "meta": soul_desc})

                # Skill 節點
                skills_dir = d / ".kiro" / "skills"
                if skills_dir.exists():
                    for skill_dir in sorted(skills_dir.iterdir()):
                        if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                            skill_name = skill_dir.name
                            # 讀 description
                            skill_content = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
                            desc_match = re.search(r"^description:\s*\|?\s*\n?\s*(.+)", skill_content, re.MULTILINE)
                            skill_desc = desc_match.group(1).strip()[:80] if desc_match else ""
                            nodes.append({"id": f"skill:{skill_name}", "type": "skill", "label": skill_name, "meta": skill_desc})
                            # Agent -> Skill 連線
                            links.append({"source": f"agent:{agent_id}", "target": f"skill:{skill_name}", "relation": "has_skill"})

    # Wiki 節點
    wiki_dir = get_knowledge_dir() / "shared" / "wiki"
    wiki_tags = {}  # filename -> tags
    if wiki_dir.exists():
        for md in sorted(wiki_dir.rglob("*.md")):
            content = md.read_text(encoding="utf-8")
            title_match = re.search(r'^title:\s*["\']?(.+?)["\']?\s*$', content, re.MULTILINE)
            title = title_match.group(1) if title_match else md.stem
            tags_match = re.search(r'^tags:\s*\[(.+)\]', content, re.MULTILINE)
            tags = [t.strip().strip("'\"") for t in tags_match.group(1).split(",")] if tags_match else []
            wiki_tags[md.name] = tags
            nodes.append({"id": f"wiki:{md.name}", "type": "wiki", "label": title, "meta": ", ".join(tags)})

    # Skill -> Wiki 連線（Skill 觸發詞匹配 wiki title）
    for node in nodes:
        if node["type"] == "skill":
            skill_id = node["id"]
            # 簡單匹配：skill label 含 wiki 主題關鍵字
            skill_label = node["label"].lower()
            for wiki_node in [n for n in nodes if n["type"] == "wiki"]:
                wiki_label = wiki_node["label"].lower()
                # competitor/market skill 連 競品分析 wiki
                if any(kw in skill_label for kw in ["market", "competitor", "research"]):
                    if any(kw in wiki_label for kw in ["ocean", "super", "slot", "fish", "捕魚", "老虎"]):
                        links.append({"source": skill_id, "target": wiki_node["id"], "relation": "reads_wiki"})

    # Wiki <-> Wiki 連線（共享 tag）
    wiki_files = list(wiki_tags.keys())
    for i in range(len(wiki_files)):
        for j in range(i + 1, len(wiki_files)):
            shared = set(wiki_tags[wiki_files[i]]) & set(wiki_tags[wiki_files[j]])
            if shared:
                links.append({"source": f"wiki:{wiki_files[i]}", "target": f"wiki:{wiki_files[j]}", "relation": "shared_tag"})

    return {"nodes": nodes, "links": links}


@app.get("/api/v1/wiki/pages")
async def list_wiki_pages():
    """列出所有 wiki 頁面（shared + agents），含 scope 標記。"""
    import re as _re

    def extract_title(content: str) -> str:
        m = _re.search(r'^title:\s*["\']?(.+?)["\']?\s*$', content, _re.MULTILINE)
        return m.group(1) if m else ""

    def scan_dir(dir_path: Path, prefix: str = "") -> list:
        items = []
        if not dir_path.exists():
            return items
        for entry in sorted(dir_path.iterdir()):
            if entry.name.startswith("."):
                continue
            rel_path = entry.name if not prefix else f"{prefix}/{entry.name}"
            if entry.is_dir():
                children = scan_dir(entry, rel_path)
                if children:
                    items.append({"type": "folder", "name": entry.name, "path": rel_path, "children": children})
            elif entry.suffix == ".md":
                content = entry.read_text(encoding="utf-8")
                title = extract_title(content) or entry.stem
                items.append({"type": "file", "filename": rel_path, "title": title})
        return items

    pages = []

    # Shared wiki
    shared_wiki = get_knowledge_dir() / "shared" / "wiki"
    if shared_wiki.exists():
        shared_items = scan_dir(shared_wiki, "shared")
        if shared_items:
            pages.append({"type": "folder", "name": "📚 共用知識", "path": "shared", "children": shared_items})

    # Agent wiki
    agents_dir = get_agents_dir()
    if agents_dir.exists():
        for agent_dir in sorted(agents_dir.iterdir()):
            if agent_dir.is_dir() and agent_dir.name.endswith("-agent"):
                wiki_dir = agent_dir / "knowledge" / "wiki"
                if wiki_dir.exists():
                    agent_items = scan_dir(wiki_dir, f"agents/{agent_dir.name}")
                    if agent_items:
                        pages.append({"type": "folder", "name": f"🤖 {agent_dir.name}", "path": f"agents/{agent_dir.name}", "children": agent_items})

    return {"pages": pages}


@app.get("/api/v1/wiki/pages/{filepath:path}")
async def get_wiki_page(filepath: str):
    """取得指定 wiki 頁面內容（支援 shared/ 和 agents/ 前綴）。"""
    # 路由：shared/xxx → knowledge/shared/wiki/xxx
    #       agents/{name}-agent/xxx → agents/{name}-agent/knowledge/wiki/xxx
    if filepath.startswith("shared/"):
        rel = filepath[len("shared/"):]
        path = get_knowledge_dir() / "shared" / "wiki" / rel
    elif filepath.startswith("agents/"):
        parts = filepath.split("/", 2)  # agents/{name}/rest
        if len(parts) >= 3:
            path = Path(f"agents/{parts[1]}/knowledge/wiki/{parts[2]}")
        else:
            return {"error": "invalid path"}
    else:
        # Fallback：嘗試 shared
        path = get_knowledge_dir() / "shared" / "wiki" / filepath
    if not path.exists() or not path.is_file():
        return {"error": "not found"}
    return {"filename": filepath, "content": path.read_text(encoding="utf-8")}


@app.post("/api/v1/wiki/query")
async def wiki_query(req: QueryRequest):
    result = await engine.query(req.q)
    return result


@app.post("/api/v1/wiki/ingest")
async def wiki_ingest():
    ingested = engine.ingest()
    return {"ingested": ingested, "count": len(ingested)}


@app.get("/api/v1/wiki/lint")
async def wiki_lint():
    issues = engine.lint()
    return {"issues": issues, "healthy": len(issues) == 0}


@app.post("/api/v1/wiki/rebuild-index")
async def wiki_rebuild_index():
    """手動觸發搜尋索引重建。"""
    from ark_bot_agent.wiki.indexer import rebuild_index
    manifest = rebuild_index()
    return {"status": "ok", "manifest": manifest}


@app.get("/api/v1/wiki/index-status")
async def wiki_index_status():
    """查看搜尋索引狀態。"""
    import json
    # 🔴 用 indexer 的常數，**不自己組路徑** —— 手寫成
    # `get_knowledge_dir() / ".index"` 會少一層 `shared`，於是 rebuild 明明成功、
    # 這裡永遠回 `not_built`。這是 M2.1 那個 BM25 bug 的第三個實例
    # （前兩個是 `layer1_bm25` 與 `indexer` 讀寫不一致）。
    from ark_bot_agent.wiki.indexer import INDEX_DIR

    manifest_path = INDEX_DIR / "manifest.json"
    if not manifest_path.exists():
        return {"status": "not_built", "manifest": None}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    return {"status": "ok", "manifest": manifest}
