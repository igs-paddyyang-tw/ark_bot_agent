"""Bot 指令處理 — Inline Button Agent 切換 + Memory 管理。

對話流程：
  /agents → Inline Keyboard → 選 Agent → 對話 → 自動寫 memory
"""
from __future__ import annotations

import asyncio
import os
import re
from pathlib import Path

from ark_bot_agent.paths import get_agents_dir, get_knowledge_dir, get_memory_dir, get_shared_tasks_dir, get_steering

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from ark_bot_agent.agent.session import session_manager
from ark_bot_agent.agent.cli import AVAILABLE_AGENTS, is_cli_available, agent_cli_chat
from ark_bot_agent.config import get_config

log = __import__("logging").getLogger("bot.handlers")

# ── 白名單 ──
#
# 🔴 [0.6.0] 這裡原本**只讀環境變數**，`bot.yaml` 的 access 段從來沒被讀取。
#    `.env` 沒設 `ADMIN_CHAT_IDS` 時白名單是空的 → 「空＝不限制」
#    → **設了白名單卻對所有人開放**。改走 `access.AccessControl`
#    （靜態來自 bot.yaml + env 疊加，動態來自 state/access.json）。
#
# 模組層不再快取集合 —— 那會讓執行期增刪不生效。


def _is_authorized(user_id: int) -> bool:
    """在白名單中嗎。白名單為空 = 不限制（維持既有語意）。"""
    from ark_bot_agent.access import get_access

    return get_access().is_allowed(user_id)


def _is_admin(user_id: int) -> bool:
    """是 admin 等級嗎。

    ⚠️ 空白名單時回 `False` —— **「不限制使用」不等於「都是管理員」**。
    """
    from ark_bot_agent.access import get_access

    return get_access().is_admin(user_id)


async def _require_auth(update: Update) -> bool:
    """白名單檢查，未授權回覆提示並回傳 False。公開指令不需呼叫此函式。"""
    user_id = update.effective_user.id
    if _is_authorized(user_id):
        return True
    await update.message.reply_text(
        f"🔒 需要權限。\n\nChat ID：`{user_id}`",
        parse_mode="Markdown",
    )
    return False


# ── 載入 SOUL（fallback 模式用）──
# [0.6.0] 移除了未使用的 `_SOUL_DIR` —— 它寫死 admin-agent 的目錄名，
#         而且**從來沒有被引用過**（純死碼）。真要用該讀 agents.yaml 的 `dir`。


def _load_soul(agent_id: str) -> str:
    """載入指定 Agent 的 SOUL.md。"""
    path = Path(f"agents/{agent_id}-agent/.kiro/steering/SOUL.md")
    if path.exists():
        return path.read_text(encoding="utf-8")
    # fallback 到根 .kiro/
    root_soul = get_steering("SOUL.md")
    return root_soul.read_text(encoding="utf-8") if root_soul.exists() else ""


# ── 指令 ─────────────────────────────────────────────────


def _escape_md(text: str) -> str:
    """逸出 Telegram Legacy Markdown 特殊字元（_ * ` [）。"""
    for ch in ("_", "*", "`", "["):
        text = text.replace(ch, f"\\{ch}")
    return text


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    is_allowed = _is_authorized(user_id)
    first_name = _escape_md(update.effective_user.first_name or "你")

    if not is_allowed:
        await update.message.reply_text(
            f"🔒 哈囉！目前我只服務授權使用者。\n\n"
            f"你的 ID：`{user_id}`\n"
            f"請聯繫管理員開通權限 😊",
            parse_mode="Markdown",
        )
        return

    await update.message.reply_text(
        f"👋 嗨 {first_name}！我是娜娜，你的雲端助理。\n\n"
        f"直接打字就能跟我聊天，不管是技術問題、AWS 維護、或只是聊聊都行 😊\n\n"
        f"需要特定專家可以用 /agents 切換。",
        parse_mode="Markdown",
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "📖 *使用指南*\n\n"
        "💬 直接打字就能對話，我會自動判斷要怎麼幫你。\n\n"
        "*常用指令*\n"
        "/agents — 切換專業 Agent（開發、測試、分析⋯）\n"
        "/recall `關鍵詞` — 搜尋過去的對話記憶\n"
        "/status — 查看系統狀態\n\n"
        "*進階*\n"
        "`@agent名稱 訊息` — 直接指定 Agent 處理\n"
        "/skills — 查看可用技能\n"
        "/history — 近期對話紀錄",
        parse_mode="Markdown",
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """顯示 Bot 狀態概覽。"""
    if not await _require_auth(update):
        return
    from ark_bot_agent.agent.cli import is_cli_available, get_available_backend

    cli_ok = is_cli_available()
    backend = get_available_backend() if cli_ok else "無"
    gemini_ok = "✅" if os.getenv("GEMINI_API_KEY") else "❌"
    from ark_bot_agent.config import get_config

    model = os.getenv("LLM_MODEL") or get_config().llm.model  # env-ok: env 覆寫，預設走 llm.model

    await update.message.reply_text(
        f"📊 *系統狀態*\n\n"
        f"• LLM：{gemini_ok} {model}\n"
        f"• Agent CLI：{'✅ ' + backend if cli_ok else '❌ 未安裝'}\n"
        f"• 路由：三路徑（command / @mention / 自然語言）\n"
        f"• 派工：dispatch_to_agent（7 Agents）",
        parse_mode="Markdown",
    )


# ── 三模式（對齊 ninja-bot 的 Chat / Agent / Team）─────────────
#
# 模式是**使用者選的，不靠 AI 猜** —— 這是 ninja 的設計要點：
# 同一句話在不同模式下該有不同處理成本，讓人決定比讓模型判斷準確。
_MODE_INFO = {
    "chat": {"emoji": "💬", "label": "快答", "desc": "娜娜直答，會用知識庫／上網／派工"},
    # 標籤直接用「管家」而非泛稱 —— 這個模式的預設對象就是 admin，
    # 用實際的人比用抽象分類好認。切到別人時面板文字會顯示實際對象。
    "agent": {"emoji": "👑", "label": "管家", "desc": "管家深入處理：系統管理、監控、費用把關"},
    "team": {"emoji": "⚔️", "label": "團隊", "desc": "隊長拆解 → 成員執行 → 隊長彙整"},
}

def _build_agents_keyboard(session) -> InlineKeyboardMarkup:
    """三模式面板 —— **只有三個按鈕**。

    刻意不放成員快捷列：那會讓「選模式」與「選人」兩件事擠在同一個面板裡，
    按鈕一多反而看不出當前狀態。要換人用 `@代號`（Path 1，不受模式影響）。
    """
    kind = session.mode_kind

    def mode_btn(mode_id: str) -> InlineKeyboardButton:
        info = _MODE_INFO[mode_id]
        mark = "✅ " if kind == mode_id else "　"
        return InlineKeyboardButton(
            f"{mark}{info['emoji']} {info['label']}", callback_data=f"switch_mode:{mode_id}"
        )

    return InlineKeyboardMarkup([[mode_btn("chat"), mode_btn("agent"), mode_btn("team")]])


def _build_agents_text(session) -> str:
    """面板文字：當前模式 + 三模式說明。"""
    kind = session.mode_kind
    info = _MODE_INFO[kind]

    if kind == "chat":
        current = f"{info['emoji']} *快答*（🚀 娜娜）"
        desc = info["desc"]
    elif kind == "team":
        current = f"{info['emoji']} *團隊*（🎯 隊長統籌）"
        desc = info["desc"]
    else:
        # 用 @代號 換過人時，標題要顯示**實際對象**而不是按鈕上的「管家」
        a = AVAILABLE_AGENTS.get(session.agent_name, {})
        current = f"{a.get('emoji', '🤖')} *{a.get('codename', session.agent_name)}*"
        desc = a.get("desc", info["desc"])

    return (
        f"🎯 目前模式：{current}\n"
        f"💬 {desc}\n\n"
        "─────────────────\n"
        "💬 *快答* — 娜娜直答，會用知識庫／上網／派工\n"
        "👑 *管家* — 一位職人深入處理\n"
        "⚔️ *團隊* — 隊長拆解 → 成員執行 → 隊長彙整\n\n"
        "換人用 `@代號` —— 不受模式影響\n"
        "　`@碼哥 幫我看這段` ｜ `@隊長 …`（只找隊長，不拉人）\n"
        "切模式**會保留**對話脈絡，要重開用 `/clear`\n"
        "點一下切換 👇"
    )


async def cmd_agents(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """顯示 Agent 切換面板（保持常駐）。"""
    if not await _require_auth(update):
        return
    user_id = update.effective_user.id
    session = session_manager.get_or_create(user_id)

    await update.message.reply_text(
        _build_agents_text(session),
        parse_mode="Markdown",
        reply_markup=_build_agents_keyboard(session),
    )


async def callback_switch_agent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Inline Button 回調 — 切換模式／對象，面板原地更新不消失。

    兩種 callback_data：
    - `switch_mode:{chat|agent|team}` —— 切模式（agent 未指定人時用 `DEFAULT_AGENT`）
    - `switch_agent:{id}` —— 進 agent 模式並指定那一位
    """
    query = update.callback_query
    await query.answer()

    prefix, _, value = query.data.partition(":")
    user_id = query.from_user.id

    if prefix == "switch_mode":
        if value not in session_manager.MODES:
            await query.answer("❌ 無效的模式", show_alert=True)
            return
        kind, agent_id = value, None
    else:  # switch_agent
        if value not in AVAILABLE_AGENTS:
            await query.answer("❌ 無效的 Agent", show_alert=True)
            return
        kind, agent_id = "agent", value

    # CLI 可用性檢查（chat＝娜娜走 Gemini，不需要 CLI；agent／team 都要）
    if kind != "chat" and not is_cli_available():
        await query.answer(
            "⚠️ 需要 Agent CLI（agy / kiro-cli / claude）",
            show_alert=True,
        )
        return

    session_manager.switch_mode(user_id, kind, agent_id)
    session = session_manager.get_or_create(user_id)

    # 原地更新面板（文字 + 鍵盤同步刷新）
    try:
        await query.edit_message_text(
            _build_agents_text(session),
            parse_mode="Markdown",
            reply_markup=_build_agents_keyboard(session),
        )
    except Exception:
        # 內容沒變時 Telegram 會拋錯，忽略即可
        pass


async def cmd_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """顯示當前執行模式。"""
    if not await _require_auth(update):
        return
    if is_cli_available():
        from ark_bot_agent.agent.cli import get_available_backend
        backend = get_available_backend()
        await update.message.reply_text(
            "🧠 *Agent CLI 模式*\n\n"
            f"• Backend: {backend} ✅\n"
            "• .kiro/ 配置全部生效\n"
            f"• 對話由 {backend} 驅動",
            parse_mode="Markdown",
        )
    else:
        has_key = "✅" if os.getenv("GEMINI_API_KEY") else "❌"
        await update.message.reply_text(
            f"⚡ *Gemini API 模式*\n\n"
            f"• Gemini Key: {has_key}\n"
            f"• SOUL.md 作為 system prompt\n\n"
            "升級：安裝 Agent CLI（agy / kiro-cli / claude）",
            parse_mode="Markdown",
        )


async def cmd_history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """顯示近期對話歷史。"""
    if not await _require_auth(update):
        return
    user_id = update.effective_user.id
    session = session_manager.get_or_create(user_id)
    if not session.history:
        await update.message.reply_text("📭 目前沒有對話歷史")
        return
    agent_info = AVAILABLE_AGENTS.get(session.current_agent, {})
    agent_emoji = agent_info.get("emoji", "🤖")
    agent_codename = agent_info.get("codename", session.current_agent)
    lines = [f"📜 對話歷史（{agent_emoji} {agent_codename}）：\n"]
    for turn in session.history[-6:]:  # 最近 6 輪
        prefix = "👤" if turn.role == "user" else "🤖"
        content = turn.content[:80] + "..." if len(turn.content) > 80 else turn.content
        lines.append(f"{prefix} {content}")
    await update.message.reply_text("\n".join(lines))


async def cmd_clear(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """清空對話歷史（模式不變）。

    切模式**不再**自動清歷史（`switch_mode(keep_history=True)`）——
    使用者切模式通常是「同一件事換個人問」，清掉等於逼他再講一次。
    真的要重開就用這個指令，讓「換人」與「重開」是兩個獨立動作。
    """
    if not await _require_auth(update):
        return
    session = session_manager.get_or_create(update.effective_user.id)
    n = len(session.history)
    session.clear_history()
    kind = _MODE_INFO[session.mode_kind]
    await update.message.reply_text(
        f"🧹 清掉 {n} 輪對話，模式維持 {kind['emoji']} {kind['label']}"
        if n else f"📭 本來就沒有對話歷史（模式：{kind['emoji']} {kind['label']}）"
    )


# ── /chat — 強制 Gemini API（帶完整 context）──────────────


async def cmd_chat(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/chat <問題> — 強制使用 Gemini API 回答（帶完整記憶+知識+技能 context）。"""
    if not await _require_auth(update):
        return
    text = " ".join(context.args) if context.args else ""
    if not text:
        await update.message.reply_text(
            "用法：`/chat 你的問題`\n\n"
            "此指令強制使用 Gemini API（2-3 秒回覆），"
            "帶入完整 context：SOUL + 記憶 + 知識庫 + 技能清單 + 對話歷史。",
            parse_mode="Markdown",
        )
        return

    gemini_key = os.getenv("GEMINI_API_KEY", "")
    if not gemini_key:
        await update.message.reply_text("❌ GEMINI_API_KEY 未設定")
        return

    user_id = update.effective_user.id
    session = session_manager.get_or_create(user_id)
    current_agent = session.current_agent
    agent_info = AVAILABLE_AGENTS[current_agent]

    session.add_turn("user", text)
    await _set_reaction(update.message, "🔥")

    # ── 組裝完整 system prompt ──
    system_prompt = await _build_rich_system_prompt(current_agent, text, session)

    # ── 呼叫 Gemini（帶 Tool Calling）──
    try:
        from ark_bot_agent.llm.agent_loop import agent_loop
        result = await agent_loop(text, system_prompt=system_prompt)
        reply = result.text or ""
    except Exception as e:
        log.error("Gemini chat error: %s", e)
        reply = f"呃，我剛剛腦袋打結了 😵 再說一次好嗎？"

    if reply:
        if len(reply) > 3000:
            reply = reply[-3000:]
        session.add_turn("agent", reply)
        await _set_reaction(update.message, "👍")
        from ark_bot_agent.bot.progress import md_to_tg_html
        html_reply = md_to_tg_html(reply)
        for i in range(0, len(html_reply), 4000):
            try:
                await update.message.reply_text(html_reply[i:i+4000], parse_mode="HTML")
            except Exception:
                await update.message.reply_text(reply[i:i+4000])
    else:
        await _set_reaction(update.message, "💔")
        await update.message.reply_text("嗯⋯我好像沒接到，再試一次？")


async def _build_rich_system_prompt(agent_id: str, query: str, session) -> str:
    """組裝完整 Gemini system prompt（6 層 context）。

    注入順序：
    1. SOUL.md — Agent 人格
    2. memory.md — 持久事實（蒸餾記憶）
    3. recent.md — 今+昨 daily log
    4. FTS5 recall — 相關歷史記憶 top-3
    5. Wiki context — 知識庫相關段落
    6. Skills list — 可用技能清單
    7. Session history — 對話歷史
    """
    parts: list[str] = []

    # 1. SOUL
    soul = _load_soul(agent_id)
    if soul:
        parts.append(soul)

    # 2. memory.md（蒸餾持久事實）
    memory_path = Path(f"agents/{agent_id}-agent/memory/memory.md")
    if memory_path.exists():
        content = memory_path.read_text(encoding="utf-8")
        if content.strip() and len(content) > 20:
            parts.append(f"\n## 持久記憶\n{content[:1500]}")

    # 3. recent.md（最近經驗）
    recent_path = Path(f"agents/{agent_id}-agent/memory/recent.md")
    if recent_path.exists():
        content = recent_path.read_text(encoding="utf-8")
        if content.strip() and "（尚無記錄）" not in content:
            parts.append(f"\n## 最近經驗\n{content[:1500]}")

    # 4. FTS5 recall（相關歷史）
    try:
        from ark_bot_agent.memory.recall import recall
        results = recall(f"{agent_id}-agent", query, k=3)
        if results:
            recall_lines = ["\n## 相關歷史記憶"]
            for r in results:
                recall_lines.append(f"- [{r.date}] {r.title}: {r.body[:100]}")
            parts.append("\n".join(recall_lines))
    except Exception:
        # FTS5 不可用時 fallback
        memory_context = _search_memory(agent_id, query)
        if memory_context:
            parts.append(f"\n## 相關歷史記憶\n{memory_context}")

    # 5. Wiki context（知識庫相關段落，不走 RAG 合成）
    try:
        from ark_bot_agent.wiki.engine import WikiEngine
        engine = WikiEngine(agent_id=agent_id)
        wiki_result = await engine.query(query, use_rag=False)
        if wiki_result.get("results"):
            wiki_lines = ["\n## 知識庫參考（搜尋範圍：私有 wiki → knowledge/shared/wiki/）"]
            for r in wiki_result["results"][:3]:
                wiki_lines.append(f"### {r['title']}\n{r['snippet'][:200]}")
            parts.append("\n".join(wiki_lines))
        else:
            parts.append(
                "\n## 知識檢索規則\n"
                "- 回答事實性問題前先查 wiki（私有 → 共用 knowledge/shared/wiki/）\n"
                "- 查無結果才走外部搜尋，並明確告知使用者"
            )
    except Exception:
        pass

    # 6. Skills list（可用技能）
    try:
        from ark_bot_agent.skills.registry import get_registry
        skills = get_registry().list_skills()
        if skills:
            skill_lines = ["\n## 可用技能（使用者可用 /skill_id 觸發）"]
            for s in skills[:10]:
                skill_lines.append(f"- /{s['skill_id']} — {s['description'][:40]}")
            parts.append("\n".join(skill_lines))
    except Exception:
        pass

    # 7. Session history
    context_str = session.get_context()
    if context_str:
        parts.append(f"\n{context_str}")

    return "\n\n".join(parts)


async def _build_default_system_prompt(query: str, session) -> str:
    """組裝 Default 模式的 Gemini system prompt（8 層 context + Tool 規則）。

    讀取根目錄的 steering + memory + wiki，不走任何 Agent 私有目錄。
    """
    parts: list[str] = []

    # 1. SOUL.md（根目錄）
    soul_path = get_steering("SOUL.md")
    if soul_path.exists():
        parts.append(soul_path.read_text(encoding="utf-8"))

    # 2. BRAIN.md（根目錄）
    brain_path = get_steering("BRAIN.md")
    if brain_path.exists():
        content = brain_path.read_text(encoding="utf-8")
        # 移除 frontmatter
        if content.startswith("---"):
            _, _, content = content.split("---", 2)
        parts.append(content.strip())

    # 3. TEAM.md（根目錄）
    team_path = get_steering("TEAM.md")
    if team_path.exists():
        parts.append(team_path.read_text(encoding="utf-8"))

    # 4. Tool 使用規則
    parts.append("""## 工具使用規則

你有三個工具可用：read_file、write_file、list_files。

### 何時使用 write_file：
- 使用者明確要求：「寫成報告」「存進知識庫」「匯出」「產出文件」「幫我整理成文章」
- 寫入前告訴使用者你要寫什麼、寫到哪裡
- 寫入後回覆確認路徑和大小

### 何時不使用 write_file：
- 一般對話（只是聊天、問答）→ 不寫
- 使用者沒要求保存 → 不寫
- 對話記錄 → 系統自動處理，你不需寫

### 寫入路徑選擇：
- 報告/分析 → output/reports/{date}_{slug}.md
- 知識庫文章（使用者說「存進知識庫」）→ knowledge/shared/raw/{slug}.md（系統會自動匯入索引）
- 匯出資料 → output/exports/{date}_{slug}.csv
- 草稿 → output/drafts/{slug}.md

### Memory vs Wiki 分工：
- Memory（系統自動）= 你經歷過的事（對話記錄、決策）
- Wiki（使用者要求才寫）= 可重複引用的知識（事實、規格、分析）
- Output（使用者要求才寫）= 交付的產出物（報告、匯出檔）
""")

    # 5. memory/memory.md（根目錄持久事實）
    memory_path = get_memory_dir() / "memory.md"
    if memory_path.exists():
        content = memory_path.read_text(encoding="utf-8")
        if content.strip() and "（尚無記錄）" not in content:
            parts.append(f"\n## 持久記憶\n{content[:1500]}")

    # 6. memory/recent.md（根目錄最近經驗）
    recent_path = get_memory_dir() / "recent.md"
    if recent_path.exists():
        content = recent_path.read_text(encoding="utf-8")
        if content.strip() and "（尚無記錄）" not in content:
            parts.append(f"\n## 最近經驗\n{content[:1500]}")

    # 6b. 今日 daily log 尾部 5 筆（讓 Gemini 知道今天做過什麼）
    from datetime import datetime as _dt
    today_log = get_memory_dir() / "daily" / f"{_dt.now().strftime('%Y-%m-%d')}.md"
    if today_log.exists():
        log_content = today_log.read_text(encoding="utf-8")
        log_entries = [e.strip() for e in log_content.split("\n## ") if e.strip()]
        # 取最後 5 筆（跳過 header 行）
        recent_entries = log_entries[-5:] if len(log_entries) > 5 else log_entries
        if recent_entries:
            daily_text = "\n## ".join(recent_entries)
            # 去掉可能的 "# 2026-07-13 Daily Log" header
            if daily_text.startswith("#"):
                lines = daily_text.split("\n", 1)
                daily_text = lines[1] if len(lines) > 1 else ""
            if daily_text.strip():
                parts.append(f"\n## 今日對話紀錄\n## {daily_text.strip()}")

    # 7. FTS5 recall（查 default + shared）
    try:
        from ark_bot_agent.memory.recall import recall
        results = recall("_default", query, k=3, include_shared=True)
        if results:
            recall_lines = ["\n## 相關歷史記憶"]
            for r in results:
                recall_lines.append(f"- [{r.date}] {r.title}: {r.body[:100]}")
            parts.append("\n".join(recall_lines))
    except Exception:
        pass

    # 8. Wiki RAG（shared wiki）
    try:
        from ark_bot_agent.wiki.engine import WikiEngine
        engine = WikiEngine()
        wiki_result = await engine.query(query, use_rag=False)
        if wiki_result.get("results"):
            wiki_lines = ["\n## 知識庫參考"]
            for r in wiki_result["results"][:3]:
                wiki_lines.append(f"### {r['title']}\n{r['snippet'][:200]}")
            parts.append("\n".join(wiki_lines))
    except Exception:
        pass

    # 9. Skills 清單
    try:
        from ark_bot_agent.skills.registry import get_registry
        skills = get_registry().list_skills()
        if skills:
            skill_lines = ["\n## 可用技能（/skill_id 觸發）"]
            for s in skills[:10]:
                skill_lines.append(f"- /{s['skill_id']} — {s['description'][:40]}")
            parts.append("\n".join(skill_lines))
    except Exception:
        pass

    # 10. Session history
    context_str = session.get_context()
    if context_str:
        parts.append(f"\n{context_str}")

    return "\n\n".join(parts)


# ── 自然語言路由 ─────────────────────────────────────────


async def _record_only(user_id: int, text: str, update: Update) -> None:
    """不回覆，但把訊息寫進記憶（[R1]／ADR-003）。

    ⚠️ 寫記憶失敗**只 log** —— 不影響「不回覆」這個主行為。
    群組略過是准入決策，記憶是附加價值，後者不該拖累前者。
    """
    try:
        session = session_manager.get_or_create(user_id)
        session.add_turn("user", text)
    except Exception as e:                                # noqa: BLE001
        log.warning("群組訊息寫 session 失敗（不影響略過）：%s", e)
    try:
        from ark_bot_agent.memory.daily_log import write_daily_log

        asyncio.create_task(write_daily_log(
            "_group", f"msg-{update.message.message_id}", f"User: {text[:200]}"))
    except Exception as e:                                # noqa: BLE001
        log.warning("群組訊息寫 daily_log 失敗（不影響略過）：%s", e)


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """主對話處理：三路徑路由。

    路由：
      1. @agent-name msg → 強制指定 agent（白名單）
      2. 自然語言 → Ark Agent（Gemini ReAct + 自動派工）（白名單）
    """
    text = update.message.text.strip()
    user_id = update.effective_user.id

    # ── 白名單檢查 ──
    if not _is_authorized(user_id):
        await update.message.reply_text(
            f"🔒 需要權限。\n\nChat ID：`{user_id}`",
            parse_mode="Markdown",
        )
        return

    # ── 群組策略（[R1]）──
    #
    # 🔴 0.7.0 之前**這裡沒有任何 chat.type 判斷** —— 所有訊息走同一條路。
    #    私訊時是對的，**群組時 bot 會回應每一則訊息**（群組立刻不能用）。
    #    不回覆時**仍寫記憶** —— 群組是資訊來源，不回話是禮貌，不聽是浪費。
    from ark_bot_agent.access import get_access

    chat = update.message.chat
    if not get_access().should_reply(
        chat_type=getattr(chat, "type", None),
        text=text,
        bot_username=getattr(context.bot, "username", None),
    ):
        log.debug("群組略過（policy=%s）：%s", get_access().group_policy, text[:40])
        await _record_only(user_id, text, update)
        return

    session = session_manager.get_or_create(user_id)
    session.add_turn("user", text)
    log.info("📨 user=%s msg=%s", user_id, text[:100])

    # ── Chat Trace: 建立記錄 ──
    from ark_bot_agent.memory.chat_trace import create_trace, update_trace_decision, complete_trace, fail_trace
    trace_id = create_trace(text)

    # ── 自動 consolidate ──
    await _auto_consolidate_if_needed()

    # ── Reaction: 👀 收到 + typing ──
    await _set_reaction(update.message, "👀")
    done = asyncio.Event()
    timer_task = asyncio.create_task(
        _keep_action_alive(update.message.chat_id, "typing", done, context.bot)
    )

    try:
        reply: str | None = None

        # ── 代號 → Agent ID 對照表（支援中英文代號 + @語法）──
        _CODENAME_MAP: dict[str, str] = {}
        for _aid, _info in AVAILABLE_AGENTS.items():
            # 技術名稱（英文）
            _CODENAME_MAP[_aid] = _aid
            _CODENAME_MAP[f"{_aid}-agent"] = _aid
            # 中文代號
            if "codename" in _info:
                _CODENAME_MAP[_info["codename"]] = _aid

        def _resolve_agent(name: str) -> str | None:
            """從代號/技術名稱解析 agent_id，找不到回 None。"""
            name = name.strip().replace("-agent", "").lower()
            # 直接匹配
            if name in _CODENAME_MAP:
                return _CODENAME_MAP[name]
            # 中文代號匹配（大小寫不敏感已處理，中文直接比對）
            for key, val in _CODENAME_MAP.items():
                if key == name:
                    return val
            return None

        # ── Path 1: @mention → 強制指定 agent（支援 @碼哥、@coder、@coder-agent）──
        if match := re.match(r"@([\w\u4e00-\u9fff-]+)\s*(.*)", text, re.DOTALL):
            target = match.group(1)
            message = match.group(2).strip() or text
            agent_id = _resolve_agent(target)

            if not agent_id or agent_id == "default":
                # 找不到對應的 agent
                await update.message.reply_text(f"🤔 不認識「{target}」欸，用 /agents 看看有誰？")
                return

            update_trace_decision(trace_id, "@mention直送", agent_id, agent_id)

            if is_cli_available():
                reply = (await agent_cli_chat(message, agent_id=agent_id)).reply_text()
            else:
                # fallback Gemini
                from ark_bot_agent.llm.chat import simple_chat
                soul_path = Path(f"agents/{agent_id}-agent/.kiro/steering/SOUL.md")
                soul = soul_path.read_text(encoding="utf-8") if soul_path.exists() else ""
                reply = await simple_chat(message, system=soul)

            if reply:
                reply = _clean_output(reply)
                session.add_turn("agent", reply)
                complete_trace(trace_id, reply[:80], success=True)
                await _set_reaction(update.message, "👍")
                # 用 codename 標示誰回的
                info = AVAILABLE_AGENTS.get(agent_id, {})
                codename = info.get("codename", agent_id)
                emoji = info.get("emoji", "🤖")
                from ark_bot_agent.bot.progress import md_to_tg_html
                html_reply = md_to_tg_html(reply)
                try:
                    await update.message.reply_text(
                        f"{emoji} <b>{codename}</b>：\n{html_reply}", parse_mode="HTML"
                    )
                except Exception:
                    await update.message.reply_text(f"{emoji} {codename}：\n{reply}")
            else:
                fail_trace(trace_id, f"{target} 不可用")
                await _set_reaction(update.message, "👎")
                info = AVAILABLE_AGENTS.get(agent_id, {})
                codename = info.get("codename", target)
                await update.message.reply_text(f"😅 {codename}好像不在，晚點再試試？")
            return

        # ── Path 2: 👑 管家 / ⚔️ 團隊 —— 都走 Agent CLI（差別只在送給誰、帶什麼提示）──
        # 模式是使用者選的，不靠 AI 猜（對齊 ninja-bot 的設計）
        if session.mode_kind in ("agent", "team"):
            is_team = session.mode_kind == "team"
            agent_id = session_manager.team_leader if is_team else session.agent_name
            update_trace_decision(
                trace_id,
                "團隊統籌" if is_team else "Agent分身",
                agent_id,
                f"{'team' if is_team else 'cli'}:{agent_id}",
            )

            info = AVAILABLE_AGENTS.get(agent_id, {})
            emoji = info.get("emoji", "🤖")
            codename = info.get("codename", agent_id)

            # ProgressStack（即時進度回饋）
            from ark_bot_agent.bot.progress import ProgressStack
            progress = ProgressStack(update.message.chat_id, context.bot)
            await progress.init(
                f"{emoji} {codename}統籌中..." if is_team else f"{emoji} {codename}思考中..."
            )

            if is_team and is_cli_available():
                # ⚔️ 團隊：leader 規劃 → Python 代為執行 → leader 收斂（三階段）。
                # 成員清單由 agents.yaml 的 group_members 產生，**不寫進 prompt 字串**。
                from ark_bot_agent.bot.team_flow import run_team_flow
                reply = await run_team_flow(
                    text,
                    session=session,
                    leader_id=agent_id,
                    on_progress=progress.update,
                )
            elif is_cli_available():
                from ark_bot_agent.agent.cli import agent_cli_chat
                cli_result = await agent_cli_chat(text, agent_id=agent_id, session=session)
                reply = cli_result.reply_text()
                # [0.9.1] 超時/失敗時給使用者明確回饋（非靜默）
                if not reply and cli_result.timed_out:
                    reply = None  # 下面 else 分支會處理
                    _timeout_msg = "⏱️ 處理超時，請稍後重試或簡化問題。"
                elif not reply and not cli_result.is_ok():
                    reply = None
                    _timeout_msg = f"😅 處理失敗（{cli_result.error[:30]}），請重試。"
                else:
                    _timeout_msg = None
            else:
                # fallback: 用該 Agent 的 SOUL 做 Gemini 對話
                from ark_bot_agent.llm.agent_loop import agent_loop
                system_prompt = await _build_rich_system_prompt(agent_id, text, session)
                result = await agent_loop(
                    user_message=text,
                    system_prompt=system_prompt,
                    max_iterations=get_config().modes.chat.max_iterations,
                )
                reply = result.text if result else None

            if reply:
                reply = _clean_output(reply)
                # 報告管線在截斷**之前** —— 截斷是 TG 訊息長度限制，
                # 不該讓存進 MD 的內容跟著被切掉
                members = ([agent_id, *get_config().group_members(agent_id)]
                           if is_team else [agent_id])
                reply = await _attach_report(
                    update, reply, mode="team" if is_team else "agent",
                    agents=members, query=text,
                )
                # [0.9.1] 長回覆走報告管線，不再硬截斷
                # 統一由 output_filter 的 _MAX_REPLY_CHARS 控制
                session.add_turn("agent", reply[:3000])  # session 只存摘要
                complete_trace(trace_id, reply[:80], success=True)
                await progress.complete(reply)
                await _set_reaction(update.message, "👍")
            else:
                fail_trace(trace_id, f"{agent_id} 無回覆")
                _fail_msg = _timeout_msg if '_timeout_msg' in dir() and _timeout_msg else f"😅 {codename}好像沒反應，要不要再試一次？"
                await progress.fail(_fail_msg)
                await _set_reaction(update.message, "👎")
            return

        # ── Path 3: 自然語言 → Ark Agent（ReAct + 自動派工）──
        from ark_bot_agent.llm.context_builder import build_default_system_prompt
        from ark_bot_agent.llm.agent_loop import agent_loop
        from ark_bot_agent.bot.progress import ProgressStack
        import ark_bot_agent.llm.tools  # noqa: F401 — 確保 tools 已註冊（含 dispatch_to_agent）

        # 注入 session 讓 dispatch_to_agent 能帶對話 context
        from ark_bot_agent.llm.tools.dispatch import set_dispatch_session
        set_dispatch_session(session)

        # 建立 ProgressStack
        progress = ProgressStack(update.message.chat_id, context.bot)
        await progress.init("想一下⋯")

        # on_tool_call 回調：更新進度
        async def _on_tool(tool_name: str):
            if tool_name == "dispatch_to_agent":
                await progress.update("找人幫忙中⋯")
            elif tool_name == "search_wiki":
                await progress.update("翻知識庫⋯")
            elif tool_name == "web_search":
                await progress.update("上網查一下⋯")
            elif tool_name == "recall_memory":
                await progress.update("回想一下⋯")

        system_prompt = await build_default_system_prompt(query=text, session=session)
        _chat = get_config().modes.chat
        result = await agent_loop(
            user_message=text,
            system_prompt=system_prompt,
            session_history=None,  # context_builder 已含 history
            max_iterations=_chat.max_iterations,
            on_tool_call=_on_tool,
            # 白名單只在快答模式套用；Path 2 的 Gemini fallback 是 agent 模式，
            # 那條刻意不傳 —— 職人本來就該能用寫入工具。
            allowed_tools=_chat.tools,
        )

        if result.text:
            reply = _clean_output(result.text)
            _targets = [t["args"].get("target_agent", "")
                        for t in result.tool_calls_log if t["tool"] == "dispatch_to_agent"]
            reply = await _attach_report(
                update, reply, mode="chat", agents=[t for t in _targets if t], query=text,
            )
            if len(reply) > 3000:
                reply = reply[-3000:]
            session.add_turn("agent", reply)
            log.info("  ✅ Agent Loop reply (%d chars, %d iterations, %d tools)",
                     len(reply), result.iterations, len(result.tool_calls_log))

            # Trace: 判斷是否有派工
            dispatched = [t for t in result.tool_calls_log if t["tool"] == "dispatch_to_agent"]
            if dispatched:
                target = dispatched[-1]["args"].get("target_agent", "unknown")
                update_trace_decision(trace_id, "派工", target, f"ark→{target}")
            else:
                update_trace_decision(trace_id, "直答", None, "ark")
            complete_trace(trace_id, reply[:80], success=True)

            await progress.complete(reply)
            await _set_reaction(update.message, "👍")
        else:
            update_trace_decision(trace_id, "無回應", None, "ark")
            fail_trace(trace_id, "agent_loop 無回覆")
            await progress.fail("嗯⋯我好像沒接住，再說一次？")
            await _set_reaction(update.message, "👎")

        # ── 對話寫入 daily log ──
        if reply:
            try:
                from ark_bot_agent.memory.daily_log import write_daily_log
                task_id = f"msg-{update.message.message_id}"
                conversation = f"User: {text[:200]}\nAgent: {reply[:500]}"
                asyncio.create_task(write_daily_log("_default", task_id, conversation))
            except Exception as e:
                log.warning("daily_log failed: %s", e)
            try:
                _update_recent(session)
            except Exception:
                pass

    except Exception as e:
        log.error("handle_message error: %s", e)
        fail_trace(trace_id, f"error: {type(e).__name__}")
        await _set_reaction(update.message, "👎")
        await update.message.reply_text("抱歉，我剛剛出了點狀況 😵 你再說一次，我重新處理。")
    finally:
        done.set()
        timer_task.cancel()


# ── Output 清理（三層管線，移植自 ark_team_agent）─────────────────────

from .output_filter import clean_output as _clean_output_impl, extract_final_reply


async def _attach_report(update, text: str, *, mode: str, agents: list[str], query: str) -> str:
    """跑報告管線（MD → HTML → TG 檔案），回傳附上降級說明的文字。

    🔴 **這是 M4 在 TG 上唯一的接點。** `deliver_report` 原本只被
    `ModeRouter._maybe_report()` 呼叫，而 `ModeRouter.route()` 從來沒有呼叫點
    —— TG 走的是本檔自己那套路由，所以報告管線從上線起**一次都沒執行過**
    （`output/reports/` 一年份的檔案全是手動產物）。

    不在這裡重寫一份判斷邏輯 —— 直接借 router 的 `_maybe_report`，
    否則門檻、標題規則、降級訊息會變成兩份各自漂移。
    """
    from ark_bot_agent.bot.router import MessageContext, ModeRouter, Reply

    async def send_document(path, caption: str):
        """TG 送檔 —— 資安限制：只允許 .html/.md 報告檔。"""
        from ark_bot_agent.report.sender import ALLOWED_FILE_TYPES
        from pathlib import Path
        p = Path(path)
        if p.suffix.lower() not in ALLOWED_FILE_TYPES:
            log.warning("⛔ send_document 拒絕傳送非白名單檔案：%s", p.name)
            return None
        with open(path, "rb") as f:
            return await update.message.reply_document(document=f, caption=caption[:1000])

    ctx = MessageContext(text=query, session=None, extra={"send_document": send_document})
    reply = Reply(text=text)
    try:
        out = await ModeRouter()._maybe_report(ctx, reply, mode=mode, agents=agents)
    except Exception as e:                                    # noqa: BLE001
        # 報告失敗**不該讓對話回覆失敗** —— 它是附加產物
        log.error("報告管線失敗（回覆照送）：%s", e)
        return text
    return out.text or text


def _clean_output(raw: str) -> str:
    """三層管線：clean → extract_final_reply。取代舊的單層過濾。"""
    cleaned = _clean_output_impl(raw)
    return extract_final_reply(cleaned)


async def _execute_skill_by_id(skill_id: str, args: str = "") -> str | None:
    """根據 skill_id 直接執行對應 Skill。回傳結果字串或 None（不認識的 skill）。"""
    skill_id = skill_id.lower().strip()

    if skill_id == "news":
        return await _handle_news()

    if skill_id == "summarize":
        if not args:
            return "⚠️ 用法：/summarize <要摘要的文字>"
        try:
            from ark_bot_agent.skills.internal.summarize import SummarizeSkill
            skill = SummarizeSkill()
            result = await skill.execute({"content": args, "max_length": 200})
            if result.success:
                return f"📝 摘要：\n{result.data['summary']}\n\n（原文 {result.data['original_length']} 字）"
            return f"⚠️ {result.error}"
        except Exception as e:
            return f"⚠️ 摘要失敗: {e}"

    if skill_id == "translate":
        if not args:
            return "⚠️ 用法：/translate <要翻譯的文字>"
        try:
            from ark_bot_agent.skills.internal.translate import TranslateSkill
            skill = TranslateSkill()
            # 解析目標語言（預設 en）
            parts = args.rsplit(" to ", 1)
            text_to_translate = parts[0]
            target_lang = parts[1].strip() if len(parts) > 1 else "en"
            result = await skill.execute({"text": text_to_translate, "target_lang": target_lang})
            if result.success:
                return f"🌐 翻譯（→ {result.data['target_lang']}）：\n{result.data['translated']}"
            return f"⚠️ {result.error}"
        except Exception as e:
            return f"⚠️ 翻譯失敗: {e}"

    if skill_id == "wiki":
        if not args:
            return "⚠️ 用法：/wiki <查詢關鍵字>"
        try:
            from ark_bot_agent.wiki.engine import WikiEngine
            engine = WikiEngine()
            result = await engine.query(args, use_rag=True)
            if result.get("answer"):
                return result["answer"]
            elif result.get("results"):
                lines = [f"📚 找到 {len(result['results'])} 筆："]
                for r in result["results"][:5]:
                    lines.append(f"• {r['title']}：{r['snippet'][:80]}")
                return "\n".join(lines)
            return "📚 知識庫中沒有找到相關內容。"
        except Exception as e:
            return f"⚠️ Wiki 查詢失敗: {e}"

    if skill_id == "ingest":
        try:
            from ark_bot_agent.wiki.engine import WikiEngine
            engine = WikiEngine()
            ingested = engine.ingest()
            return f"✅ 匯入完成：{len(ingested)} 篇\n" + "\n".join(f"• {f}" for f in ingested)
        except Exception as e:
            return f"⚠️ Ingest 失敗: {e}"

    return None  # 不認識的 skill_id


# ── Memory Search ─────────────────────────────────────────


def _search_memory(agent_id: str, query: str, max_results: int = 3) -> str | None:
    """搜尋 Agent 的歷史記憶，回傳相關 context 或 None。"""
    from pathlib import Path
    memory_dir = Path(f"agents/{agent_id}-agent/knowledge/raw")
    if not memory_dir.exists():
        return None

    keywords = query.lower().split()
    matches: list[str] = []

    for md in sorted(memory_dir.glob("*.md"), reverse=True)[:20]:  # 最近 20 筆
        content = md.read_text(encoding="utf-8")
        if any(kw in content.lower() for kw in keywords):
            # 提取任務和結果
            lines = content.split("\n")
            task_line = ""
            result_lines: list[str] = []
            in_result = False
            for line in lines:
                if line.startswith("## 任務"):
                    in_result = False
                elif line.startswith("## 結果"):
                    in_result = True
                elif in_result and line.strip():
                    result_lines.append(line)
                elif not in_result and line.strip() and not line.startswith("---") and not line.startswith("user_id"):
                    task_line = line
            if result_lines:
                matches.append(f"[{md.stem}] {task_line}\n{''.join(result_lines[:3])}")

        if len(matches) >= max_results:
            break

    return "\n\n".join(matches) if matches else None


# ── Reaction Helper ───────────────────────────────────────


def _update_recent(session) -> None:
    """將 session 最近 5 輪對話寫入 memory/recent.md，供下次 system prompt 注入。"""
    from pathlib import Path

    recent_path = get_memory_dir() / "recent.md"
    recent_path.parent.mkdir(parents=True, exist_ok=True)

    # 取最近 5 輪
    turns = session.history[-10:]  # 5 輪 = 10 條（user + agent 各一）
    if not turns:
        return

    lines = ["# 最近對話\n"]
    for turn in turns:
        prefix = "👤 User" if turn.role == "user" else "🤖 Agent"
        content = turn.content[:300]
        lines.append(f"{prefix}: {content}\n")

    recent_path.write_text("\n".join(lines), encoding="utf-8")


# ── 自動 consolidate ─────────────────────────────────────

_consolidate_done_today: str = ""  # 記錄今天是否已跑過


async def _auto_consolidate_if_needed() -> None:
    """每天首次對話時，自動蒸餾前一天 daily log → memory.md。"""
    global _consolidate_done_today
    from datetime import datetime, timedelta

    today = datetime.now().strftime("%Y-%m-%d")
    if _consolidate_done_today == today:
        return  # 今天已經跑過

    # 檢查昨天有沒有 daily log
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    yesterday_log = Path(f"memory/daily/{yesterday}.md")
    if not yesterday_log.exists():
        _consolidate_done_today = today
        return  # 昨天沒 log，跳過

    # 非同步執行 consolidate（不阻塞對話）
    try:
        from ark_bot_agent.memory.consolidate import consolidate
        result = await consolidate("_default")
        if result.get("status") == "updated":
            log.info("Auto-consolidate: memory.md updated from %s", yesterday)
        _consolidate_done_today = today
    except Exception as e:
        log.warning("Auto-consolidate failed: %s", e)
        _consolidate_done_today = today  # 避免重複嘗試


async def _set_reaction(message, emoji: str) -> None:
    """設定訊息 Reaction（靜默失敗）。"""
    try:
        from telegram import ReactionTypeEmoji
        await message.set_reaction([ReactionTypeEmoji(emoji=emoji)])
    except Exception:
        pass  # Reaction API 不可用時靜默跳過


async def _keep_action_alive(chat_id: int, action: str, done: asyncio.Event, bot) -> None:
    """持續送 chat action 直到 done 被 set（每 4 秒一次）。"""
    try:
        while not done.is_set():
            await bot.send_chat_action(chat_id=chat_id, action=action)
            try:
                await asyncio.wait_for(done.wait(), timeout=4.0)
            except asyncio.TimeoutError:
                pass
    except (asyncio.CancelledError, Exception):
        pass


# ── Skill 處理 ───────────────────────────────────────────


async def _handle_news() -> str | None:
    """新聞 Skill 快速路徑。"""
    try:
        from ark_bot_agent.skills.internal.news import NewsSkill
        skill = NewsSkill()
        result = await skill.execute({"max_items": 5})
        if result.success:
            lines = [f"📰 *{result.data['source']}* — {result.data['count']} 則\n"]
            for i, art in enumerate(result.data["articles"], 1):
                lines.append(f"{i}. [{art['title']}]({art['url']}) (⬆️{art['score']})")
            return "\n".join(lines)
        return f"⚠️ {result.error}"
    except Exception as e:
        return f"⚠️ 新聞抓取失敗: {e}"


# ── Team Dispatch ────────────────────────────────────────


async def _handle_team_dispatch(text: str, update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | None:
    """團隊派工處理 — 走 A2ARouter.dispatch()。

    由 `bot.yaml` 的 `features.a2a` 決定是否啟用。
    """
    from ark_bot_agent.config import get_config

    if not get_config().features.a2a:
        return "⚠️ A2A 派工未啟用（bot.yaml 的 features.a2a）"

    # 清除關鍵字前綴
    clean_text = text
    for prefix in ("派工", "assign", "分配", "指派", "@pm"):
        clean_text = clean_text.replace(prefix, "").strip()

    if not clean_text:
        return "⚠️ 請描述要派工的任務，例如：`派工 分析老虎機競品數據`"

    try:
        from ark_bot_agent.coordinator.a2a.router import A2ARouter
        from ark_bot_agent.coordinator.a2a.graph import TaskGraph
        from ark_bot_agent.coordinator.a2a.shared_memory import SharedMemory
        from ark_bot_agent.coordinator.a2a.discovery import AgentDiscovery
        from ark_bot_agent.coordinator.a2a.protocol import TaskHandoff
        from datetime import datetime, timezone

        # 組裝 Router（每次重建，讀最新的 profiles）
        graph = TaskGraph()
        memory = SharedMemory()
        discovery = AgentDiscovery(memory)

        # spawn_fn — 本地 Agent 用 agent_cli_chat
        async def _spawn_fn(agent_name: str, message: str) -> str | None:
            from ark_bot_agent.agent.cli import agent_cli_chat
            return (await agent_cli_chat(
                message, agent_id=agent_name.replace("-agent", "")
            )).reply_text()

        router = A2ARouter(graph, memory, discovery, spawn_fn=_spawn_fn)

        # 建立 TaskHandoff
        now = datetime.now(timezone.utc)
        task_id = now.strftime("%Y-%m-%d") + f"_{now.hour:02d}{now.minute:02d}_{clean_text[:20].replace(' ', '-')}"
        handoff = TaskHandoff(
            task_id=task_id,
            from_agent="user",
            to_agent="auto",
            title=clean_text,
            context="",
        )

        # Discovery 匹配
        target = discovery.match(handoff)
        handoff.to_agent = target

        # 通知使用者已派工
        await update.message.reply_text(f"📋 已派工給 *{target}*\n任務：{clean_text[:100]}", parse_mode="Markdown")

        # Dispatch（非同步執行）
        await router.dispatch(handoff)

        # 等結果（從 shared memory 讀）
        task_path = memory.base / "tasks" / f"{task_id}.md"
        if task_path.exists():
            content = task_path.read_text(encoding="utf-8")
            if "## Output" in content:
                output_section = content.split("## Output")[-1].strip()
                return f"✅ {target} 完成：\n\n{output_section[:2000]}"

        return f"⏳ 任務 {task_id} 已提交給 {target}，可用 /board 查看進度"

    except ImportError:
        return "⚠️ coordinator 模組未安裝"
    except Exception as e:
        log.error("Team dispatch error: %s", e)
        return f"⚠️ 派工失敗：{e}"


# ── /assign /board Commands ──────────────────────────────


async def cmd_assign(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/assign <描述> — 派工給團隊 Agent。"""
    text = update.message.text.strip()
    # 移除 /assign 前綴
    task_desc = text[len("/assign"):].strip() if text.startswith("/assign") else text

    if not task_desc:
        await update.message.reply_text(
            "📋 用法：`/assign <任務描述>`\n\n"
            "範例：\n"
            "• `/assign 分析老虎機競品數據`\n"
            "• `/assign review 主迴圈 performance`",
            parse_mode="Markdown",
        )
        return

    reply = await _handle_team_dispatch(f"派工 {task_desc}", update, context)
    if reply:
        # _handle_team_dispatch 已經回覆了中間訊息，這裡只處理最終結果
        if not reply.startswith("📋"):  # 避免重複
            await update.message.reply_text(reply)


async def cmd_board(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/board — 查看任務看板。"""
    from pathlib import Path

    tasks_dir = get_shared_tasks_dir()
    if not tasks_dir.exists() or not list(tasks_dir.glob("*.md")):
        await update.message.reply_text("📋 任務看板為空\n\n使用 `/assign <描述>` 派工", parse_mode="Markdown")
        return

    lines = ["📋 *任務看板*\n"]
    status_emoji = {
        "pending": "⏳",
        "running": "🔄",
        "completed": "✅",
        "failed": "❌",
    }

    tasks = sorted(tasks_dir.glob("*.md"), reverse=True)[:10]  # 最近 10 筆
    for task_file in tasks:
        content = task_file.read_text(encoding="utf-8")
        # 解析 frontmatter
        status = "pending"
        assignee = ""
        title = task_file.stem
        for line in content.splitlines():
            if line.startswith("status:"):
                status = line.split(":", 1)[1].strip()
            elif line.startswith("assigned_to:"):
                assignee = line.split(":", 1)[1].strip()
            elif line.startswith("# "):
                title = line[2:].strip()

        emoji = status_emoji.get(status, "❓")
        assignee_str = f" → {assignee}" if assignee else ""
        lines.append(f"{emoji} {title[:40]}{assignee_str}")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
