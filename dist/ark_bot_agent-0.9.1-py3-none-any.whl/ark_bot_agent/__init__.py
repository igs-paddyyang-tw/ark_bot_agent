"""ark_bot_agent —— 個體模式 AI Agent Bot 框架。

## 定位

| 套件 | 模式 | 一句話 |
|------|------|--------|
| `ark_team_agent` | **團隊** | 多 agent 常駐、群組 topic 路由、決策矩陣 |
| **`ark_bot_agent`（本套件）** | **個體** | 單一 Bot + 三種對話模式 + 選擇性派工 |

**兩者互不依賴，也不合併** —— 定位不同。

## 三種對話模式

模式由使用者在 TG 選（`/agents` 面板），**不靠 AI 猜** ——
同一句話在不同模式下該有不同的處理成本，讓人決定比讓模型判斷準確。

| 模式 | 引擎 | 能力來源 |
|------|------|---------|
| 💬 Chat | Gemini ReAct loop | 外部 web + 內部 wiki，需要時才派單一 agent |
| 👑 管家 | `admin-agent` on kiro-cli | 全靠 agent 本身 + 提詞 + skill + wiki + memory |
| ⚔️ Team | `leader-agent` + Python 工作流 | 意圖分析 → 建工作流 → 彙整回報 |

三種模式的分析產出**一律** MD（給 AI）→ HTML（給人）→ TG。

## 用法

零 code（設定檔 + agent 提詞驅動）：

    from ark_bot_agent import run_bot
    run_bot()

需要注入自訂邏輯時：

    from ark_bot_agent import create_bot
    bot = create_bot(router=MyRouter(), skills=["skills"])
    bot.run()

消費端需要的檔案（**設定檔各自單一職責，不合併**）：

| 檔案 | 職責 |
|------|------|
| `agents.yaml` | agent 定義（誰、代號、工作目錄、可否派工、`group_members`）**← 專案根哨兵** |
| `bot.yaml` | Bot 層設定（server / modes / llm / backend / report / features） |
| `scheduler.yaml` | 排程（選用） |
| `.env` | **只放機密**（TG token / API key） |
| `agents/*/` | 各 agent 的提詞（`.kiro/steering/`） |
| `knowledge/` | 知識庫 |
"""
from __future__ import annotations

__version__ = "0.9.1"

from ark_bot_agent import paths
from ark_bot_agent.config import BotConfig, get_config
from ark_bot_agent.paths import get_home
from ark_bot_agent.runner import Bot, create_bot, run_bot

__all__ = [
    "__version__",
    "Bot",
    "BotConfig",
    "create_bot",
    "get_config",
    "get_home",
    "paths",
    "run_bot",
]
