"""Telegram handlers for memory commands: /recall, /skills, /consolidate + 審批 callback。"""
from __future__ import annotations

import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

log = logging.getLogger(__name__)

# 🔴 **這裡刻意沒有自己的白名單。**
#
# v0.9.0 前是：
#     ADMIN_CHAT_IDS: set[int] = set()
#     _admin_env = os.getenv("ADMIN_CHAT_IDS", "")      # ← 只讀環境變數
#
# 那是 **0.6.0 修過的缺陷的孿生兄弟**（當時修的是 `handlers._ALLOWED_USERS`）：
# 它從不讀 `bot.yaml`，所以實測
#
#     bot.yaml  access.admin_chat_ids  = [937896656]
#     access（0.6.0 修好的那條路）      = [937896656]   ✅
#     tg_handlers.ADMIN_CHAT_IDS        = set()         ❌
#
# 而三個使用點都是「空集合 = 放行」→ `/recall` `/skills` `/consolidate`
# 與**審批 callback** 對所有人開放，且 `send_approval_card` 永遠送不出去。
# **設了白名單卻沒生效，而且看起來生效了。**
#
# 白名單的唯一來源是 `access.get_access()`（它讀 `bot.yaml` + env 疊加）。


def _get_current_agent(context: ContextTypes.DEFAULT_TYPE) -> str:
    """取得使用者目前選擇的 Agent（支援 Default 模式）。"""
    from ark_bot_agent.agent.session import session_manager
    user_id = context._user_id if hasattr(context, '_user_id') else None
    if user_id:
        session = session_manager.get_or_create(user_id)
        if session.is_default_mode:
            return "_default"
        return (session.agent_name or "admin") + "-agent"
    agent = context.user_data.get("current_agent", "default")
    if agent == "default":
        return "_default"
    return agent + "-agent"


async def _require_auth(update: Update) -> bool:
    """白名單檢查（`/recall` `/skills` `/consolidate`）。

    用 `is_allowed()` 而不是 `is_admin()` —— **刻意維持既有語意**：
    空白名單 = 不限制（開發模式）。這三個指令是查詢／整理自己的記憶，
    不是特權操作，收緊它會改變現有部署行為而沒有對應的風險。
    （審批 callback 不同 —— 見 `callback_skill_approval`。）
    """
    from ark_bot_agent.access import get_access
    user_id = update.effective_user.id
    if get_access().is_allowed(user_id):
        return True
    await update.message.reply_text(
        f"🔒 需要權限。\n\nChat ID：`{user_id}`",
        parse_mode="Markdown",
    )
    return False


# ─── /recall ───

async def cmd_recall(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """查詢 memory FTS5 索引。用法：/recall <query>"""
    if not await _require_auth(update):
        return
    if not context.args:
        await update.message.reply_text("用法：`/recall <查詢關鍵詞>`", parse_mode="Markdown")
        return

    query = " ".join(context.args)
    agent = _get_current_agent(context)

    from ark_bot_agent.memory.recall import recall
    results = recall(agent=agent, query=query, k=5)

    if not results:
        await update.message.reply_text(f"🔍 查無結果：`{query}`", parse_mode="Markdown")
        return

    lines = [f"🔍 **recall** `{query}` ({agent}):\n"]
    for i, r in enumerate(results, 1):
        source_emoji = {"daily": "📅", "memory": "🧠", "wiki": "📚", "skill": "⚙️"}.get(r.source, "📄")
        lines.append(f"{i}. {source_emoji} **{r.title}** ({r.date})")
        lines.append(f"   {r.body[:100]}...")
        lines.append(f"   score: {r.score:.3f}\n")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ─── /skills ───

async def cmd_skills(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """列出 skills。用法：/skills [pending]"""
    if not await _require_auth(update):
        return
    sub = context.args[0] if context.args else ""

    if sub == "pending":
        from ark_bot_agent.memory.skill_manage import list_pending
        pending = list_pending()
        if not pending:
            await update.message.reply_text("✅ 無待審提案")
            return
        lines = ["📋 **待審提案**:\n"]
        for p in pending:
            lines.append(f"• `{p['id']}` [{p['agent']}] {p['skill_name']}")
            lines.append(f"  📎 {p['gist'][:60]}")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        return

    agent = _get_current_agent(context)
    from ark_bot_agent.memory.skill_manage import list_skills
    skills = list_skills(agent)

    if not skills:
        await update.message.reply_text(f"⚙️ {agent} 尚無 skills")
        return

    lines = [f"⚙️ **{agent} Skills**:\n"]
    for s in skills:
        origin_mark = "🤖" if s["origin"] == "auto" else "👤"
        lines.append(f"• {origin_mark} `{s['name']}` v{s['version']}")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ─── /consolidate ───

async def cmd_consolidate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """手動觸發 daily → memory.md 蒸餾。"""
    if not await _require_auth(update):
        return
    agent = _get_current_agent(context)
    await update.message.reply_text(f"🧠 正在蒸餾 {agent} 的記憶...")

    from ark_bot_agent.memory.consolidate import consolidate
    result = await consolidate(agent)

    status = result.get("status", "unknown")
    if status == "updated":
        msg = f"✅ {agent} memory.md 已更新\n📏 {result['old_size']} → {result['new_size']} chars"
    elif status == "no_change":
        msg = f"ℹ️ {agent} 無新的持久事實"
    elif status == "no_data":
        msg = f"⚠️ {agent} 近 7 天無 daily log"
    else:
        msg = f"❌ 蒸餾失敗：{result.get('message', '')}"

    await update.message.reply_text(msg)


# ─── 審批推送 ───

async def send_approval_card(
    bot,
    proposal: dict,
    chat_id: int | None = None,
) -> None:
    """推送審批卡片到管理者。"""
    if chat_id is None:
        from ark_bot_agent.access import get_access
        admins = get_access().admin_ids()
        if not admins:
            log.warning("沒有任何 admin 等級的使用者，審批卡片無法送出 —— "
                        "請設 bot.yaml 的 access.admin_chat_ids")
            return
        chat_id = admins[0]

    text = (
        f"🧩 **Skill 推薦** `{proposal['id']}` [{proposal['agent']}]\n"
        f"**{proposal['skill_name']}**\n\n"
        f"📎 {proposal['gist'][:200]}\n"
        f"📊 來源：{proposal.get('source_task', 'unknown')}\n"
        f"⏰ {proposal['created']}"
    )

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ 核准", callback_data=f"skill_approve:{proposal['id']}"),
            InlineKeyboardButton("❌ 駁回", callback_data=f"skill_reject:{proposal['id']}"),
        ],
    ])

    await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=keyboard,
        parse_mode="Markdown",
    )


# ─── 審批 Callback ───

async def callback_skill_approval(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """處理審批 Inline Button callback。"""
    query = update.callback_query
    await query.answer()

    # 驗證管理者白名單
    #
    # 🔴 **這裡用 `is_admin()`，空白名單時擋下 —— 這是 v0.9.0 刻意的行為改變。**
    # 舊寫法是 `if ADMIN_CHAT_IDS and user_id not in ADMIN_CHAT_IDS`，
    # 空集合就放行，而核准 skill 等於把程式碼裝進 agent。
    # 「空白名單 = 任何人都能核准」不是有人刻意依賴的行為，是碰巧存在的缺陷。
    from ark_bot_agent.access import get_access
    acc = get_access()
    user_id = query.from_user.id
    if not acc.is_admin(user_id):
        hint = ("⛔ 你沒有審批權限"
                if not acc.is_empty() else
                "⛔ 尚未設定管理者 —— 請在 bot.yaml 的 access.admin_chat_ids 加入你的 chat id")
        await query.edit_message_text(hint)
        return

    data = query.data  # format: "skill_approve:{id}" or "skill_reject:{id}"
    parts = data.split(":")
    if len(parts) != 2:
        return

    action, proposal_id = parts

    if action == "skill_approve":
        from ark_bot_agent.memory.skill_manage import approve
        result = approve(proposal_id)
        if result.get("status") == "approved":
            await query.edit_message_text(
                f"✅ 已核准 `{proposal_id}`\n📁 {result.get('skill_path', '')}",
                parse_mode="Markdown",
            )
        else:
            await query.edit_message_text(f"❌ 核准失敗：{result.get('message', '')}")

    elif action == "skill_reject":
        from ark_bot_agent.memory.skill_manage import reject
        result = reject(proposal_id, reason="TG 按鈕駁回")
        await query.edit_message_text(f"❌ 已駁回 `{proposal_id}`", parse_mode="Markdown")
