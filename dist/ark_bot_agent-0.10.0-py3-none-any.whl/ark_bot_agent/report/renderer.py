"""報告的 **HTML 軌** —— 給人看的渲染視圖。

## 三條規則

1. **MD 是 source of truth** —— 這裡只做格式轉換，
   **禁止新增 MD 沒有的結論**（spec R-2）
2. HTML 產生失敗**不影響 MD**（spec R-4）—— 所以這裡只回 `None`，不拋例外
3. 自帶樣式、不引外部資源 —— 報告會被下載到手機看，載不到 CDN 就會變成裸文字
"""
from __future__ import annotations

import html
import logging
import re
from pathlib import Path

log = logging.getLogger(__name__)

_FRONTMATTER = re.compile(r"^---\n.*?\n---\n", re.S)

# 暗色優先、支援 light 的最小樣式集。刻意不用 CDN（見上方規則 3）。
_CSS = """
:root {
  --bg: #0f1419; --fg: #e6e6e6; --dim: #9aa4b2; --line: #2a3441;
  --accent: #58a6ff; --code-bg: #161b22; --quote: #f0b429;
}
@media (prefers-color-scheme: light) {
  :root {
    --bg: #ffffff; --fg: #1f2328; --dim: #656d76; --line: #d0d7de;
    --accent: #0969da; --code-bg: #f6f8fa; --quote: #9a6700;
  }
}
* { box-sizing: border-box; }
body {
  margin: 0; padding: 2rem 1.25rem 4rem; background: var(--bg); color: var(--fg);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft JhengHei",
               "PingFang TC", "Noto Sans TC", sans-serif;
  line-height: 1.75; font-size: 16px;
}
main { max-width: 46rem; margin: 0 auto; }
h1, h2, h3 { line-height: 1.3; margin: 2rem 0 .75rem; }
h1 { font-size: 1.7rem; border-bottom: 2px solid var(--line); padding-bottom: .5rem; }
h2 { font-size: 1.3rem; color: var(--accent); }
h3 { font-size: 1.1rem; }
p, li { margin: .5rem 0; }
a { color: var(--accent); }
code {
  background: var(--code-bg); padding: .15em .4em; border-radius: 4px;
  font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace; font-size: .9em;
}
pre { background: var(--code-bg); padding: 1rem; border-radius: 8px; overflow-x: auto; }
pre code { background: none; padding: 0; }
blockquote {
  margin: 1rem 0; padding: .5rem 1rem; border-left: 3px solid var(--quote);
  background: var(--code-bg); color: var(--dim);
}
table { border-collapse: collapse; width: 100%; margin: 1rem 0; display: block; overflow-x: auto; }
th, td { border: 1px solid var(--line); padding: .5rem .75rem; text-align: left; }
th { background: var(--code-bg); }
hr { border: none; border-top: 1px solid var(--line); margin: 2rem 0; }
.meta { color: var(--dim); font-size: .85rem; margin-bottom: 2rem; }
"""

_PAGE = """<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>{css}</style>
</head>
<body>
<main>
<div class="meta">{meta}</div>
{body}
</main>
</body>
</html>
"""


def strip_frontmatter(md: str) -> str:
    """移除 frontmatter —— 那是給 AI 的中介資料，不該出現在給人看的頁面。"""
    return _FRONTMATTER.sub("", md, count=1)


def _md_to_html(md: str) -> str:
    """MD → HTML body。

    優先用 `markdown` 套件（`[skills]` extra）；缺少時降級為
    `<pre>` 包原文 —— **降級要看得出來是降級**，不要假裝渲染成功。
    """
    try:
        import markdown
    except ImportError:
        log.warning("未安裝 markdown 套件（pip install 'ark-bot-agent[skills]'），HTML 降級為純文字")
        return (
            '<blockquote>⚠️ 未安裝 <code>markdown</code> 套件，'
            "以下為未渲染的原文。</blockquote>\n"
            f"<pre>{html.escape(md)}</pre>"
        )
    return markdown.markdown(
        md,
        extensions=["tables", "fenced_code", "toc", "nl2br", "sane_lists"],
        output_format="html",
    )


def render_html(md_path: Path, *, source: str = "", out_path: Path | None = None) -> Path | None:
    """把 MD 檔渲染成同名 `.html`，回傳路徑；**失敗回 `None` 不拋例外**。

    Args:
        md_path: MD 檔（source of truth）
        source: 頁尾標註的來源（例如 `nana-bot · team 模式`）
        out_path: 預設同目錄同名 `.html`

    呼叫端拿到 `None` 時應該補一句「報告頁產生失敗，內容見 …md」——
    **MD 已經寫成功了，不要因為渲染失敗就當整件事失敗**（spec R-4）。
    """
    try:
        md = md_path.read_text(encoding="utf-8")
        body_md = strip_frontmatter(md)
        # 標題取 MD 的第一個 H1；沒有就用檔名
        m = re.search(r"^#\s+(.+)$", body_md, re.M)
        title = m.group(1).strip() if m else md_path.stem

        meta_bits = [md_path.name]
        if source:
            meta_bits.append(source)
        page = _PAGE.format(
            title=html.escape(title),
            css=_CSS,
            meta=html.escape(" ｜ ".join(meta_bits)),
            body=_md_to_html(body_md),
        )
        target = out_path or md_path.with_suffix(".html")
        target.write_text(page, encoding="utf-8")
        log.info("報告 HTML 已渲染 %s（%d 字）", target.name, len(page))
        return target
    except Exception as e:                     # noqa: BLE001 —— 渲染失敗不得中斷主流程
        log.error("HTML 渲染失敗（MD 仍完好）：%s: %s", type(e).__name__, e)
        return None


__all__ = ["render_html", "strip_frontmatter"]
