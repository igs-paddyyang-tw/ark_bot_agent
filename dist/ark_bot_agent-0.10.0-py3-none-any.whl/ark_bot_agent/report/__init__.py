"""MD-first 報告管線 —— **三種模式共用**。

    ① write_md()      產 MD（給 AI／知識庫／下游 agent）← source of truth
    ② render_html()   渲染 HTML（給人看）
    ③ send_report()   送 TG

## 為什麼獨立成模組

三個模式（chat / agent / team）都要產報告。放在任一模式裡都會變成跨模組 import，
而且「HTML 失敗不影響 MD」這條失敗策略會被寫三次 —— 寫三次就會有一次寫錯。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from ark_bot_agent.report.renderer import render_html, strip_frontmatter
from ark_bot_agent.report.sender import DocumentSender, send_report
from ark_bot_agent.report.writer import ReportMeta, slugify, write_md

log = logging.getLogger(__name__)


@dataclass
class ReportResult:
    """管線結果。`md` 一定有值（它是 source of truth）。"""

    md: Path
    html: Path | None = None
    sent: bool = False

    @property
    def degraded(self) -> bool:
        """是否有任何一步沒完成 —— 呼叫端要據此決定回覆文案。"""
        return self.html is None or not self.sent

    def user_note(self) -> str:
        """給使用者的一句補充說明（沒問題時回空字串）。

        **降級要講出來** —— 使用者以為收到報告了，實際只有 MD 在磁碟上，
        那比直接說「渲染失敗」更糟。
        """
        if self.html is None:
            return f"⚠️ 報告頁產生失敗，內容見 `{self.md.name}`"
        if not self.sent:
            return f"⚠️ 報告已產出但沒送成功，檔案在 `{self.html.name}`"
        return ""


async def deliver_report(
    *,
    title: str,
    body: str,
    mode: str,
    out_dir: Path,
    agents: list[str] | None = None,
    tags: list[str] | None = None,
    send: DocumentSender | None = None,
    render: bool = True,
    day: date | None = None,
) -> ReportResult:
    """跑完整管線。**任一步失敗都不讓前面的成果白費。**

    Args:
        title: 報告標題（也用來組檔名）
        body: MD 正文（不含 frontmatter 與 H1，那兩者由 writer 補）
        mode: `chat` / `agent` / `team` —— 寫進 frontmatter 的 `source_mode`
        out_dir: 輸出目錄（通常是 `BotConfig.report_dir`）
        agents: 參與的 agent id
        send: 送檔函式；`None` 表示不送
        render: `False` 表示只產 MD

    Raises:
        OSError: **只有 MD 寫入失敗才拋** —— 那代表整件事失敗（沒有 source of truth）。
            HTML 與送檔失敗都只反映在 `ReportResult`。
    """
    meta = ReportMeta(
        title=title, source_mode=mode, agents=agents or [], tags=tags or [], day=day
    )
    md = write_md(meta, body, out_dir=out_dir, day=day)      # 失敗就讓它拋

    html = render_html(md, source=f"{mode} 模式") if render else None
    sent = await send_report(send, html_path=html, md_path=md, caption=title)

    result = ReportResult(md=md, html=html, sent=sent)
    if result.degraded:
        log.warning("報告管線降級：html=%s sent=%s", html is not None, sent)
    return result


__all__ = [
    "DocumentSender",
    "ReportMeta",
    "ReportResult",
    "deliver_report",
    "render_html",
    "send_report",
    "slugify",
    "strip_frontmatter",
    "write_md",
]
