"""報告的 **TG 軌** —— 把 HTML（或 MD）送到使用者手上。

失敗時回 `False` 讓呼叫端降級成文字回覆 —— **不拋例外**。
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Protocol

log = logging.getLogger(__name__)

# TG 單檔上限 50 MB，但報告遠不會到；設 20 MB 當防呆
_MAX_BYTES = 20 * 1024 * 1024

# 資安白名單：只允許傳送整理過的報告格式（預設開啟）
# 消費端可透過 bot.yaml 的 report.allowed_file_types 覆蓋
ALLOWED_FILE_TYPES: set[str] = {".html", ".md"}


class DocumentSender(Protocol):
    """送檔的最小介面。

    刻意用 Protocol 而不是直接吃 `telegram.Message` ——
    套件不該綁定呼叫端怎麼拿到 chat context，測試也才好 mock。
    """

    async def __call__(self, path: Path, caption: str) -> Any: ...


async def send_report(
    send: DocumentSender | None,
    *,
    html_path: Path | None,
    md_path: Path,
    caption: str = "",
    allowed_types: set[str] | None = None,
) -> bool:
    """送報告檔。優先送 HTML（給人看），沒有就送 MD。

    安全限制：只允許白名單內的檔案類型通過（預設 .html + .md）。
    消費端可透過 `allowed_types` 參數覆蓋白名單。

    Returns:
        `True` 已送出；`False` 沒送出（沒有 sender／檔案過大／送出失敗／類型不允許）。
        回 `False` 時呼叫端應改用文字回覆，並附上檔案路徑。
    """
    if send is None:
        log.info("沒有提供 sender，跳過 TG 送檔")
        return False

    target = html_path or md_path
    if not target.is_file():
        log.error("要送的檔案不存在：%s", target)
        return False

    # 資安守門：只允許白名單類型
    whitelist = allowed_types if allowed_types is not None else ALLOWED_FILE_TYPES
    suffix = target.suffix.lower()
    if suffix not in whitelist:
        log.warning("⛔ 檔案類型 '%s' 不在白名單 %s，拒絕傳送：%s", suffix, whitelist, target.name)
        return False

    size = target.stat().st_size
    if size > _MAX_BYTES:
        log.error("檔案過大不送（%.1f MB）：%s", size / 1048576, target.name)
        return False

    try:
        await send(target, caption or target.stem)
    except Exception as e:                     # noqa: BLE001 —— 送檔失敗不得中斷主流程
        log.error("TG 送檔失敗：%s: %s", type(e).__name__, e)
        return False
    log.info("報告已送出 %s（%.1f KB）", target.name, size / 1024)
    return True


__all__ = ["DocumentSender", "send_report"]
