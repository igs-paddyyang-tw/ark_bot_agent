"""報告的 **MD 軌** —— source of truth。

MD 先寫成功才算成功；HTML 只是渲染視圖（見 `renderer.py`）。
frontmatter 是給下游消費的契約：AI／知識庫／`ark-md-report` skill 都靠它判斷內容性質。
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

log = logging.getLogger(__name__)

# 檔名用的 slug：保留中英數與連字號，其餘換成 `-`
_SLUG_STRIP = re.compile(r"[^\w一-鿿-]+")


@dataclass
class ReportMeta:
    """frontmatter 契約（design ADR-005）。"""

    title: str
    source_mode: str                       # chat | agent | team
    agents: list[str] = field(default_factory=list)
    type: str = "report"
    audience: str = "ai"                   # MD 是給 AI 看的
    render: str = "html"
    tags: list[str] = field(default_factory=list)
    day: date | None = None                # 測試可注入；None = 由呼叫端給

    def to_frontmatter(self) -> str:
        """組出 YAML frontmatter。

        手寫而不用 `yaml.safe_dump` —— 這裡要固定欄位順序（讓 diff 好讀），
        而 dump 的排序與引號規則不受控。值都是自己產的，沒有注入風險。
        """
        d = (self.day or date.today()).isoformat()
        lines = [
            "---",
            f"type: {self.type}",
            f'title: "{self.title}"',
            f"date: {d}",
            f"source_mode: {self.source_mode}",
            f"agents: [{', '.join(self.agents)}]",
            f"tags: [{', '.join(self.tags)}]",
            f"audience: {self.audience}",
            f"render: {self.render}",
            "---",
        ]
        return "\n".join(lines)


def slugify(text: str, *, max_len: int = 40) -> str:
    """把標題轉成檔名可用的 slug（保留中文）。"""
    s = _SLUG_STRIP.sub("-", text.strip()).strip("-")
    return (s[:max_len].rstrip("-") or "report")


def write_md(
    meta: ReportMeta, body: str, *, out_dir: Path, day: date | None = None
) -> Path:
    """寫 MD 檔，回傳路徑。

    檔名 `{YYYY-MM-DD}-{slug}.md`。同名時加序號 —— **不覆蓋**，
    同一天同主題產兩份報告是正常的（例如重跑），覆蓋會讓前一份無聲消失。
    """
    d = day or meta.day or date.today()
    out_dir.mkdir(parents=True, exist_ok=True)

    base = f"{d.isoformat()}-{slugify(meta.title)}"
    path = out_dir / f"{base}.md"
    n = 2
    while path.exists():
        path = out_dir / f"{base}-{n}.md"
        n += 1

    content = f"{ReportMeta(**{**meta.__dict__, 'day': d}).to_frontmatter()}\n\n# {meta.title}\n\n{body.strip()}\n"
    path.write_text(content, encoding="utf-8")
    log.info("報告 MD 已寫入 %s（%d 字）", path.name, len(content))
    return path


__all__ = ["ReportMeta", "slugify", "write_md"]
