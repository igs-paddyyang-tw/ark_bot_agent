"""`python -m ark_bot_agent` 入口。"""
from __future__ import annotations

import sys


def main() -> int:
    """CLI 入口。M1 階段只提供 `paths` 診斷子命令。"""
    from ark_bot_agent import __version__, paths

    argv = sys.argv[1:]
    if argv and argv[0] == "paths":
        print(f"ark_bot_agent {__version__}")
        print(f"  home            {paths.get_home()}")
        print("  設定檔：")
        for name, exists in paths.config_status().items():
            need = "必要" if name == paths.SENTINEL else "選用"
            mark = "✅" if exists else ("🔴" if need == "必要" else "⬚")
            print(f"    {mark} {name:16} ({need})")
        for name in ("state", "data", "logs", "knowledge", "agents", "memory"):
            print(f"  {name:15} {getattr(paths, f'get_{name}_dir')()}")
        print(f"  {'templates':15} {paths.get_templates_dir()}")
        print(f"  {'steering':15} {paths.get_steering()}")
        return 0

    print(f"ark_bot_agent {__version__}")
    print("用法：python -m ark_bot_agent paths    # 檢查路徑解析結果")
    return 0


if __name__ == "__main__":
    sys.exit(main())
