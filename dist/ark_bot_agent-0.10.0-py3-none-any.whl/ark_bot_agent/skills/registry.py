"""SkillRegistry — 註冊、查詢、執行 Skills。"""
from __future__ import annotations

import importlib
import logging
import pkgutil
import sys
from .base import BaseSkill, SkillResult

logger = logging.getLogger(__name__)


class SkillRegistry:
    """Skill 註冊表：auto_discover + invoke + hot_reload。"""

    def __init__(self) -> None:
        self._skills: dict[str, BaseSkill] = {}
        self._packages: list[str] = []
        self._origin: dict[str, str] = {}          # skill_id → 來源套件

    def register(self, skill: BaseSkill, *, origin: str = "") -> None:
        self._skills[skill.skill_id] = skill
        if origin:
            self._origin[skill.skill_id] = origin

    def count_in(self, package_name: str) -> int:
        """來自指定套件的 skill 數。"""
        return sum(1 for p in self._origin.values() if p == package_name)

    def get(self, skill_id: str) -> BaseSkill | None:
        return self._skills.get(skill_id)

    def list_skills(self) -> list[dict]:
        return [{"skill_id": s.skill_id, "description": s.description, "version": s.version} for s in self._skills.values()]

    async def invoke(self, skill_id: str, params: dict) -> SkillResult:
        """執行 Skill，統一錯誤處理。"""
        skill = self.get(skill_id)
        if not skill:
            return SkillResult(success=False, error=f"Skill not found: {skill_id}")
        if not skill.validate_params(params):
            return SkillResult(success=False, error=f"Invalid params: {skill_id}")
        try:
            return await skill.execute(params)
        except Exception as e:
            return SkillResult(success=False, error=str(e))

    def auto_discover(self, package_name: str) -> int:
        """掃描套件下所有 BaseSkill 子類別並註冊。

        ⚠️ import 不到只回 0 是刻意的（消費端沒放 skill 套件是正常狀態），
        但**一定要留 log** —— 之前這裡靜默 return 0，於是套件化後
        `"src.skills.internal"` 這個已不存在的路徑讓 5 個呼叫點全數拿到空表，
        而沒有任何一行訊息指出原因。
        """
        count = 0
        try:
            pkg = importlib.import_module(package_name)
        except ImportError as e:
            logger.info("skill 套件 %s 不存在，略過（%s）", package_name, e)
            self._packages.append(package_name)
            return 0
        self._packages.append(package_name)
        for _, module_name, _ in pkgutil.iter_modules(pkg.__path__):
            try:
                mod = importlib.import_module(f"{package_name}.{module_name}")
                for attr_name in dir(mod):
                    attr = getattr(mod, attr_name)
                    if (isinstance(attr, type) and issubclass(attr, BaseSkill)
                            and attr is not BaseSkill and attr.skill_id):
                        self.register(attr(), origin=package_name)
                        count += 1
            except Exception as e:
                logger.warning("載入 %s 失敗: %s", module_name, e)
        return count

    def hot_reload(self, skill_id: str) -> bool:
        """動態重新載入指定 Skill。

        依 `packages()` 逐個套件找，而**不是猜 module 路徑** ——
        舊版寫死 `src.skills.internal.{id}`，套件化後那個 module 根本不存在，
        於是這個函式永遠回 `False` 且不留任何訊息。
        """
        for pkg in self.packages() or [INTERNAL_PACKAGE]:
            module_name = f"{pkg}.{skill_id}"
            sys.modules.pop(module_name, None)
            try:
                mod = importlib.import_module(module_name)
            except ImportError:
                continue
            for attr_name in dir(mod):
                attr = getattr(mod, attr_name)
                if (isinstance(attr, type) and issubclass(attr, BaseSkill)
                        and attr is not BaseSkill and attr.skill_id):
                    self.register(attr())
                    return True
        return False

    def packages(self) -> list[str]:
        """已 `auto_discover` 過的套件名（依加入順序）。"""
        return list(self._packages)


# ══════════════════════════════════════════════════════════════════
# 共用 registry
#
# 🔴 為什麼需要這個：原本每個呼叫點各自 `SkillRegistry()` 再 discover 一次，
#    於是 `create_bot(skills=[...])` 注入的消費端 skill **只進得了 runner 那份**，
#    server 與提詞組裝那幾份看不到 —— agent 因此從來不知道自己有哪些技能。
#    註冊表是全域事實，不該一個呼叫點一份。
# ══════════════════════════════════════════════════════════════════

INTERNAL_PACKAGE = "ark_bot_agent.skills.internal"

_shared: SkillRegistry | None = None
_extra_packages: list[str] = []


def register_package(package_name: str) -> None:
    """登記一個要掃的 skill 套件（消費端注入用）。

    可在 `get_registry()` 之後才呼叫 —— 下次取用時會補掃。
    """
    if package_name not in _extra_packages:
        _extra_packages.append(package_name)


def get_registry() -> SkillRegistry:
    """取得共用 registry（內建 skill + 已登記的消費端套件）。"""
    global _shared
    if _shared is None:
        _shared = SkillRegistry()
    for pkg in [INTERNAL_PACKAGE, *_extra_packages]:
        if pkg not in _shared._packages:
            _shared.auto_discover(pkg)
    return _shared
