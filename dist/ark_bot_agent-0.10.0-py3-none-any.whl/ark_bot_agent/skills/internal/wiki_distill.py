"""wiki_distill — 用 kiro-cli 將 `knowledge/shared/raw/` 蒸餾為
`knowledge/shared/wiki/` 結構化頁面。

⚠️ 路徑**同時出現在常數與 prompt 裡** —— prompt 直接指示模型寫去哪，
所以只改常數沒有用（0.7.1 修正時兩處都少了 `shared`）。
這是「同一事實寫兩處」的變體：**其中一處是給模型看的自然語言。**
"""
from __future__ import annotations

import asyncio
import os
import subprocess
from datetime import datetime
from pathlib import Path

from ark_bot_agent.paths import get_knowledge_dir, get_shared_wiki_dir
from ark_bot_agent.skills.base import BaseSkill, SkillParam, SkillResult, SkillType

# 🔴 [0.7.1] 原本是 `get_knowledge_dir() / "wiki"` —— **少了 `shared`**。
#     引擎的索引與搜尋讀 `knowledge/shared/wiki`（21 篇），
#     而蒸餾把產出寫進 `knowledge/wiki`（1 篇）→
#     **蒸餾出來的知識永遠不會被索引，也搜不到**，而且不拋例外不寫 log。
#     這是「少一層目錄」的第四個實例，所以改走 `paths` 的正規存取器。
#
#     同時刪掉 `_RAW_DIR` / `_LOG_PATH` / `_INDEX_PATH` —— 那三個**從未被引用**
#     （純死碼），而且它們的路徑同樣少了 `shared`，留著只會被人照抄。
_WIKI_DIR = get_shared_wiki_dir()

_DISTILL_PROMPT = """你是知識庫管理員。請閱讀 knowledge/shared/raw/ 目錄下的所有 .md 檔案，
將內容蒸餾為結構化 wiki 頁面，存放到 knowledge/shared/wiki/ 對應子目錄。

規則：
1. 每個 wiki 頁面必須有 frontmatter：title/type/tags/created/updated/status/sources
2. 去除時間戳、過程細節、重複內容，只保留核心知識
3. 同主題的多個 raw 檔合併為一頁
4. 分類目錄：operations/（操作）、research/（調研）、patterns/（設計模式）、decisions/（決策）
5. 用 [[page_name]] 雙向連結相關頁面
6. 完成後更新 knowledge/shared/index.md（頁面目錄表格）
7. 在 knowledge/shared/log.md 末尾追加一行：- [distill] YYYY-MM-DD 蒸餾 N 頁

現在請執行蒸餾，讀取 raw/ 下的檔案並產出 wiki/ 頁面。"""


class WikiDistillParams(SkillParam):
    timeout: int = 300


class WikiDistillSkill(BaseSkill):
    skill_id = "wiki_distill"
    skill_type = SkillType.PYTHON
    description = "用 kiro-cli 蒸餾 knowledge/shared/raw/ 為結構化 wiki 頁面（每日排程）"
    version = "1.0.0"
    input_schema = WikiDistillParams

    async def execute(self, params: dict) -> SkillResult:
        try:
            p = WikiDistillParams(**params)
            # 確保目錄存在
            _WIKI_DIR.mkdir(parents=True, exist_ok=True)

            # 用 kiro-cli 執行蒸餾
            cmd_path = os.getenv("KIRO_CLI_CMD", "kiro-cli")
            cwd = os.getenv("AI_BOT_WORKSPACE", str(Path.home()))

            cmd = subprocess.list2cmdline([
                cmd_path, "chat", "--no-interactive", "-a", "--wrap", "never",
                _DISTILL_PROMPT,
            ])

            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=p.timeout)
            out = stdout.decode("utf-8").strip() if stdout else ""
            err = stderr.decode("utf-8").strip() if stderr else ""

            if process.returncode != 0 and not out:
                return SkillResult(success=False, error=f"kiro-cli 失敗: {err[:300]}")

            # 統計產出
            wiki_pages = list(_WIKI_DIR.rglob("*.md"))
            count = len(wiki_pages)

            return SkillResult(success=True, data={
                "output": f"✅ 蒸餾完成，wiki/ 共 {count} 頁",
                "pages": count,
                "kiro_output": out[:500],
            })
        except asyncio.TimeoutError:
            return SkillResult(success=False, error=f"蒸餾超時（{params.get('timeout', 300)}s）")
        except Exception as e:
            return SkillResult(success=False, error=str(e))
