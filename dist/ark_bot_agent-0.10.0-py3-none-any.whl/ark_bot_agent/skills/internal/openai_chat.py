"""OpenAI API 即時對話。"""
from __future__ import annotations

import os

_client = None


def _get_client():
    global _client
    if _client is None:
        from openai import OpenAI
        _client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    return _client


def is_available() -> bool:
    return bool(os.getenv("OPENAI_API_KEY"))


async def chat(message: str, system_prompt: str = "", model: str = "") -> str:
    """單輪 OpenAI 對話。"""
    if not is_available():
        return ""
    try:
        client = _get_client()
        # env-ok: 本 skill **固定走 OpenAI**，與 `llm.provider` 無關 ——
        #         不能用 `model_for()`／`llm.model`，那可能是 Gemini 的模型名
        #         （預設 `gemini-3.5-flash`），送給 OpenAI 會直接失敗。
        #         呼叫端可傳 `model=`，或用 OPENAI_MODEL 覆寫。
        mdl = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")  # env-ok: 本 skill 固定走 OpenAI，llm.model 可能是別家模型名（理由見上方註解）
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": message})
        resp = client.chat.completions.create(model=mdl, messages=messages)
        return resp.choices[0].message.content or ""
    except Exception:
        return ""
