"""HTTP client for ark-team-agent dispatch API（headless 模式整合）。

Usage:
    from ark_bot_agent.agent.team_client import TeamClient

    client = TeamClient(url="http://localhost:13030", timeout=120)
    result = await client.dispatch("幫我分析這份報告", target="leader-agent")
    print(result.reply)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Literal

import httpx

log = logging.getLogger(__name__)

# dispatch 的結果分類。**服務端（`/api/v1/dispatch`）與這裡共用同一組字串** ——
# 服務端在回應體的 `status` 欄位給值，這裡照收，未知值歸 `unknown`。
DispatchStatus = Literal[
    "ok",               # 拿到回覆
    "timeout",          # 送進去了，但等不到這一則的回覆
    "unreachable",      # 連不上 team-agent（服務沒開／port 不對）
    "queued",           # agent 未就緒，訊息已存入 overflow 待投遞
    "send_failed",      # 送不進去（agent 起不來／已停用）
    "unknown_agent",    # target 不在團隊裡
    "invalid_request",  # 請求不合法
    "internal_error",   # 服務端未預期例外
    "bad_response",     # 回應不是預期的 JSON（通常是打到別的服務）
    "unknown",          # 服務端給了本版不認識的 status
]

# 值得重試的分類。**`unknown_agent` / `invalid_request` 重試一萬次也一樣** ——
# 而 `queued` 刻意不列入：訊息已經排隊了，重試等於重複投遞。
_RETRYABLE: frozenset[str] = frozenset({
    "timeout", "unreachable", "send_failed", "internal_error", "unknown",
})


@dataclass
class DispatchResult:
    """dispatch API 回傳結果。

    🔴 **為什麼不能只有 `ok`**：`ok=False` 只說「失敗了」，說不出
    「服務沒開 / 目標不存在 / agent 真的沒回」—— 呼叫端無法決定要不要重試、
    也無法給使用者有用的訊息。這是 `ark_bot_agent` 0.5.0 把 `agent_cli_chat()`
    從 `str | None` 改成 `CliResult`（帶 `status` / `retryable`）的同一個理由，
    形狀刻意對齊那邊。

    而服務端在 1.4.7 之前是「**HTTP 200 帶 error**」—— 以回傳值表示失敗。
    只看 HTTP status 的呼叫端會把「方法不存在」當成成功。1.4.8 起失敗一律
    帶對應的 HTTP status code，本類別的 `status` 則是更細的分類。
    """

    ok: bool
    status: DispatchStatus = "unknown"
    reply: str = ""
    agent_id: str = ""
    elapsed_ms: int = 0
    error: str = ""
    http_status: int = 0

    @property
    def retryable(self) -> bool:
        """這次失敗值得重試嗎。"""
        return not self.ok and self.status in _RETRYABLE

    def reply_text(self) -> str:
        """可直接顯示的文字；失敗時回空字串（與 `CliResult.reply_text()` 同語意）。"""
        return self.reply if self.ok else ""


class TeamClient:
    """ark-team-agent dispatch API 的 HTTP 客戶端。"""

    def __init__(self, url: str = "http://localhost:13030", timeout: int = 120):
        self.base_url = url.rstrip("/")
        self.timeout = timeout

    async def dispatch(self, message: str, *, target: str = "", session_id: str = "") -> DispatchResult:
        """發送訊息到 team-agent 並等待回覆。

        Args:
            message: 要發送的訊息
            target: 指定 agent（空字串 = 預設走 leader）
            session_id: 可選的 session 追蹤 ID
        """
        url = f"{self.base_url}/api/v1/dispatch"
        body = {"message": message}
        if target:
            body["target"] = target
        if session_id:
            body["session_id"] = session_id

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(url, json=body)
        except httpx.TimeoutException:
            log.warning("team-agent dispatch timeout (%ds)", self.timeout)
            return DispatchResult(ok=False, status="timeout",
                                  error=f"no response within {self.timeout}s")
        except httpx.ConnectError:
            log.warning("team-agent 無法連線：%s", self.base_url)
            return DispatchResult(ok=False, status="unreachable",
                                  error=f"cannot connect to {self.base_url}")
        except Exception as e:
            log.error("team-agent dispatch 失敗：%s", e)
            return DispatchResult(ok=False, status="internal_error", error=str(e))

        try:
            data = resp.json()
        except Exception:
            # 打到別的服務、或服務回了 HTML 錯誤頁 —— 不要把它當成 agent 的回覆
            log.error("team-agent dispatch 回應不是 JSON（HTTP %s）", resp.status_code)
            return DispatchResult(ok=False, status="bad_response",
                                  error=f"non-JSON response (HTTP {resp.status_code})",
                                  http_status=resp.status_code)
        if not isinstance(data, dict):
            return DispatchResult(ok=False, status="bad_response",
                                  error="response body is not a JSON object",
                                  http_status=resp.status_code)

        ok = bool(data.get("ok", False)) and resp.status_code < 400
        status = str(data.get("status") or "")
        if not status:
            # 舊版服務端（≤1.4.7）沒有 `status` 欄位 —— 由 HTTP code 推導，
            # 不要留 "unknown" 讓 `retryable` 誤判成可重試。
            status = "ok" if ok else ("unreachable" if resp.status_code >= 500
                                      else "invalid_request")
        elif status not in DispatchStatus.__args__:  # type: ignore[attr-defined]
            log.warning("team-agent 回了本版不認識的 status=%r", status)
            status = "unknown"

        return DispatchResult(
            ok=ok,
            status=status,  # type: ignore[arg-type]
            reply=str(data.get("reply") or ""),
            agent_id=str(data.get("agent_id") or ""),
            elapsed_ms=int(data.get("elapsed_ms") or 0),
            error=str(data.get("error") or ""),
            http_status=resp.status_code,
        )

    async def list_agents(self) -> list[dict]:
        """取得 team-agent 的可用 agent 清單。失敗回空清單。

        ⚠️ **空清單是有歧義的**（團隊真的沒人／服務沒開／端點壞了），所以失敗一定
        寫 log 並帶上 HTTP status。實例：服務端 1.4.7 的這個端點回 **HTTP 500**
        （呼叫了不存在的 `daemon.get_instance_status()`），而這裡原本只 warn
        一句 `無法取得` → 整條鏈完全靜默，看起來就像「團隊沒有成員」。
        """
        url = f"{self.base_url}/api/v1/agents"
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(url)
        except Exception as e:
            log.warning("無法取得 team agents 清單（連線失敗）：%s", e)
            return []
        if resp.status_code >= 400:
            log.error("team agents 端點回 HTTP %s：%s", resp.status_code, url)
            return []
        try:
            data = resp.json()
        except Exception:
            log.error("team agents 端點回應不是 JSON（HTTP %s）", resp.status_code)
            return []
        if not isinstance(data, dict) or not data.get("ok"):
            log.error("team agents 端點回 ok=false：%s",
                      (data or {}).get("error", "") if isinstance(data, dict) else data)
            return []
        return data.get("agents") or []

    async def is_available(self) -> bool:
        """檢查 team-agent 是否可用。"""
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.base_url}/api/health")
                return resp.status_code == 200
        except Exception:
            return False
