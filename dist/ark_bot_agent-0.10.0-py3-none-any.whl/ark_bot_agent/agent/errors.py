"""CLI backend 的錯誤分類與重試判定。

## 為什麼要分類

`cli.py` 原本 `except Exception` 一律寫 log —— **所有錯誤同等對待**。
但重試策略完全不同：

| 分類 | 可重試 | 為什麼 |
|------|:------:|--------|
| `timeout` | ✅ | 可能只是這次特別慢 |
| `crash` | ✅ | 子進程掛了，重開有機會 |
| `unknown` | ✅ | 不知道就給一次機會 |
| **`not_found`** | ❌ | **CLI 沒安裝，重試一百次也不會好** |
| **`permission`** | ❌ | **權限問題，那是設定不是暫時故障** |

不分類的代價是：對 `not_found` 重試三次，把「設定錯誤」拖成「服務很慢」。
"""
from __future__ import annotations

import asyncio
from typing import Literal

ErrorKind = Literal["timeout", "not_found", "permission", "crash", "unknown"]

#: 重試不會改變結果的分類 —— 它們是設定問題，不是暫時故障。
NOT_RETRYABLE: frozenset[str] = frozenset({"not_found", "permission"})


def classify(exc: BaseException | None = None, returncode: int | None = None) -> ErrorKind:
    """把失敗歸類。

    🔴 **順序有意義：例外先判、`returncode` 最後。**
    逾時被 kill 的子進程**也會有非 0 returncode** ——
    先看 returncode 會把逾時誤分類成 crash，而兩者的處置不同
    （逾時要調 timeout，crash 要查 agent 本身）。
    """
    if exc is not None:
        if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
            return "timeout"
        if isinstance(exc, FileNotFoundError):
            return "not_found"
        if isinstance(exc, PermissionError):
            return "permission"
        return "unknown"
    if returncode is not None and returncode != 0:
        return "crash"
    return "unknown"


def is_retryable(kind: ErrorKind) -> bool:
    """這個分類重試有意義嗎。"""
    return kind not in NOT_RETRYABLE


def describe(kind: ErrorKind, detail: str = "") -> str:
    """給 log 用的一句話（**不進使用者回覆** —— 那是實作細節）。"""
    base = {
        "timeout": "逾時",
        "not_found": "找不到 CLI 執行檔",
        "permission": "權限不足",
        "crash": "子進程非正常結束",
        "unknown": "未分類錯誤",
    }[kind]
    return f"{base}（{detail}）" if detail else base


__all__ = ["ErrorKind", "NOT_RETRYABLE", "classify", "is_retryable", "describe"]
