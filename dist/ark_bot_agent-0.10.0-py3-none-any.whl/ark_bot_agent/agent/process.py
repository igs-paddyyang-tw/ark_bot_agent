from __future__ import annotations
import asyncio
import time
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from ark_bot_agent.agent.result import CliResult

log = logging.getLogger("process")

# 預設超時秒數（當沒有注入 config 時使用）
DEFAULT_TIMEOUT = 3600

# Agent CLI token usage 解析（支援多種格式）
_TOKEN_PATTERNS = [
    # "input_tokens: 1234, output_tokens: 5678"
    re.compile(r"input_tokens[:\s]+(\d+).*?output_tokens[:\s]+(\d+)"),
    # "Tokens: 1234 in / 5678 out"
    re.compile(r"[Tt]okens?[:\s]+(\d+)\s*in\s*/\s*(\d+)\s*out"),
    # "Usage: input=1234 output=5678"
    re.compile(r"[Uu]sage.*?input[=:\s]+(\d+).*?output[=:\s]+(\d+)"),
    # JSON-like: {"input_tokens": 1234, "output_tokens": 5678}
    re.compile(r'"input_tokens"[:\s]+(\d+).*?"output_tokens"[:\s]+(\d+)'),
]


@dataclass
class TokenUsage:
    input_tokens: int = 0
    output_tokens: int = 0

    @property
    def total(self) -> int:
        return self.input_tokens + self.output_tokens


def parse_token_usage(text: str) -> TokenUsage | None:
    """從 Agent CLI stderr/stdout 解析 token usage，解析失敗回傳 None。"""
    for pattern in _TOKEN_PATTERNS:
        m = pattern.search(text)
        if m:
            return TokenUsage(input_tokens=int(m.group(1)), output_tokens=int(m.group(2)))
    return None


def estimate_token_usage(input_text: str, output_text: str) -> TokenUsage:
    """Fallback：以字元數 / 4 估算 token 數。"""
    return TokenUsage(
        input_tokens=len(input_text) // 4,
        output_tokens=len(output_text) // 4,
    )


class AgentProcess:
    """每次 send() spawn 一個 Agent CLI 進程，忙碌時排隊依序執行。"""

    _shutting_down: bool = False  # 類別層級 shutdown flag

    def __init__(self, name: str, working_dir: str = ".", model: str = "auto",
                 skip_resume: bool = False, backend: str = "kiro",
                 max_queue: int = 32, idle_timeout: int = 1800,
                 crash_window: int = 600):
        self.name = name
        self.working_dir = working_dir
        self.model = model
        self.backend = backend
        self.skip_resume = skip_resume
        self._running = False
        self._busy = False
        self.on_output: Callable | None = None
        self.event_bus = None  # 注入 EventBus
        self.timeout: int = DEFAULT_TIMEOUT  # 可由外部設定

        # [M2/R3] queue **必須有上限** —— 原本是無上限 `asyncio.Queue()`，
        #         沒有背壓，只會無聲堆積（記憶體與延遲一起長）。
        self.max_queue = max_queue
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=max_queue)
        self._worker_task: asyncio.Task | None = None

        # [M2/R3] idle 回收：8 個常駐 kiro-cli 原本永不回收。
        #         `persistent` 的 agent 不受此限（由 pool 判斷）。
        self.idle_timeout = idle_timeout
        self._last_active: float = time.monotonic()

        # [M2/R3] crash 計數用**時間窗**不用累計 ——
        #         累計值會讓長時間運行的健康服務慢慢累積到誤觸上限
        #         （`ark_team_agent` 1.2.14 就是為此改過）。
        self.crash_window = crash_window
        self._crashes: list[float] = []

    # Multi-runtime backend 配置
    BACKENDS = {
        "kiro": lambda self, msg: [
            "kiro-cli", "chat", "--no-interactive", "--trust-all-tools",
            *(["--model", self.model] if self.model != "auto" else []),
            *([] if self.skip_resume else ["--resume"]),
            msg,
        ],
        "agy": lambda self, msg: [
            "agy", "-p", msg, "--dangerously-skip-permissions",
            "--add-dir", str(Path(self.working_dir).resolve()),
            *(["--model", self.model] if self.model != "auto" else []),
        ],
        "claude": lambda self, msg: [
            "claude", "-p", msg, "--model", self.model,
        ],
    }

    def _build_cmd(self, message: str) -> list[str]:
        builder = self.BACKENDS.get(self.backend)
        if not builder:
            builder = self.BACKENDS["kiro"]

        # agy/claude 不會自動讀 .kiro/ steering，手動注入 SOUL
        # 但如果 caller 已經注入過（含 [SYSTEM INSTRUCTIONS] 標記），就跳過
        if self.backend in ("agy", "claude") and "[SYSTEM INSTRUCTIONS" not in message:
            message = self._inject_soul(message)

        cmd = builder(self, message)
        # 解析完整路徑（處理不在 PATH 的情況）
        try:
            from ark_bot_agent.agent.cli import _resolve_cmd
            resolved = _resolve_cmd(self.backend)
            if resolved:
                cmd[0] = resolved
        except ImportError:
            pass
        return cmd

    def _inject_soul(self, message: str) -> str:
        """讀取 working_dir 的 SOUL.md，prepend 到 message 作為 system context。"""
        soul_path = Path(self.working_dir).resolve() / ".kiro" / "steering" / "SOUL.md"
        if not soul_path.exists():
            return message
        try:
            soul = soul_path.read_text(encoding="utf-8").strip()
            if soul:
                return f"[SYSTEM INSTRUCTIONS - 你必須嚴格遵守以下角色設定]\n\n{soul}\n\n[END SYSTEM INSTRUCTIONS]\n\n---\n\n使用者訊息：{message}"
        except Exception:
            pass
        return message

    async def start(self, _retries: int = 3) -> None:
        """標記為可用，啟動佇列消費 worker（失敗 retry 最多 3 次）。"""
        cwd = Path(self.working_dir).resolve()
        cwd.mkdir(parents=True, exist_ok=True)
        for attempt in range(1, _retries + 1):
            try:
                self._running = True
                if self._worker_task and not self._worker_task.done():
                    self._worker_task.cancel()
                self._worker_task = asyncio.create_task(self._queue_worker())
                log.info("Agent %s registered (cwd=%s)", self.name, cwd)
                return
            except Exception as e:
                log.warning("Agent %s start attempt %d/%d failed: %s", self.name, attempt, _retries, e)
                if attempt < _retries:
                    await asyncio.sleep(5)
        log.error("Agent %s failed to start after %d attempts", self.name, _retries)

    async def _queue_worker(self) -> None:
        """持續從佇列取出任務依序執行。"""
        while self._running:
            try:
                text, future = await asyncio.wait_for(self._queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            result = await self._execute(text)
            if not future.done():
                # `_execute` 仍回 `str | None`（它只管跑 CLI）；
                # 型別化在這一層做，讓 `send()` 的契約單一。
                future.set_result(
                    CliResult.ok(result, backend=self.backend, model=self.model)
                    if result else
                    CliResult.fail("agent 無輸出", retryable=True,
                                   backend=self.backend, model=self.model)
                )
            self._queue.task_done()

    # ── idle / crash 觀測（[M2/R3]）─────────────────────────

    @property
    def idle_seconds(self) -> float:
        """距上次活動幾秒。忙碌中回 0。"""
        return 0.0 if self._busy else time.monotonic() - self._last_active

    @property
    def crash_count(self) -> int:
        """**時間窗內**的崩潰次數（不是累計值）。"""
        cutoff = time.monotonic() - self.crash_window
        self._crashes = [t for t in self._crashes if t >= cutoff]
        return len(self._crashes)

    def _record_crash(self) -> None:
        self._crashes.append(time.monotonic())
        log.warning("%s 崩潰（%d 秒內第 %d 次）",
                    self.name, self.crash_window, self.crash_count)

    # ── send ────────────────────────────────────────────────

    async def send(self, text: str) -> CliResult:
        """將訊息加入佇列，等待 worker 完成後回 `CliResult`。

        [M2/R3] queue 滿了**丟最舊的**（ADR-005）——
        最新的是使用者剛送的，丟它使用者立刻感覺到沒反應；
        最舊的已經等很久、本來就快逾時了。

        🔴 **被丟掉的那一則必須收到結果** —— 不能讓它的 future 永遠掛著，
        那會變成一個永不完成的 await，比丟掉更糟。
        """
        self._last_active = time.monotonic()

        if AgentProcess._shutting_down:
            log.info("%s: rejecting new task during shutdown", self.name)
            return CliResult.fail("服務正在關閉", backend=self.backend)
        if not self._running:
            return CliResult.fail("進程未啟動", retryable=True, backend=self.backend)

        future: asyncio.Future = asyncio.get_event_loop().create_future()
        item = (text, future)

        try:
            self._queue.put_nowait(item)
        except asyncio.QueueFull:
            # 丟最舊的，並讓它的等待者拿到 overflow 結果（不是懸掛的 future）
            try:
                _dropped_text, dropped_future = self._queue.get_nowait()
                self._queue.task_done()
                if not dropped_future.done():
                    dropped_future.set_result(
                        CliResult.fail("queue overflow", retryable=True,
                                       backend=self.backend)
                    )
            except asyncio.QueueEmpty:                     # 極端競態：剛好被 worker 取走
                pass
            log.warning("%s queue 滿（上限 %d），丟棄最舊的一則",
                        self.name, self.max_queue)
            try:
                self._queue.put_nowait(item)
            except asyncio.QueueFull:                      # 仍滿 → 拒絕這一則
                return CliResult.fail("queue overflow", retryable=True,
                                      backend=self.backend)

        if self._busy:
            log.info("%s is busy, queued (size=%d/%d)",
                     self.name, self._queue.qsize(), self.max_queue)
        try:
            return await asyncio.wait_for(future, timeout=self.timeout)
        except asyncio.TimeoutError:
            log.error("%s send() 等待逾時（%ds）", self.name, self.timeout)
            return CliResult.fail("等待佇列逾時", retryable=True, backend=self.backend)
        finally:
            self._last_active = time.monotonic()

    async def _execute(self, text: str) -> str | None:
        """Spawn Agent CLI 處理一則訊息，完成後回傳 output。"""
        self._busy = True
        cwd = Path(self.working_dir).resolve()
        cmd = self._build_cmd(text)
        log.info("Executing %s: %s", self.name, " ".join(cmd[:6]) + "...")

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
            output = stdout.decode("utf-8", errors="ignore").strip()
            err_text = stderr.decode("utf-8", errors="ignore").strip()

            # 基礎 ANSI strip（讓 log 可讀，完整清理交給 handlers._clean_output）
            output = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", output)

            # 解析 token usage（優先 stderr，其次 stdout，最後 fallback 估算）
            usage = parse_token_usage(err_text) or parse_token_usage(output)
            if not usage:
                usage = estimate_token_usage(text, output)
            self._last_usage = usage

            if output and self.on_output:
                await self.on_output(self.name, output, usage)

            if proc.returncode != 0 and not output:
                log.warning("%s exited %d: %s", self.name, proc.returncode, err_text[:200])
                return None

            log.info("%s completed (%d chars, %d tokens)", self.name, len(output), usage.total)
            # Daily log: 記錄情節記憶
            try:
                from ark_bot_agent.memory.daily_log import write_daily_log
                task_id = f"msg-{int(asyncio.get_event_loop().time())}"
                # 背景執行，不阻塞回覆
                asyncio.create_task(
                    write_daily_log(
                        agent_name=self.name,
                        task_id=task_id,
                        conversation=f"INPUT: {text[:500]}\nOUTPUT: {output[:500]}",
                    )
                )
            except Exception as e:
                log.debug("Daily log skipped for %s: %s", self.name, e)
            # Skill 推薦：評估是否觸發
            try:
                from ark_bot_agent.memory.recommend import recommend_skill
                # 粗估 tool calls（從 output 中計算 tool 使用痕跡）
                tool_call_count = len(re.findall(r"(?:Tool|tool|呼叫|execute|Running)", output))
                if tool_call_count >= 5:
                    asyncio.create_task(
                        recommend_skill(
                            agent_name=self.name,
                            task_id=task_id,
                            conversation=f"INPUT: {text[:800]}\nOUTPUT: {output[:1500]}",
                            tool_call_count=tool_call_count,
                        )
                    )
            except Exception as e:
                log.debug("Skill recommend skipped for %s: %s", self.name, e)
            # Parse progress markers
            try:
                from coordinator.a2a.progress_parser import parse_output
                progress_events = parse_output(output)
                for pevt in progress_events:
                    pevt.agent_id = self.name
                    if self.event_bus:
                        from coordinator.events.types import Event, EventType
                        await self.event_bus.emit(Event(
                            type=EventType.AGENT_OUTPUT,
                            data={"agent_id": self.name, "progress_type": pevt.type,
                                  "message": pevt.message, "step": pevt.step,
                                  "total_steps": pevt.total_steps, "artifacts": pevt.artifacts},
                            source="a2a_progress",
                        ))
            except ImportError:
                pass
            # Emit event
            if self.event_bus:
                from coordinator.events.types import Event, EventType
                await self.event_bus.emit(Event(
                    type=EventType.AGENT_OUTPUT,
                    data={"agent_id": self.name, "output": output, "model": self.model,
                          "input_tokens": usage.input_tokens, "output_tokens": usage.output_tokens},
                    source="process",
                ))
            return output or "done"

        except asyncio.TimeoutError:
            log.error("%s timed out (%ds)", self.name, self.timeout)
            if self.event_bus:
                from coordinator.events.types import Event, EventType
                await self.event_bus.emit(Event(
                    type=EventType.TASK_FAILED,
                    data={"agent_id": self.name, "output": f"timeout ({self.timeout}s)"},
                    source="process",
                ))
            if self.on_output:
                await self.on_output(self.name, f"⚠️ {self.name} 執行超時（{self.timeout} 秒）", None)
            return None
        except Exception as e:
            log.error("%s failed: %s", self.name, e)
            return None
        finally:
            self._busy = False

    def is_alive(self) -> bool:
        return self._running

    async def kill(self) -> None:
        self._running = False
        if self._worker_task:
            self._worker_task.cancel()
