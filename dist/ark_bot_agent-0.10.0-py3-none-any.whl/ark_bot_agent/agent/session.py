"""Agent Session 管理 — SQLite 持久化。

功能：
  - 追蹤每個 user_id 的 current_agent
  - 保留最近 N 輪對話歷史（多輪記憶）
  - 切換 Agent 時清空歷史（新對話）
  - 重啟不丟失（SQLite 儲存）
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from ark_bot_agent.config import get_config
from ark_bot_agent.paths import get_state_dir

log = logging.getLogger(__name__)

# DB 路徑
def _db_path() -> Path:
    """Session DB 路徑。

    🔴 **不在模組層算** —— 模組層常數在 import 時就凍結，
    誰先 import 就綁誰的 `get_home()`。那讓測試出現「單獨跑會過、
    完整跑會壞」的順序依賴，而執行期也可能綁到錯的家目錄。
    """
    return get_state_dir() / "sessions.db"


def default_agent_id() -> str:
    """新 Session 的預設對話對象 —— 讀 `bot.yaml` 的 `modes.default_agent`。

    ⚠️ 只影響**新建**的 Session —— 既有 Session 的模式存在 SQLite 裡，
    要讓改動對舊 Session 生效得用 `/agents` 切換一次，或清掉 `state/sessions.db`。

    > [M3.2] 原本讀 `DEFAULT_AGENT` 環境變數 —— 改為設定檔，
    > 因為「預設跟誰聊」是行為設定不是機密。env 只留 token 與 api key。
    """
    return get_config().modes.default_agent


def default_mode() -> str:
    """新 Session 的 `mode` 欄位值 —— 由 `modes.default` + `modes.default_agent` 決定。

    **欄位值不等於 `mode_kind`**（`default` / `agent:{id}` / `team`）——
    判斷模式一律用 `session.mode_kind`。
    """
    return get_config().modes.default_mode_string


def _get_db() -> sqlite3.Connection:
    """取得 SQLite 連線（自動建表）。"""
    db = _db_path()
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db), check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            user_id INTEGER PRIMARY KEY,
            current_agent TEXT NOT NULL DEFAULT 'default',
            mode TEXT NOT NULL DEFAULT 'default',
            history TEXT NOT NULL DEFAULT '[]',
            last_active TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


# Module-level 連線（lazy init）
_conn: sqlite3.Connection | None = None


def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = _get_db()
    return _conn


@dataclass
class ConversationTurn:
    """單輪對話。"""

    role: str  # "user" | "agent"
    content: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {"role": self.role, "content": self.content, "timestamp": self.timestamp}

    @classmethod
    def from_dict(cls, d: dict) -> "ConversationTurn":
        return cls(role=d["role"], content=d["content"], timestamp=d.get("timestamp", ""))


@dataclass
class UserSession:
    """單一使用者的 Session。"""

    user_id: int
    # 預設對話對象由 DEFAULT_AGENT 決定（預設 admin＝👑 管家），見 default_agent_id()
    current_agent: str = field(default_factory=default_agent_id)
    mode: str = field(default_factory=default_mode)  # "default" | "agent:{name}" | "team"
    history: list[ConversationTurn] = field(default_factory=list)
    max_turns: int = 10
    last_active: str = field(default_factory=lambda: datetime.now().isoformat())

    @property
    def is_default_mode(self) -> bool:
        """是否為 💬 快答模式（娜娜的 Gemini ReAct）。"""
        return self.mode == "default"

    @property
    def is_team_mode(self) -> bool:
        """是否為 ⚔️ 團隊模式（送 leader 統籌，由它決定自己做或拉人）。"""
        return self.mode == "team"

    @property
    def mode_kind(self) -> str:
        """三模式的分類：`chat` / `agent` / `team`。

        `mode` 欄位本身混了兩種資訊（模式 + 哪一位 agent），
        UI 與路由要的是「哪一種模式」，用這個屬性取，不要各自解析字串。
        """
        if self.mode == "default":
            return "chat"
        if self.mode == "team":
            return "team"
        return "agent"

    @property
    def agent_name(self) -> str | None:
        """Agent 模式時回傳 agent 名稱；chat／team 模式回傳 None。"""
        if self.mode.startswith("agent:"):
            return self.mode.split(":", 1)[1]
        return None

    def add_turn(self, role: str, content: str) -> None:
        """新增一輪對話，超過上限時移除最舊的。"""
        self.history.append(ConversationTurn(role=role, content=content))
        if len(self.history) > self.max_turns:
            self.history = self.history[-self.max_turns:]
        self.last_active = datetime.now().isoformat()
        self._save()

    def get_context(self) -> str:
        """取得對話歷史作為 context 字串（注入 LLM）。"""
        if not self.history:
            return ""
        lines = ["## 近期對話歷史\n"]
        for turn in self.history:
            prefix = "👤 User" if turn.role == "user" else "🤖 Agent"
            lines.append(f"{prefix}: {turn.content}")
        return "\n".join(lines)

    def clear_history(self) -> None:
        """清空對話歷史（切換 Agent 時）。"""
        self.history = []
        self._save()

    def _save(self) -> None:
        """持久化到 SQLite。"""
        try:
            history_json = json.dumps(
                [t.to_dict() for t in self.history], ensure_ascii=False
            )
            _db().execute(
                """INSERT OR REPLACE INTO sessions
                   (user_id, current_agent, mode, history, last_active)
                   VALUES (?, ?, ?, ?, ?)""",
                (self.user_id, self.current_agent, self.mode, history_json, self.last_active),
            )
            _db().commit()
        except Exception as e:
            log.warning("Session save failed for user %s: %s", self.user_id, e)


class SessionManager:
    """管理所有使用者 Session（SQLite 持久化）。"""

    def __init__(self) -> None:
        self._cache: dict[int, UserSession] = {}

    def get_or_create(self, user_id: int) -> UserSession:
        """取得或建立 Session（優先從 cache，miss 則查 DB）。"""
        if user_id in self._cache:
            return self._cache[user_id]

        # 從 DB 載入
        try:
            row = _db().execute(
                "SELECT current_agent, mode, history, last_active FROM sessions WHERE user_id = ?",
                (user_id,),
            ).fetchone()
            if row:
                history = [ConversationTurn.from_dict(d) for d in json.loads(row[2])]
                session = UserSession(
                    user_id=user_id,
                    current_agent=row[0],
                    mode=row[1],
                    history=history,
                    last_active=row[3],
                )
                self._cache[user_id] = session
                return session
        except Exception as e:
            log.warning("Session load failed for user %s: %s", user_id, e)

        # 新建
        session = UserSession(user_id=user_id)
        self._cache[user_id] = session
        return session

    @property
    def team_leader(self) -> str:
        """⚔️ 團隊模式的統籌者 —— 讀 `bot.yaml` 的 `modes.team_leader`。"""
        return get_config().modes.team_leader

    # 舊名保留給既有呼叫端（唯讀）。新程式碼請用 `team_leader`。
    @property
    def TEAM_LEADER(self) -> str:  # noqa: N802 —— 相容既有呼叫端
        return self.team_leader

    # 三模式（唯一的對外詞彙）。`mode` 欄位存的字串格式另有歷史包袱，見 switch_mode()
    MODES = ("chat", "agent", "team")

    def switch_mode(
        self, user_id: int, kind: str, agent_id: str | None = None, *, keep_history: bool = True
    ) -> UserSession:
        """切換三模式之一。

        Args:
            kind: `chat`（娜娜 Gemini ReAct）／`agent`（管家等單一 agent）／`team`（隊長統籌）
            agent_id: 只有 `kind="agent"` 時需要；未給則用 `DEFAULT_AGENT`
            keep_history: **預設保留對話歷史**。使用者切模式的真實意圖通常是
                「同一件事換個人問」，不是重新開始 —— 清掉等於逼他再講一次。
                要真的重開請傳 `False`（或呼叫 `session.clear_history()`）。

        Raises:
            ValueError: `kind` 不在 `MODES` 內

        > **`mode` 欄位的值不等於 `kind`** —— 欄位存的是 `"default"` / `"agent:{id}"` /
        > `"team"`（沿用既有 DB 格式，避免遷移）。判斷模式一律用 `session.mode_kind`，
        > 不要自己解析字串。
        >
        > ⚠️ 保留歷史對 **kiro backend 沒有副作用**：`agent_cli_chat()` 在
        > `backend == "kiro"` 時**不注入** session context（kiro-cli 自己有
        > `--resume` 的對話歷史）。session history 實際只餵給 Gemini 路徑
        > （💬 快答模式與 agy/claude backend），所以不會出現兩份歷史疊加。
        """
        if kind not in self.MODES:
            raise ValueError(f"未知模式 {kind!r}，可用：{', '.join(self.MODES)}")

        session = self.get_or_create(user_id)
        if kind == "chat":
            session.mode = "default"
            session.current_agent = "default"
        elif kind == "team":
            session.mode = "team"
            session.current_agent = self.TEAM_LEADER
        else:
            target = agent_id or default_agent_id()
            session.mode = f"agent:{target}"
            session.current_agent = target

        if not keep_history:
            session.clear_history()
        session.last_active = datetime.now().isoformat()
        session._save()
        return session

    def switch_agent(self, user_id: int, agent_id: str) -> UserSession:
        """[相容層] 以 agent id 切換，內部轉呼叫 `switch_mode()`。

        `default` → chat 模式、`team` → team 模式、其餘 → agent 模式。
        新程式碼請直接用 `switch_mode()`，模式語意比較清楚。
        """
        if agent_id == "default":
            return self.switch_mode(user_id, "chat")
        if agent_id == "team":
            return self.switch_mode(user_id, "team")
        return self.switch_mode(user_id, "agent", agent_id)

    def get_current_agent(self, user_id: int) -> str:
        """取得當前 Agent ID。"""
        return self.get_or_create(user_id).current_agent


# Module-level 實例
session_manager = SessionManager()
