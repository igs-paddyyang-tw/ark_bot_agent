"""`CliResult` —— CLI backend 的執行結果。

## 為什麼需要這個型別

`agent_cli_chat()` 原本回 **`str | None`**，呼叫端分不出四種情況：

| 實際發生 | 舊回傳 |
|---|---|
| agent 回了空字串 | `None` |
| 子進程崩潰（非 0 exit） | `None` |
| 逾時 | `None` |
| CLI 根本沒安裝 | `None` |

前三種該重試，第四種重試一百次也不會好（那是設定問題）。而**失敗是用回傳值
表示的，所以 `try/except` 抓不到** —— 呼叫端只 try/except 就會把失敗當成功。

> 💡 ninja-bot 的同型別 docstring 寫著「取代 `[PARTIAL]`/`[ERROR]` 字串前綴」
> —— 他們先用字串前綴表示狀態，痛過一輪才改型別。這裡直接跳到終點。

## 為什麼不叫 `AgentResult`

`llm/agent_loop.py` 已經有一個 `AgentResult`（ReAct 迴圈的結果）。
兩者語意完全不同，撞名會讓 `import AgentResult` 拿到哪一個變成靠 import 順序決定。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Status = Literal["success", "partial", "error"]


@dataclass
class CliResult:
    """一次 CLI backend 呼叫的結果。

    `partial` 的用途：逾時但已經讀到部分輸出 —— **部分結果比沒結果好**
    （與 team_flow 的 deadline 策略同一個原則）。
    """

    status: Status
    output: str = ""
    error: str = ""
    retryable: bool = False
    elapsed_ms: int = 0
    backend: str = ""
    model: str = ""

    # 🔴 刻意**不實作** `__str__` 回 output ——
    #    漏改的呼叫點要在測試就爆（`"..." + result` 會 TypeError），
    #    而不是靜默把 `CliResult(...)` 的物件字串當成 agent 的回答送給使用者。

    def is_ok(self) -> bool:
        """成功或部分成功（有輸出可用）。"""
        return self.status in ("success", "partial")

    def reply_text(self) -> str:
        """可直接顯示的文字。

        `error` 時回 `""` —— 與舊語意等價（舊版失敗回 `None`，
        呼叫端都用 `if reply:` 判斷）。遷移時把 `reply` 改成
        `result.reply_text()` 即可，判斷式不用動。
        """
        return self.output if self.is_ok() else ""

    @classmethod
    def ok(cls, output: str, **kw) -> CliResult:
        """成功。空輸出仍算 `success` —— agent 就是回了空字串，那不是錯誤。"""
        return cls(status="success", output=output, **kw)

    @classmethod
    def fail(cls, error: str, *, retryable: bool = False, output: str = "", **kw) -> CliResult:
        """失敗。有部分輸出時降為 `partial` 而不是丟掉。"""
        if output:
            return cls(status="partial", output=output, error=error, retryable=retryable, **kw)
        return cls(status="error", error=error, retryable=retryable, **kw)


__all__ = ["CliResult", "Status"]
