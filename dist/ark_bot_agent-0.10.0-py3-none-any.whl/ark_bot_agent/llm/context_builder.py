"""Context Builder：統一組裝 system prompt。"""
from __future__ import annotations

import logging
from pathlib import Path

from ark_bot_agent.paths import get_memory_dir, get_steering

log = logging.getLogger(__name__)



async def build_default_system_prompt(query: str = "", session=None) -> str:
    """組裝 Default 模式（Ark Agent）的 system prompt。

    8 層：SOUL + BRAIN + USER + memory + recent + recall + wiki + skills + tool instructions
    """
    parts: list[str] = []

    # 1. SOUL.md
    soul_path = get_steering("SOUL.md")
    if soul_path.exists():
        parts.append(soul_path.read_text(encoding="utf-8"))

    # 1a. 三模式分工（**必須明寫**）
    #     agent 只讀到最終 prompt，它不知道使用者選了哪個模式，也不知道還有別的模式。
    #     不寫的話娜娜會在快答模式積極派工，使用者會覺得三個模式沒差別。
    parts.append("""## 你現在的角色：💬 快答模式

使用者有三種模式可選，**現在選的是「快答」——也就是你**：

| 模式 | 誰處理 | 適合 |
|------|--------|------|
| 💬 **快答（你）** | 你直接回，需要時才用工具 | 閒聊、查知識庫、單一問題 |
| 👑 管家 | admin agent 深入處理 | 系統維運、要動手做的事 |
| ⚔️ 團隊 | 隊長拆解 → 成員執行 → 隊長彙整 | 跨職能、要多方評估的事 |

**這決定了你該做什麼：**

- **優先自己回答**。能用 `search_wiki` / `recall_memory` / `web_search` 查到的就自己查完回答
- `dispatch_to_agent` **留給「非得那個人才做得到」的事**（要動手改檔、要跑指令、
  要該領域深度分析）。不要因為題目看起來專業就轉手
- 遇到**跨職能、需要多方評估**的需求（例如「評估要不要做 X，技術、數據、報表都要看」），
  不要自己硬拆 —— **告訴使用者切 ⚔️ 團隊模式會更完整**，那邊有真正的拆解與彙整流程
- 使用者若說「找管家」「叫隊長」，提醒他可以用 `/agents` 切模式，或直接 `@管家`／`@隊長`
""")

    # 1b. 口語語氣指引（強化 SOUL 的風格要求）
    parts.append("""## 回覆語氣規則（必須遵守）

- 用繁體中文口語回覆，像在跟同事聊天
- 句尾不要每句都用句號「。」結束，可以用「～」「！」「⋯」或直接結束
- 可以用「嗯嗯」「好喔」「了解」「沒問題」開頭
- 不要用「收到您的需求」「根據分析」「以下是建議」這種公文體
- emoji 適量使用（1-3 個/回覆），不要過度
- 技術回答可以直接切入重點，不需要客套前言
- 派工時簡短說明：「這個我找碼哥幫你處理～」而不是「我將此任務派發給 coder-agent」
""")

    # 2. BRAIN.md（去 frontmatter）
    brain_path = get_steering("BRAIN.md")
    if brain_path.exists():
        content = brain_path.read_text(encoding="utf-8")
        if content.startswith("---"):
            _, _, content = content.split("---", 2)
        parts.append(content.strip())

    # 3. TEAM.md
    team_path = get_steering("TEAM.md")
    if team_path.exists():
        parts.append(team_path.read_text(encoding="utf-8"))

    # 4. memory/memory.md
    memory_path = get_memory_dir() / "memory.md"
    if memory_path.exists():
        content = memory_path.read_text(encoding="utf-8")
        if content.strip() and "（尚無記錄）" not in content:
            parts.append(f"\n## 持久記憶\n{content[:1500]}")

    # 5. memory/recent.md
    recent_path = get_memory_dir() / "recent.md"
    if recent_path.exists():
        content = recent_path.read_text(encoding="utf-8")
        if content.strip() and "（尚無記錄）" not in content:
            parts.append(f"\n## 最近經驗\n{content[:1500]}")

    # 6. FTS5 recall（相關歷史）
    if query:
        try:
            from ark_bot_agent.memory.recall import recall
            results = recall("_default", query, k=3, include_shared=True)
            if results:
                recall_lines = ["\n## 相關歷史記憶"]
                for r in results:
                    recall_lines.append(f"- [{r.date}] {r.title}: {r.body[:100]}")
                parts.append("\n".join(recall_lines))
        except Exception:
            pass

    # 7. Wiki + Web Search（搜尋流程指引）
    parts.append(
        "\n## 知識庫與搜尋\n"
        "查詢事實/比較/評價的流程（強制，不可跳過）：\n"
        "1. 先用 search_wiki tool 搜尋知識庫\n"
        "2. 知識庫查無 → 用 web_search tool 搜尋外部資訊\n"
        "3. web_search 有回傳內容 → 直接根據回傳內容整理回答，附上 🔗 來源\n"
        "4. 兩者都確實無結果（web_search 回傳含 'Error' 或 '無結果'）→ 回覆「📚 知識庫與外部搜尋皆無相關資料」\n"
        "\n重要規則：\n"
        "- web_search 回傳的文字就是搜尋結果，直接使用它來回答使用者\n"
        "- 回答後就結束，不要自動存入知識庫\n"
        "- save_to_wiki 只在使用者明確說「存進知識庫」「記錄下來」「寫入 wiki」時才使用\n"
        "- 絕對不要在同一輪中既搜尋又自動存入\n"
    )

    # 7b. 派工規則（dispatch_to_agent）
    parts.append(
        "\n## 派工規則（dispatch_to_agent）\n"
        "### Agent 代號對照表\n"
        "| 代號 | agent_id | 職責 |\n"
        "|------|----------|------|\n"
        "| 管家 | admin-agent | 系統管理、監控、費控 |\n"
        "| 隊長 | leader-agent | 任務規劃、拆解需求 |\n"
        "| 阿智 | ai-dev-agent | AI 技術、Prompt、RAG |\n"
        "| 碼哥 | coder-agent | 寫程式、API、DB |\n"
        "| 品管 | qa-agent | 測試、Code Review |\n"
        "| 數據 | data-agent | 數據分析、KPI |\n"
        "| 情報 | market-agent | 市場研究、競品 |\n"
        "| 筆記 | report-agent | 產報告、圖表 |\n\n"
        "### 派工判斷\n"
        "- 使用者提到代號（「叫碼哥」「讓數據看看」「請筆記」）→ 直接派對應 agent\n"
        "- 簡單問答、聊天、查知識庫 → 你直接回覆，不要派工\n"
        "- 需要寫程式 → dispatch coder-agent\n"
        "- 需要 AI/Prompt/RAG 設計 → dispatch ai-dev-agent\n"
        "- 需要數據分析 → dispatch data-agent\n"
        "- 需要市場研究 → dispatch market-agent\n"
        "- 需要產報告 → dispatch report-agent\n"
        "- 需要測試/Review → dispatch qa-agent\n"
        "- 需要部署/費控 → dispatch admin-agent\n"
        "- 複雜多步任務 → dispatch leader-agent\n"
        "- 不確定 → 你自己先回答\n\n"
        "### 派工回覆語氣\n"
        "派工時用代號口語回報：「好喔，我請碼哥來處理～」而不是「已將任務派發給 coder-agent」\n"
    )

    # 8. Skills 清單
    try:
        from ark_bot_agent.llm.tool_registry import registry
        tool_desc = registry.list_descriptions()
        if tool_desc:
            parts.append(f"\n## 可用工具\n{tool_desc}")
    except Exception:
        pass

    # 9. Skill 清單（SKILL.md 名稱）
    try:
        from ark_bot_agent.llm.tools.skill_executor import _list_skill_names
        skills = _list_skill_names()
        if skills:
            parts.append(f"\n## 可執行的 Skills\n使用 execute_skill tool 載入：\n- " + "\n- ".join(skills[:15]))
    except Exception:
        pass

    # 10. Session history + 歡迎破冰
    if session:
        context_str = session.get_context()
        if context_str:
            parts.append(f"\n{context_str}")
        else:
            # 新 session（沒有歷史）→ 嘗試從 daily log 提起上次做的事
            parts.append(_build_icebreaker())

    return "\n\n".join(parts)


def _build_icebreaker() -> str:
    """從最近的 daily log 提取上次做的事，供 LLM 主動破冰。"""
    daily_dir = get_memory_dir() / "daily"
    if not daily_dir.exists():
        return ""

    # 找最近的 daily log（不含今天）
    from datetime import datetime, timedelta
    today = datetime.now().strftime("%Y-%m-%d")
    logs = sorted(daily_dir.glob("*.md"), reverse=True)

    for log_file in logs[:3]:  # 最近 3 天
        if log_file.stem == today:
            continue
        content = log_file.read_text(encoding="utf-8")
        if len(content) < 50:
            continue
        # 取最後幾個有意義的對話摘要
        lines = [l for l in content.split("\n") if l.strip() and not l.startswith("#")]
        if lines:
            recent_activity = "\n".join(lines[-5:])  # 最後 5 行
            return (
                f"\n## 破冰提示（新對話時主動提起）\n"
                f"上次（{log_file.stem}）Paddy 做了這些事：\n"
                f"{recent_activity[:300]}\n\n"
                f"如果使用者只是打招呼（hi、嗨、你好），你可以自然地提起：\n"
                f"「嗨～上次看你在忙 XXX，今天要繼續嗎？還是有新的事情？」\n"
                f"不要每次都提，只在新 session 第一句時提一次。"
            )
    return ""
