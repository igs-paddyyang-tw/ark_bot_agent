"""Tool: dispatch_to_agent — 將任務派給專業 Agent 處理。"""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

# 會在 handle_message 中注入當前 session 供 dispatch 使用
_current_session = None


def set_dispatch_session(session) -> None:
    """由 handle_message 注入當前 session，讓 dispatch 能讀到對話歷史。"""
    global _current_session
    _current_session = session


async def handle_dispatch_to_agent(args: dict) -> str:
    """派工給指定 Agent，自動帶入對話 context。"""
    target_agent = args.get("target_agent", "").strip()
    task_description = args.get("task_description", "").strip()
    priority = args.get("priority", "normal")

    if not target_agent:
        return "Error: target_agent 不能為空"
    if not task_description:
        return "Error: task_description 不能為空"

    log.info("dispatch_to_agent: target=%s priority=%s task=%s",
             target_agent, priority, task_description[:80])

    # 帶入最近對話 context（讓 Agent 看到之前聊了什麼）
    enriched_task = _enrich_with_context(task_description)

    # 嘗試透過 Agent CLI 送出任務
    try:
        from ark_bot_agent.agent.cli import is_cli_available, agent_cli_chat

        if is_cli_available():
            agent_id = target_agent.replace("-agent", "")
            result = (await agent_cli_chat(enriched_task, agent_id=agent_id)).reply_text()
            if result:
                log.info("dispatch_to_agent: %s replied (%d chars)", target_agent, len(result))
                return f"✅ {target_agent} 回覆：\n\n{result}"
            else:
                return f"⚠️ {target_agent} 無回應（可能超時），任務已送出但未收到結果。"
        else:
            # CLI 不可用 → fallback Gemini
            from pathlib import Path
            from ark_bot_agent.llm.chat import simple_chat

            agent_id = target_agent.replace("-agent", "")
            soul_path = Path(f"agents/{target_agent}/.kiro/steering/SOUL.md")
            if not soul_path.exists():
                soul_path = Path(f"agents/{agent_id}-agent/.kiro/steering/SOUL.md")

            soul = ""
            if soul_path.exists():
                soul = soul_path.read_text(encoding="utf-8")

            system = f"{soul}\n\n## 任務\n你收到一個派工任務，請完成後回報結果。"
            result = await simple_chat(enriched_task, system=system)

            if result:
                log.info("dispatch_to_agent (fallback): %s replied (%d chars)", target_agent, len(result))
                return f"✅ {target_agent}（Gemini fallback）回覆：\n\n{result}"
            else:
                return f"❌ {target_agent} 不可用（CLI 未安裝，Gemini fallback 也失敗）"

    except Exception as e:
        log.error("dispatch_to_agent failed: %s", e)
        return f"❌ 派工失敗：{e}"


def _enrich_with_context(task_description: str) -> str:
    """將對話 context 附加到 task_description，讓被派工的 Agent 看到脈絡。"""
    if not _current_session or not _current_session.history:
        return task_description

    # 取最近 6 輪（3 來回），避免 context 太長
    recent = _current_session.history[-6:]
    if not recent:
        return task_description

    context_lines = ["## 對話脈絡（使用者最近的對話，供參考）\n"]
    for turn in recent:
        prefix = "User" if turn.role == "user" else "Assistant"
        # 每輪最多 500 字，避免超長
        content = turn.content[:500]
        context_lines.append(f"{prefix}: {content}\n")

    context_block = "\n".join(context_lines)

    return f"{context_block}\n---\n\n## 當前任務\n{task_description}"


def register_tools():
    from ark_bot_agent.llm.tool_registry import Tool, registry
    from ark_bot_agent.agent.cli import get_dispatchable_agents

    # 動態從 agents.yaml 取得可派工的 agent 列表
    dispatchable = get_dispatchable_agents()
    if not dispatchable:
        dispatchable = [
            "coder-agent", "ai-dev-agent", "data-agent",
            "market-agent", "report-agent", "qa-agent", "admin-agent",
            "leader-agent",
        ]

    registry.register(Tool(
        name="dispatch_to_agent",
        description=(
            "將任務派給專業 Agent 處理。用於需要特定領域專業知識的任務。"
            "簡單問答/聊天/查知識庫 → 你直接回覆，不要派工。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "target_agent": {
                    "type": "string",
                    "enum": dispatchable,
                    "description": "目標 Agent ID",
                },
                "task_description": {
                    "type": "string",
                    "description": "任務描述（含使用者原始需求 + 你的分析）",
                },
                "priority": {
                    "type": "string",
                    "enum": ["low", "normal", "high"],
                    "description": "優先級（預設 normal）",
                },
            },
            "required": ["target_agent", "task_description"],
        },
        handler=handle_dispatch_to_agent,
    ))
