"""用途 → 模型（[R6] 多模型分工）。

## 為什麼要這個

`bot.yaml` 原本只有一個 `llm.model`，所有用途共用。但成本結構不同：

| 用途 | 特性 | 該用什麼 |
|------|------|---------|
| `plan` | 輸出短 JSON，不需要深思 | 便宜快的 |
| `chat` | 對話，要好的語感 | 中間的 |
| `verify` | 檢查別人的產出，要挑得出問題 | 強的 |

用同一個模型代表三者之中至少兩個配錯 —— 要嘛規劃太貴，要嘛驗證太弱。

## 為什麼 key 是「用途」不是「節點名」

ninja 的 `MODEL_MAP` key 是工作流節點名，與它的拓樸綁在一起。
用途名跨拓樸可用，而且**未知的用途名可以 warning** ——
節點名做不到（每個專案的節點都不一樣，無法判斷是打錯還是新節點）。
"""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

#: 套件本身會用到的用途。消費端可自行加，但加了要自己傳。
#
#: v0.9.0 補上 `wiki` 與 `rerank` —— 這兩處原本各自硬編 `gemini-2.5-flash`
#: 而完全不看設定（`llm.model` 是 `gemini-3.5-flash`，改它沒有用）。
#: 不把它們併進 `chat` 的理由正是本模組的設計前提：**成本結構不同**。
#: rerank 只是把 N 個候選重排，輸出極短 → 該用最便宜的；
#: wiki 問答要從一堆上下文組出答案並標來源 → 比 rerank 重、比 chat 輕。
KNOWN_PURPOSES: frozenset[str] = frozenset({
    "chat", "plan", "verify", "synthesis", "wiki", "rerank",
})


def model_for(purpose: str) -> str:
    """回該用途要用的模型。

    解析順序：`llm.models[purpose]` → `llm.model` → `"auto"`。

    🔴 **未知用途要 warning 並列出可用的** —— 靜默 fallback 會讓
    `bot.yaml` 裡打錯的 key（`verfiy`）永遠沒人發現，而行為看起來「正常」
    （只是一直用著預設模型）。這與 `modes.chat.tools` 那個 bug 同型。
    """
    from ark_bot_agent.config import get_config

    llm = get_config().llm
    models: dict[str, str] = getattr(llm, "models", None) or {}

    if purpose not in KNOWN_PURPOSES:
        log.warning("未知的模型用途 %r ｜ 已知：%s", purpose, "、".join(sorted(KNOWN_PURPOSES)))

    if unknown := [k for k in models if k not in KNOWN_PURPOSES]:
        # 設定裡有打錯的 key —— 那個設定永遠不會生效，要講出來
        log.warning("llm.models 有不會生效的 key：%s ｜ 已知用途：%s",
                    "、".join(unknown), "、".join(sorted(KNOWN_PURPOSES)))

    return models.get(purpose) or llm.model or "auto"


__all__ = ["KNOWN_PURPOSES", "model_for"]
