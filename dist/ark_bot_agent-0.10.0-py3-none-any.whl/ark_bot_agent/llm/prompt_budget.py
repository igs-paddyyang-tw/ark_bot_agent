"""Chat prompt 的 context 預算量測（[R2]）。

## 為什麼是量測工具，不是優化

💬 快答模式每則訊息都送 **system prompt + 工具 schema**，
不論那則訊息是「你好」還是一份技術評估。

M3 的教訓很直接：當時計畫要「精簡 plan prompt」（抄 ninja 的 -97% tokens），
量測後發現我們的 plan prompt 只有 654 字元，**真正的量在 leader steering
與 `--resume` 歷史**。照計畫字面做會改錯地方，**而且看起來有做事**。

> 🔴 所以先讓「花了多少」可**重複量測**，再決定要不要動、動哪裡。
> **量測工具本身就是交付物** —— 沒有它，下次改動無從比較。

## 用法

```python
from ark_bot_agent.llm.prompt_budget import prompt_budget

b = await prompt_budget("你好")
b["total_chars"]     # 全部
b["sections"]        # 各區塊字元數
b["tool_schema"]     # 工具 schema
b["est_tokens"]      # 粗估 token（÷4，中文偏保守）
```

CLI：`python -m ark_bot_agent budget "你好"`
"""
from __future__ import annotations

import json
import logging
import re

log = logging.getLogger(__name__)

#: system prompt 的區塊標記 → 可讀名稱。
#: 依 `context_builder.build_default_system_prompt()` 的九個區塊。
#: ⚠️ 標記必須與 `context_builder` 的**實際標頭**逐字一致。
#:    初版我憑印象寫「## 搜尋」「## 可用技能」，實際是「## 知識庫與搜尋」
#:    「## 可執行的 Skills」→ 找不到標記，那些區塊被**歸到前一段**，
#:    於是 `recent_md` 量到 2799 而程式明明截斷在 1500。
#:    **量測工具自己算錯比沒有量測更糟** —— 它會讓人去優化錯的地方。
_SECTION_MARKS: tuple[tuple[str, str], ...] = (
    ("## 你現在的角色", "mode_desc"),
    ("## 回覆語氣規則", "tone_rules"),
    ("## 持久記憶", "memory_md"),
    ("## 最近經驗", "recent_md"),
    ("## 相關歷史記憶", "fts5_recall"),
    ("## 知識庫與搜尋", "search_guide"),
    ("## 派工規則", "dispatch_rules"),
    ("## 可用工具", "tools_desc"),
    ("## 可執行的 Skills", "skills_list"),
    ("## 破冰提示", "icebreaker"),
)

_CHARS_PER_TOKEN = 4        # 粗估。中文實際更低，所以這是**保守**估計


def _split_sections(prompt: str) -> dict[str, int]:
    """把 system prompt 依標記切段並計字元數。

    找不到標記的部分歸到 `soul_and_other` —— **不丟棄**，
    否則各段加總 ≠ 總數，那種帳對不起來的量測沒有用。
    """
    hits: list[tuple[int, str]] = []
    for mark, name in _SECTION_MARKS:
        if (i := prompt.find(mark)) >= 0:
            hits.append((i, name))
    hits.sort()

    out: dict[str, int] = {}
    if not hits:
        return {"soul_and_other": len(prompt)}

    out["soul_and_other"] = hits[0][0]          # 第一個標記之前（SOUL/BRAIN/TEAM）
    for idx, (start, name) in enumerate(hits):
        end = hits[idx + 1][0] if idx + 1 < len(hits) else len(prompt)
        out[name] = end - start
    return out


async def prompt_budget(query: str = "你好", *, session=None) -> dict:
    """量測一次 chat 呼叫要送出的 context。

    回傳的 `sections` 各段加總 + `tool_schema` == `total_chars`，
    **帳要對得起來**（見 `_split_sections`）。
    """
    from ark_bot_agent.config import get_config
    from ark_bot_agent.llm.context_builder import build_default_system_prompt

    prompt = await build_default_system_prompt(query=query, session=session)
    sections = _split_sections(prompt)

    # 工具 schema —— 套白名單後的，那才是實際送出的
    tool_chars = 0
    tool_names: list[str] = []
    try:
        import ark_bot_agent.llm.tools  # noqa: F401
        from ark_bot_agent.llm.agent_loop import _pick_schemas
        from ark_bot_agent.llm.tool_registry import registry

        schemas = _pick_schemas(registry, get_config().modes.chat.tools) or []
        tool_chars = len(json.dumps(schemas, ensure_ascii=False))
        tool_names = [s.get("name", "?") for s in schemas]
    except Exception as e:                                # noqa: BLE001
        log.warning("量測工具 schema 失敗（其餘照算）：%s", e)

    total = len(prompt) + tool_chars
    return {
        "query": query,
        "query_chars": len(query),
        "system_prompt_chars": len(prompt),
        "tool_schema": tool_chars,
        "tool_names": tool_names,
        "total_chars": total,
        "est_tokens": total // _CHARS_PER_TOKEN,
        "sections": dict(sorted(sections.items(), key=lambda kv: -kv[1])),
    }


def format_budget(b: dict) -> str:
    """給 CLI / 報告用的表格。"""
    lines = [
        f"query          : {b['query']!r}（{b['query_chars']} 字元）",
        f"system prompt  : {b['system_prompt_chars']:>6} 字元",
        f"tool schema    : {b['tool_schema']:>6} 字元（{len(b['tool_names'])} 個工具）",
        f"{'─' * 40}",
        f"總計           : {b['total_chars']:>6} 字元 ≈ {b['est_tokens']} tokens",
        "",
        "各區塊（由大到小）：",
    ]
    total = max(1, b["system_prompt_chars"])
    for name, n in b["sections"].items():
        lines.append(f"  {name:<16} {n:>6} 字元　{n * 100 // total:>3}%")
    return "\n".join(lines)


__all__ = ["prompt_budget", "format_budget"]
