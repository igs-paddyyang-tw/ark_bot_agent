"""設定載入 —— `agents.yaml`（誰）+ `bot.yaml`（怎麼跑）。

## 設定檔分工（刻意不合併）

| 檔案 | 職責 | 必要性 |
|------|------|--------|
| `agents.yaml` | agent 定義（誰、代號、工作目錄、`dispatchable`、`group_members`） | **必要（哨兵）** |
| `bot.yaml` | Bot 層設定（server / modes / llm / backend / report / features） | 選用，缺則全走預設 |
| `.env` | **只放機密**（token / api key） | 依 Tier |

agent 定義是「有誰」、bot 設定是「怎麼跑」—— 變動頻率與審視角度都不同，
混在一起會讓「改一個 port」也要動 agent 區塊。

## 兩個設計原則

**① 未知欄位一律忽略，不報錯。**
舊設定移除欄位後，消費端的 yaml 可能還留著。報錯會讓服務起不來，
而那個欄位本來就已經沒作用了 —— 讓它安靜地被忽略。
（`ark_team_agent` 對已刪 policy 就是這樣處理。）

**② 缺 `bot.yaml` 不該讓服務起不來。**
全部走預設值，但啟動訊息要標示（`paths.config_status()` 提供逐檔狀態）。
只有哨兵 `agents.yaml` 是必要的。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, TypeVar

import yaml

from ark_bot_agent.paths import get_config_file, get_home

log = logging.getLogger(__name__)

T = TypeVar("T")

# 三模式的唯一詞彙（與 `session.mode_kind` 一致）
MODES = ("chat", "agent", "team")


def _pick(cls: type[T], raw: dict | None, **overrides: Any) -> T:
    """用 dict 建 dataclass，**未知欄位忽略**（原則①）。

    會把被忽略的欄位寫進 log —— 不報錯，但也不該完全無聲，
    否則使用者打錯欄位名時會以為設定生效了。
    """
    raw = raw or {}
    known = {f.name for f in fields(cls)}          # type: ignore[arg-type]
    unknown = set(raw) - known
    if unknown:
        log.info("%s 忽略未知欄位：%s", cls.__name__, ", ".join(sorted(unknown)))
    kwargs = {k: v for k, v in raw.items() if k in known}
    kwargs.update(overrides)
    return cls(**kwargs)                            # type: ignore[call-arg]


# ── Bot 層設定 ──────────────────────────────────────────────


@dataclass
class ServerConfig:
    """FastAPI／Web UI。"""

    port: int = 8088
    host: str = "0.0.0.0"


@dataclass
class ChatModeConfig:
    """💬 快答（娜娜 Gemini ReAct）。"""

    max_iterations: int = 5

    # 工具白名單 —— 只列**唯讀 + 派工**。
    #
    # 🔴 三個有寫入副作用的工具刻意不在預設裡，要開必須在 `bot.yaml` 明寫：
    #     save_to_wiki   → `filepath.write_text()` 直接寫共用知識庫
    #     save_memory    → 寫記憶
    #     execute_skill  → 執行 skill（含 execute_code）
    #
    # 專案的知識庫規則是「wiki 只由 ingest 產出、禁止手寫」，
    # 讓對話模型自己寫進去與那條規則衝突 —— 所以預設關，不是預設開。
    #
    # ⚠️ 這份清單原本寫 `wiki_search`（實際叫 `search_wiki`）而且**沒有任何人讀**，
    #    於是「看起來限制了工具範圍，實際上七個全開」，其中三個能寫。
    #    給人錯誤的安全感比沒有這個設定更糟。
    tools: list[str] = field(
        default_factory=lambda: [
            "search_wiki", "recall_memory", "web_search", "dispatch_to_agent",
        ]
    )


@dataclass
class TeamModeConfig:
    """⚔️ 團隊（leader 統籌的三階段工作流）。

    預設值來自實測（三人派工：data 37s / report 50s / ai-dev 123s）——
    `stage_deadline` 取 100s 是因為「最慢的那個人不該拖住已完成的」。
    """

    stage_deadline: int = 100        # 執行階段整體 deadline（秒）
    member_timeout: int = 150        # 單一成員硬超時
    max_concurrency: int = 3         # 同時最多幾個成員在跑
    max_assignments: int = 3         # leader 一次最多派幾項
    member_reply_cap: int = 2500

    # [R8] 收斂後的可選驗證。**預設關** —— 它多一次 CLI 往返，
    #      而且不是每種任務都需要（閒聊型的問題驗證只是噪音）。
    #      驗證失敗不影響已完成的協作（只是不附意見）。
    verify: bool = False     # 單一成員回覆進收斂 prompt 的字數上限


@dataclass
class ModesConfig:
    """三模式設定。"""

    default: str = "agent"           # chat | agent | team ← 新 Session 的預設
    default_agent: str = "admin"     # agent 模式的預設對象
    team_leader: str = "leader"      # team 模式的統籌者
    chat: ChatModeConfig = field(default_factory=ChatModeConfig)
    team: TeamModeConfig = field(default_factory=TeamModeConfig)

    def __post_init__(self) -> None:
        if self.default not in MODES:
            log.warning(
                "modes.default=%r 不在 %s，改用 'agent'", self.default, list(MODES)
            )
            self.default = "agent"

    @property
    def default_mode_string(self) -> str:
        """轉成 Session 的 `mode` 欄位格式。

        欄位存的是 `"default"` / `"agent:{id}"` / `"team"`（沿用既有 DB 格式），
        **不等於 `mode_kind`** —— 判斷模式一律用 `session.mode_kind`。
        """
        if self.default == "chat":
            return "default"
        if self.default == "team":
            return "team"
        return f"agent:{self.default_agent}"


@dataclass
class LLMConfig:
    """💬 快答模式的 LLM。管家／團隊模式**不經過這裡**（走 kiro-cli）。"""

    provider: str = "gemini"         # gemini | openai | anthropic
    model: str = "gemini-3.5-flash"
    temperature: float = 0.7

    # [R6] 多模型分工。key 是**用途**（chat / plan / verify / synthesis），
    #      未指定者 fallback 到 `model`。**`model` 不可移除** —— 既有部署還在用。
    #      打錯的 key 會在 log warning（靜默 fallback 會讓錯誤設定永遠沒人發現）。
    models: dict[str, str] = field(default_factory=dict)


@dataclass
class BackendConfig:
    """Agent 分身的執行引擎。"""

    cli: str = "auto"                # auto | kiro | claude | agy
    model: str = "auto"

    # [R4] 全域逾時。**預設 120 與 0.4.3 相同** —— 升版不得改變既有部署的行為。
    #      per-agent 可用 `AgentDef.timeout` 覆蓋（實測 ai-dev 要 123s、data 只要 37s）。
    timeout: int = 120
    # [R2] 重試次數。**預設 0 是刻意的** —— 0.4.3 沒有重試，
    #      開新行為要由設定明示，不能因為升版就默默多花時間。
    #      只對 retryable 的錯誤重試（not_found / permission 不重試）。
    retries: int = 0

    # [R3] 進程池。三個都是「原本沒有」而不是「原本有別的值」——
    #      queue 原本**無上限**（無背壓、只會無聲堆積）、
    #      沒有 idle 回收（8 個常駐 kiro-cli 永不釋放）、
    #      沒有崩潰計數（崩潰迴圈偵測不到）。
    max_queue: int = 32
    idle_timeout: int = 1800         # 秒；0 = 不回收。persistent 的 agent 不受此限
    crash_window: int = 600          # 秒；崩潰計數用時間窗不用累計

    # [R3] 執行期狀態目錄覆寫。空 = 用 `get_home()/state`（與 0.6.0 同值）。
    #      env `ARK_BOT_STATE_DIR` 優先於此。相對路徑相對 `get_home()` 不是 cwd。
    #      消費端從舊 layout（例如 `data/sessions.db`）遷移時用這個，
    #      不必做 symlink。**注意：套件不搬檔，既有資料要自己搬。**
    state_dir: str = ""


@dataclass
class ReportConfig:
    """MD-first 報告管線（MD → HTML → TG）。"""

    enabled: bool = True
    md_dir: str = "output/reports"
    render_html: bool = True
    send_to_tg: bool = True
    min_chars: int = 150             # 短於此就直接 reply 純文字，不走管線


@dataclass
class FeaturesConfig:
    """功能開關 —— 關掉就不載入，省啟動時間。"""

    wiki: bool = True
    memory: bool = True
    scheduler: bool = True
    web_ui: bool = True
    a2a: bool = False                # 取代舊的 `_TEAM_MODE` 環境變數


@dataclass
class AccessConfig:
    """存取控制。

    🔴 **0.6.0 前這整段設定沒有任何人讀** —— `handlers` 只從環境變數
    `ADMIN_CHAT_IDS` 取白名單，而 `.env` 沒設時 `_ALLOWED_USERS` 是空集合
    → 「空＝不限制」→ **設了白名單卻對所有人開放**。
    這是「宣告了但沒接上」最危險的形狀：安全設定沒生效，而且看起來生效了。
    """

    #: 舊格式（仍支援）。載入時正規化成 `{id: "admin"}`。
    admin_chat_ids: list[int] = field(default_factory=list)
    #: 新格式：`{chat_id: "admin"|"user"}`。與上面**疊加**不是取代。
    users: dict[int, str] = field(default_factory=dict)

    # [R1] 群組策略。**這是修缺陷不是加功能** ——
    #      0.7.0 之前 handlers 零處 `chat.type` 判斷，所有訊息走同一條路：
    #      私訊時對的，**群組時它會回應每一則訊息**（群組立刻不能用）。
    #
    #      mention_only（預設）—— 只回被 @ 的；其餘**仍寫記憶**（群組是資訊來源）
    #      all              —— 每則都回（0.6.0 的行為，要舊行為設這個）
    #      off              —— 群組完全不參與
    #
    #      🔴 預設選 mention_only 而非沿用現行：**相容性保護的是
    #      「有人刻意依賴的行為」，不是「碰巧存在的缺陷」**。私訊行為完全不變。
    group_policy: str = "mention_only"


# ── agent 定義 ──────────────────────────────────────────────


@dataclass
class AgentDef:
    """單一 agent 的定義（來自 `agents.yaml`）。"""

    id: str
    dir: str = "."
    name: str = ""
    codename: str = ""
    emoji: str = "🤖"
    desc: str = ""
    dispatchable: bool = False
    persistent: bool = False
    skip_resume: bool = False
    role: str = "worker"
    group_members: list[str] = field(default_factory=list)
    # [R4] per-agent 逾時。`None` = 用 `backend.timeout`。
    #      不設定時行為與 0.4.3 完全相同。
    timeout: int | None = None

    @property
    def display(self) -> str:
        """`👑 管家` —— 給人看的稱呼。"""
        return f"{self.emoji} {self.codename or self.name or self.id}".strip()

    def steering(self, name: str = "") -> Path:
        """這個 agent 的 steering 路徑。

        **用 `dir` 欄位而不是拼 `{id}-agent`** —— id 與目錄名的對應由設定決定，
        自己拼在改名時會壞（M2 留下的兩個 TODO 就是這個）。
        """
        d = get_home() / self.dir / ".kiro" / "steering"
        return d / name if name else d

    @property
    def working_dir(self) -> Path:
        """工作目錄（**相對 home 解析**，不是相對 cwd）。"""
        return get_home() / self.dir


# ── 總設定 ──────────────────────────────────────────────────


@dataclass
class TeamBackendConfig:
    """外部 ark-team-agent 後台設定（headless 模式）。"""

    url: str = "http://localhost:13030"   # team-agent API 位址
    enabled: bool = False                  # 預設關，明確啟用才走 HTTP
    timeout: int = 120                     # 秒


@dataclass
class BotConfig:
    """Bot 的完整設定（`agents.yaml` + `bot.yaml` 合成）。"""

    name: str = "ark-bot"
    codename: str = ""
    server: ServerConfig = field(default_factory=ServerConfig)
    modes: ModesConfig = field(default_factory=ModesConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    team_backend: TeamBackendConfig = field(default_factory=TeamBackendConfig)
    backend: BackendConfig = field(default_factory=BackendConfig)
    report: ReportConfig = field(default_factory=ReportConfig)
    features: FeaturesConfig = field(default_factory=FeaturesConfig)
    access: AccessConfig = field(default_factory=AccessConfig)
    agents: dict[str, AgentDef] = field(default_factory=dict)

    # ── agent 查詢（**唯一來源**，不要在別處自己解析 agents.yaml）──

    def agent(self, agent_id: str) -> AgentDef | None:
        """取單一 agent 定義。"""
        return self.agents.get(agent_id)

    def dispatchable(self) -> list[str]:
        """可被 `dispatch_to_agent` 派工的 agent id。"""
        return [a.id for a in self.agents.values() if a.dispatchable]

    def group_members(self, leader_id: str | None = None) -> list[str]:
        """⚔️ 團隊模式下該 leader 可派工的成員。

        來源是 `agents.yaml` 的 `group_members`。**唯一來源就是設定檔** ——
        成員清單絕不寫進 prompt 字串，否則新增 agent 時必然漏改。

        未設時退回「所有 dispatchable 且不是自己」，並過濾設定裡不存在的 id
        （避免派給不存在的對象）。
        """
        leader_id = leader_id or self.modes.team_leader
        leader = self.agents.get(leader_id)
        declared = leader.group_members if leader else []

        if declared:
            members = [m for m in declared if m in self.agents]
            if dropped := [m for m in declared if m not in self.agents]:
                log.warning(
                    "group_members 有 %d 個不存在的 agent，已忽略：%s",
                    len(dropped), ", ".join(dropped),
                )
            return members

        log.info("%s 未設 group_members，退回所有 dispatchable", leader_id)
        return [a.id for a in self.agents.values() if a.dispatchable and a.id != leader_id]

    def describe(self, agent_ids: list[str]) -> str:
        """把 agent id 列表組成人可讀的多行說明（給 prompt 用）。"""
        return "\n".join(
            f"- `{aid}`　{a.display} —— {a.desc}"
            for aid in agent_ids
            if (a := self.agents.get(aid))
        )

    @property
    def report_dir(self) -> Path:
        """報告輸出目錄（`report.md_dir` 相對 home）。"""
        d = get_home() / self.report.md_dir
        d.mkdir(parents=True, exist_ok=True)
        return d


# ── 載入 ────────────────────────────────────────────────────


def _read_yaml(path: Path) -> dict:
    """讀 YAML，缺檔或空檔回空 dict。**一律 `safe_load`**。"""
    if not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        log.error("%s 解析失敗：%s", path.name, e)
        return {}
    return data if isinstance(data, dict) else {}


def load_agents(path: Path | None = None) -> dict[str, AgentDef]:
    """載入 `agents.yaml`。

    每個頂層 key 是 agent id（`default` / `admin` / `coder`…），
    值是該 agent 的欄位。未知欄位忽略。
    """
    raw = _read_yaml(path or get_config_file("agents.yaml"))
    out: dict[str, AgentDef] = {}
    for aid, body in raw.items():
        if not isinstance(body, dict):
            log.warning("agents.yaml 的 %r 不是 mapping，已忽略", aid)
            continue
        out[aid] = _pick(AgentDef, body, id=aid)
    if not out:
        log.warning("agents.yaml 沒有任何 agent 定義 —— 派工與模式切換都會失效")
    return out


def load(
    agents_path: Path | None = None, bot_path: Path | None = None
) -> BotConfig:
    """載入完整設定。

    Args:
        agents_path / bot_path: 測試用；預設從 `get_home()` 解析。

    缺 `bot.yaml` 時全部走預設值 —— **不拋例外**（原則②）。
    """
    bot_raw = _read_yaml(bot_path or get_config_file("bot.yaml"))

    modes_raw = dict(bot_raw.get("modes") or {})
    chat = _pick(ChatModeConfig, modes_raw.pop("chat", None))
    team = _pick(TeamModeConfig, modes_raw.pop("team", None))

    return _pick(
        BotConfig,
        bot_raw,
        server=_pick(ServerConfig, bot_raw.get("server")),
        modes=_pick(ModesConfig, modes_raw, chat=chat, team=team),
        llm=_pick(LLMConfig, bot_raw.get("llm")),
        # 🔴 [0.8.0] 這一行原本漏了 —— `team_backend` 是 `BotConfig` 的已知欄位，
        # 所以 `_pick` 會把 `bot.yaml` 的原始 dict **直接塞進去**，不會轉成 dataclass：
        #   · 沒寫 team_backend → 拿到預設值 `enabled=False` → **功能永遠無法啟用**
        #   · 寫了 team_backend → `cfg.team_backend` 是 **dict** →
        #     `router.run_team` 一碰 `.enabled` 就 AttributeError → ⚔️ 團隊模式壞掉
        #
        # 也就是「宣告了但沒接上」的又一個實例，而這次的形狀是**設了才會壞**。
        # 守門見 `test_config_wiring.py`（掃描 BotConfig 每個嵌套欄位是否都明確組裝）。
        team_backend=_pick(TeamBackendConfig, bot_raw.get("team_backend")),
        backend=_pick(BackendConfig, bot_raw.get("backend")),
        report=_pick(ReportConfig, bot_raw.get("report")),
        features=_pick(FeaturesConfig, bot_raw.get("features")),
        access=_pick(AccessConfig, bot_raw.get("access")),
        agents=load_agents(agents_path),
    )


_cached: BotConfig | None = None


def get_config(*, reload: bool = False) -> BotConfig:
    """取得設定（單例）。

    Args:
        reload: 強制重讀（測試或 hot reload 用）。

    執行期不該反覆重讀 —— 設定變更請重啟服務（比照 `ark_team_agent`：
    `team.yaml` / `scheduler.yaml` 都只在啟動時載入）。
    """
    global _cached
    if _cached is None or reload:
        _cached = load()
    return _cached


def reset_config_cache() -> None:
    """清掉設定快取。**只給測試用**。"""
    global _cached
    _cached = None


__all__ = [
    "MODES",
    "AccessConfig",
    "AgentDef",
    "BackendConfig",
    "BotConfig",
    "ChatModeConfig",
    "FeaturesConfig",
    "LLMConfig",
    "ModesConfig",
    "ReportConfig",
    "ServerConfig",
    "TeamBackendConfig",
    "TeamModeConfig",
    "get_config",
    "load",
    "load_agents",
    "reset_config_cache",
]
