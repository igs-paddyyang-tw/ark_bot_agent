"""Bot 啟動編排 —— `run_bot()` 與 `create_bot()` 的實作。

消費端的 `start.py` 只要：

    from ark_bot_agent import run_bot
    run_bot()

## Tier 分級（沿用 nana-bot 的設計）

| Tier | 內容 | 需要 |
|:----:|------|------|
| 0 | Prompts + Skills + Wiki | 永遠可用 |
| 1 | Telegram Bot | `TELEGRAM_BOT_TOKEN` |
| 2 | Gemini AI + RAG | `GEMINI_API_KEY` |
| 3 | Agent 分身常駐 | kiro-cli / claude / agy |

**缺憑證不該讓服務起不來** —— 少一個 Tier 就少一組功能，其餘照跑。
這讓部署可以分段驗收（先跑 Tier 0/3，token 之後補）。
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Sequence

from ark_bot_agent import paths
from ark_bot_agent.config import BotConfig, get_config

log = logging.getLogger(__name__)

Hook = Callable[["Bot"], Any]

_LINE = "═" * 50


def _tier_flags() -> dict[int, tuple[bool, str]]:
    """回傳各 Tier 的 `(是否可用, 說明)`。"""
    from ark_bot_agent.agent.cli import get_available_backend, is_cli_available

    cli = is_cli_available()
    return {
        0: (True, "Prompts + Skills + Wiki"),
        1: (bool(os.getenv("TELEGRAM_BOT_TOKEN")), "Telegram Bot"),
        2: (bool(os.getenv("GEMINI_API_KEY")), "Gemini AI + RAG"),
        3: (cli, f"Agent 分身常駐（backend: {get_available_backend()}）" if cli
            else "Agent 分身（未偵測到 kiro-cli / agy / claude）"),
    }


@dataclass
class Bot:
    """組裝好的 Bot。`create_bot()` 產生，`run()` 啟動。"""

    config: BotConfig
    router: Any = None                                   # ModeRouter
    skill_packages: list[str] = field(default_factory=list)
    extra_tools: list[Any] = field(default_factory=list)
    on_startup: list[Hook] = field(default_factory=list)
    on_shutdown: list[Hook] = field(default_factory=list)

    # ── 啟動報告 ────────────────────────────────────────────

    def startup_report(self) -> str:
        """組出啟動摘要。

        **所有數字都從實際狀態算**，不寫死 —— 寫死的數字會在內容變動後說謊
        （`start.py` 原本就有「8 active」這種硬編）。
        """
        cfg = self.config
        lines = [_LINE, f"  🤖 {cfg.name}" + (f"（{cfg.codename}）" if cfg.codename else ""), _LINE]

        for tier, (ok, desc) in _tier_flags().items():
            lines.append(f"  Tier {tier}: {'✅' if ok else '⬚'} {desc}")
        lines.append(_LINE)

        # 設定檔狀態 —— 缺哪些走了預設要講出來
        status = paths.config_status()
        missing = [n for n, exists in status.items() if not exists and n != paths.SENTINEL]
        lines.append("")
        lines.append(f"  ⚙️  設定: {', '.join(n for n, e in status.items() if e) or '（無）'}"
                     + (f"　⬚ 未提供（走預設）: {', '.join(missing)}" if missing else ""))

        internal, consumer = self._load_skills()
        skills_line = f"  📦 Skills: IDE {self._count_ide_skills()} | 內建 {internal}"
        if self.skill_packages:
            # 有注入卻是 0 就把它講出來 —— 這正是先前靜默失效的樣子
            mark = "" if consumer else "  ⚠️ 注入了 " + "、".join(self.skill_packages) + " 但一個都沒載到"
            skills_line += f" | 消費端 {consumer}{mark}"
        lines.append(skills_line)

        w = self._wiki_counts()
        lines.append(f"  📚 Wiki:   shared {w['shared_wiki']} | raw {w['shared_raw']} | agents {w['agent_wiki']}")
        lines.append(f"  🔍 Lint:   {self._wiki_lint()}")
        lines.append(f"  🧠 SOUL:   {'✅ 已載入' if paths.get_steering('SOUL.md').is_file() else '⚠️ 未找到'}")
        lines.append(f"  🧠 Agents: {len(cfg.agents)} 定義 | 可派工 {len(cfg.dispatchable())}")
        lines.append(f"  📝 Report: {'✅ ' + cfg.report.md_dir if cfg.report.enabled else '⬚ 關閉'}")
        if cfg.features.a2a:
            lines.append("  🤝 A2A:    ✅ 已掛載")

        base = f"http://localhost:{cfg.server.port}"
        lines += ["", "  ── Web UI ──"]
        for label, path in (("Chat", ""), ("Dashboard", "/admin"), ("Wiki", "/wiki")):
            lines.append(f"  {label:10} {base}{path}")
        lines += ["  ── API ──", f"  {'Health':10} {base}/health", f"  {'Docs':10} {base}/api-docs"]
        return "\n".join(lines)

    # ── 各項統計（都從實際狀態算）──────────────────────────

    def _count_ide_skills(self) -> int:
        d = paths.get_skills_dir()
        return len(list(d.glob("ark-*"))) if d.is_dir() else 0

    def _load_skills(self) -> tuple[int, int]:
        """把消費端注入的 package 登記進**共用** registry，回傳 `(內建, 消費端)`。

        🔴 原本這裡自己開一份 `SkillRegistry()`，於是消費端 skill 只存在於這份
        統計用的表裡 —— server 與提詞組裝各自再開一份、看不到，
        而啟動橫幅仍然顯示「Internal 15」。**數字對，事實錯。**
        """
        from ark_bot_agent.skills.registry import INTERNAL_PACKAGE, get_registry, register_package

        for pkg in self.skill_packages:
            register_package(pkg)

        reg = get_registry()
        self._registry = reg
        # 內建與消費端**分開報** —— 混成一個總數會藏住「消費端根本沒載到」
        internal = reg.count_in(INTERNAL_PACKAGE)
        return internal, len(reg.list_skills()) - internal

    def _wiki_counts(self) -> dict[str, int]:
        k = paths.get_knowledge_dir()
        def n(p: Path) -> int:
            return len(list(p.rglob("*.md"))) if p.is_dir() else 0
        agents = sum(n(d / "knowledge" / "wiki") for d in paths.get_agents_dir().glob("*"))
        return {
            "shared_wiki": n(k / "shared" / "wiki"),
            "shared_raw": n(k / "shared" / "raw"),
            "agent_wiki": agents,
        }

    def _wiki_lint(self) -> str:
        try:
            from ark_bot_agent.wiki.engine import WikiEngine

            issues = WikiEngine().lint()
        except Exception as e:                            # noqa: BLE001
            return f"⚠️ 無法執行（{type(e).__name__}）"
        return "✅ 0 issues" if not issues else f"⚠️ {len(issues)} issues"

    # ── 啟動 ────────────────────────────────────────────────

    def run(self) -> None:
        """印啟動報告後跑 uvicorn（阻塞）。"""
        import uvicorn

        print(self.startup_report())
        print()

        for hook in self.on_startup:
            try:
                hook(self)
            except Exception as e:                        # noqa: BLE001
                log.error("on_startup hook 失敗：%s", e)

        cfg = self.config
        try:
            uvicorn.run(
                "ark_bot_agent.server.main:app",
                host=cfg.server.host,
                # port 只有這一個來源 —— 顯示與實際綁定不得分開寫
                # （原本 start.py 印 8000 實際綁 8088，就是寫兩處造成的）
                port=cfg.server.port,
                reload=False,
            )
        except KeyboardInterrupt:
            print("\n  👋 服務已停止")
        finally:
            for hook in self.on_shutdown:
                try:
                    hook(self)
                except Exception as e:                    # noqa: BLE001
                    log.error("on_shutdown hook 失敗：%s", e)


def create_bot(
    *,
    config: BotConfig | None = None,
    router: Any = None,
    skills: Sequence[str] | None = None,
    tools: Sequence[Any] | None = None,
    on_startup: Sequence[Hook] | None = None,
    on_shutdown: Sequence[Hook] | None = None,
    load_env: bool = True,
    chdir: bool = True,
) -> Bot:
    """組裝 Bot（**不啟動**）。消費端要注入自訂邏輯時用這個。

    Args:
        config: 預設從 `agents.yaml` + `bot.yaml` 載入
        router: 自訂 `ModeRouter`（ninja-bot 需要）
        skills: 額外的 skill 掃描路徑（套件內建仍會載入）
        tools: 額外的 ReAct tool
        on_startup / on_shutdown: 生命週期 hook
        load_env: 是否 `load_dotenv()`（機密只從 `.env` 來）
        chdir: 是否切到 `get_home()` —— kiro-cli 子進程與部分 skill 仍依賴 cwd
    """
    if load_env:
        from dotenv import load_dotenv

        load_dotenv(paths.get_home() / ".env")

    if chdir:
        os.chdir(paths.get_home())

    from ark_bot_agent.logging_config import setup_logging

    setup_logging()

    cfg = config or get_config()

    if router is None:
        from ark_bot_agent.bot.router import ModeRouter

        router = ModeRouter(cfg)

    bot = Bot(
        config=cfg,
        router=router,
        skill_packages=list(skills or []),
        extra_tools=list(tools or []),
        on_startup=list(on_startup or []),
        on_shutdown=list(on_shutdown or []),
    )

    if bot.extra_tools:
        from ark_bot_agent.llm.tool_registry import registry as tool_registry

        for t in bot.extra_tools:
            tool_registry.register(t)

    return bot


def run_bot(**kwargs: Any) -> None:
    """組裝並啟動（零 code 用法）。參數同 `create_bot()`。"""
    create_bot(**kwargs).run()


__all__ = ["Bot", "create_bot", "run_bot"]
