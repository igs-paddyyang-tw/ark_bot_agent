"""ProgressStack — 堆疊式進度訊息，透過 edit_message 原地更新。"""
from __future__ import annotations

import logging
import re

log = logging.getLogger(__name__)


def md_to_tg_html(text: str) -> str:
    """將 Gemini 回的 Markdown 轉為 TG 支援的 HTML。

    支援：粗體、斜體、行內程式碼、程式碼區塊、標題、清單、連結。
    不支援的標記直接保留純文字。
    長文自動截斷至 TG 4096 字元限制。
    """
    if not text:
        return ""

    # 先處理程式碼區塊（避免內部被轉換）
    code_blocks: list[str] = []

    def _store_code(m):
        code_blocks.append(m.group(1))
        return f"__CODE_BLOCK_{len(code_blocks) - 1}__"

    text = re.sub(r"```(?:\w*)\n?(.*?)```", _store_code, text, flags=re.DOTALL)

    # 行內程式碼先保護起來
    inline_codes: list[str] = []

    def _store_inline(m):
        inline_codes.append(m.group(1))
        return f"__INLINE_CODE_{len(inline_codes) - 1}__"

    text = re.sub(r"`([^`]+)`", _store_inline, text)

    # HTML 特殊字元跳脫（在轉換前處理）
    text = text.replace("&", "&amp;")
    text = text.replace("<", "&lt;")
    text = text.replace(">", "&gt;")

    # 標題 → 粗體 + 換行
    text = re.sub(r"^#{1,3}\s+(.+)$", r"\n<b>\1</b>", text, flags=re.MULTILINE)

    # 粗體 **text**
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)

    # 斜體 *text*（單星號）
    text = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"<i>\1</i>", text)

    # 清單符號 - item 或 * item → • item
    text = re.sub(r"^[-*]\s+", "• ", text, flags=re.MULTILINE)

    # 連結 [text](url) → TG <a href>
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)

    # 分隔線 --- / *** → 空行
    text = re.sub(r"^[-*]{3,}\s*$", "", text, flags=re.MULTILINE)

    # 表格簡化處理（移除 | 邊框，保留內容）
    text = re.sub(r"^\|[-:| ]+\|$", "", text, flags=re.MULTILINE)  # 移除分隔行
    text = re.sub(r"^\|\s*(.+?)\s*\|$",
                  lambda m: "  ".join(c.strip() for c in m.group(1).split("|")),
                  text, flags=re.MULTILINE)

    # 還原行內程式碼
    for i, code in enumerate(inline_codes):
        escaped = code.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        text = text.replace(f"__INLINE_CODE_{i}__", f"<code>{escaped}</code>")

    # 還原程式碼區塊
    for i, code in enumerate(code_blocks):
        escaped_code = code.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        text = text.replace(f"__CODE_BLOCK_{i}__", f"<pre>{escaped_code}</pre>")

    # TG 4096 字元限制 → 不在這裡截斷，由呼叫端（ProgressStack）處理分段。
    # 只在極端情況（單段超長）留最基本保護。

    # 清理多餘空行（最多保留 2 個連續換行）
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


def _split_html_safe(html: str, max_len: int = 4000) -> list[str]:
    """把長 HTML 文字切成 ≤ max_len 的段落。

    切點策略（優先順序）：
    1. 雙換行（段落邊界）
    2. 單換行
    3. 最後才硬切

    不保證 HTML tag 完整 —— TG 對 unclosed tag 容錯度夠高，
    而且我們的 md_to_tg_html 產出的 tag 都在同一行內。
    """
    if len(html) <= max_len:
        return [html]

    chunks: list[str] = []
    remaining = html

    while len(remaining) > max_len:
        # 在 max_len 範圍內找最後一個雙換行
        cut = remaining.rfind("\n\n", 0, max_len)
        if cut < max_len // 2:
            # 找不到好的雙換行切點，退而求其次找單換行
            cut = remaining.rfind("\n", 0, max_len)
        if cut < max_len // 4:
            # 完全找不到換行，硬切
            cut = max_len

        chunks.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip("\n")

    if remaining.strip():
        chunks.append(remaining.strip())

    return chunks


class ProgressStack:
    """堆疊式進度訊息。

    使用者看到一條不斷更新的進度訊息，清楚知道目前在哪一步。
    透過 TG edit_message_text 原地更新，不發多條通知。

    狀態符號：
        ⏳ 進行中
        ✅ 完成
        ❌ 失敗
    """

    def __init__(self, chat_id: int, bot):
        self.chat_id = chat_id
        self.bot = bot
        self.message_id: int | None = None
        self.steps: list[str] = []

    async def init(self, first_step: str) -> None:
        """發送第一條進度訊息，記錄 message_id。"""
        self.steps.append(f"⏳ {first_step}")
        try:
            msg = await self.bot.send_message(self.chat_id, self._render())
            self.message_id = msg.message_id
        except Exception as e:
            log.warning("ProgressStack.init failed: %s", e)

    async def update(self, step: str, complete_previous: bool = True) -> None:
        """標記上一步完成 + 新增下一步。"""
        if complete_previous and self.steps:
            last = self.steps[-1]
            if last.startswith("⏳"):
                self.steps[-1] = last.replace("⏳", "✅", 1)
        self.steps.append(f"⏳ {step}")
        await self._edit()

    async def complete(self, final_text: str) -> None:
        """標記全部完成，用 HTML 格式化的最終回覆取代進度訊息。

        長文策略：
        - ≤ 4000 字元：原地 edit 一次搞定
        - > 4000 字元：edit 第一段 + send_message 後續各段
          （TG 單則上限 4096，留 96 字元給 HTML tag / emoji 緩衝）
        """
        html = md_to_tg_html(final_text)

        # 短文：原地更新即可
        if len(html) <= 4000:
            await self._edit(html, use_html=True)
            return

        # 長文：分段（在 HTML tag 外找安全切點）
        chunks = _split_html_safe(html, max_len=4000)

        # 第一段用 edit 覆蓋進度訊息
        await self._edit(chunks[0], use_html=True)

        # 後續段用 send_message
        for chunk in chunks[1:]:
            try:
                await self.bot.send_message(
                    chat_id=self.chat_id,
                    text=chunk,
                    parse_mode="HTML",
                )
            except Exception:
                # HTML 解析失敗時 fallback 純文字
                try:
                    plain = re.sub(r"<[^>]+>", "", chunk)
                    await self.bot.send_message(
                        chat_id=self.chat_id, text=plain
                    )
                except Exception:
                    pass

    async def fail(self, error: str) -> None:
        """標記當前步驟失敗。"""
        if self.steps and self.steps[-1].startswith("⏳"):
            self.steps[-1] = self.steps[-1].replace("⏳", "❌", 1)
        self.steps.append(error)
        await self._edit()

    def _render(self) -> str:
        """渲染進度文字（純文字，無格式）。"""
        return "\n".join(self.steps)

    async def _edit(self, text: str | None = None, use_html: bool = False) -> None:
        """編輯進度訊息。靜默處理錯誤。"""
        if not self.message_id:
            return
        content = text or self._render()
        # TG 限制 4096 字元
        if len(content) > 4000:
            content = content[:4000] + "\n\n⋯（已截斷）"
        try:
            await self.bot.edit_message_text(
                chat_id=self.chat_id,
                message_id=self.message_id,
                text=content,
                parse_mode="HTML" if use_html else None,
            )
        except Exception as e:
            # HTML 解析失敗時 fallback 到純文字
            if use_html:
                try:
                    # 去掉 HTML tags fallback
                    plain = re.sub(r"<[^>]+>", "", content)
                    await self.bot.edit_message_text(
                        chat_id=self.chat_id,
                        message_id=self.message_id,
                        text=plain,
                    )
                except Exception:
                    pass
