"""Bot 獨立進程入口 — TG Bot + Agent 常駐服務。"""
import asyncio
import os
import sys
from pathlib import Path

from ark_bot_agent.paths import get_home

# 確保工作目錄正確
# 切到消費端專案根 —— kiro-cli 子進程與部分 skill 仍依賴 cwd。
# 用哨兵搜尋而非數 .parent 層數（套件安裝後層數必然不同）。
os.chdir(get_home())
sys.path.insert(0, str(Path.cwd()))

from dotenv import load_dotenv
load_dotenv()

from ark_bot_agent.logging_config import setup_logging
setup_logging()


async def main():
    import logging
    log = logging.getLogger("bot.run")
    
    # 啟動 Agent 常駐服務
    from ark_bot_agent.agent.cli import is_cli_available, start_all_agents
    if is_cli_available():
        count = await start_all_agents()
        log.info("Agent 服務: %d 個已啟動", count)
    
    # 啟動 TG Bot
    tg_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    if not tg_token:
        log.error("TELEGRAM_BOT_TOKEN 未設定")
        return
    
    from ark_bot_agent.bot.main import create_app, BOT_COMMANDS
    bot_app = create_app()
    await bot_app.initialize()
    # 注意：_post_init 已在 initialize() 時設置指令選單，不需重複呼叫
    await bot_app.updater.start_polling(drop_pending_updates=True)
    await bot_app.start()
    log.info("TG Bot polling 已啟動")
    
    # 保持運行
    try:
        await asyncio.Event().wait()
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        await bot_app.updater.stop()
        await bot_app.stop()
        await bot_app.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
