"""Inline Keyboard 分行建構（[R9]，自 ninja-bot 搬入）。

純 UI 工具，無業務語意 —— 每個消費端都要自己組 Inline Keyboard，
而「一行放幾個」「callback_data 上限 64 bytes」是 Telegram 的規則不是誰的偏好。

⚠️ `callback_data` 超過 64 bytes 會**拋 ValueError 而不是截斷** ——
截斷會產生一個看起來正常但點下去對應不到任何處理器的按鈕。
"""
from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

_MAX_PER_ROW = 2
_MAX_CALLBACK_DATA_BYTES = 64


def build_keyboard(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    """依 (label, callback_data) 巢狀列表建構 Inline Keyboard。

    Args:
        rows: 每行為 (label, callback_data) tuple 列表。

    Rules:
        - 單行超過 2 個按鈕時自動拆成每行 2 個
        - 例外：3 個按鈕且每個 label ≤ 4 字時允許同行
        - callback_data 超過 64 bytes 會拋出 ValueError

    Returns:
        InlineKeyboardMarkup
    """
    keyboard_rows: list[list[InlineKeyboardButton]] = []
    for row in rows:
        for sub_row in _chunk_row(row):
            keyboard_rows.append([_make_button(label, data) for label, data in sub_row])
    return InlineKeyboardMarkup(keyboard_rows)


def auto_layout(buttons: list[tuple[str, str]]) -> list[list[tuple[str, str]]]:
    """將扁平按鈕列表依分行規則自動排版。

    Args:
        buttons: (label, callback_data) tuple 扁平列表。

    Returns:
        巢狀列表，每個子列表為一行。
    """
    return _chunk_row(buttons)


def _chunk_row(
    buttons: list[tuple[str, str]],
    max_per_row: int = _MAX_PER_ROW,
) -> list[list[tuple[str, str]]]:
    """依分行規則將一組按鈕切分成多行。"""
    if len(buttons) == 3 and all(len(label) <= 4 for label, _ in buttons):
        return [buttons]
    return [buttons[i : i + max_per_row] for i in range(0, len(buttons), max_per_row)]


def _make_button(label: str, callback_data: str) -> InlineKeyboardButton:
    """建構單一按鈕並驗證 callback_data 長度。"""
    data_bytes = len(callback_data.encode("utf-8"))
    if data_bytes > _MAX_CALLBACK_DATA_BYTES:
        raise ValueError(
            f"callback_data 超過 Telegram 限制 {_MAX_CALLBACK_DATA_BYTES} bytes："
            f"{callback_data!r}（{data_bytes} bytes）"
        )
    return InlineKeyboardButton(text=label, callback_data=callback_data)
