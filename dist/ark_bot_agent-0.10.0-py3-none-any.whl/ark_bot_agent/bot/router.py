"""三模式路由 —— **模式由使用者選，不靠 AI 猜**。

同一句話在不同模式下該有不同的處理成本，讓人決定比讓模型判斷準確
（也省掉一次意圖分類的 LLM 呼叫）。這是 ninja-bot 驗證過的設計。

## 四條路徑

    @代號          → 直送該 agent（**不受模式影響**）
    💬 chat       → 娜娜 Gemini ReAct（wiki／上網／選擇性派工）
    👑 agent      → 單一職人 on kiro-cli（預設 admin）
    ⚔️ team       → leader 三階段工作流（規劃 → 執行 → 收斂）

## 為什麼是類別而不是一堆 if

消費端要能換策略（ninja-bot 有自己的路由規則）。
`create_bot(router=MyRouter())` 覆寫 `route()` 或任一 `run_*()` 即可，
不必 fork 整個 handlers。
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from ark_bot_agent.config import BotConfig, get_config

log = logging.getLogger(__name__)

# `@碼哥 內容` / `@coder 內容` / `@coder-agent 內容`
_MENTION = re.compile(r"@([\w一-鿿-]+)\s*(.*)", re.DOTALL)

ProgressFn = Callable[[str], Awaitable[None]]


def clean_cli_output(raw: str | None) -> str:
    """把 kiro-cli 的原始輸出清成給人看的答覆（`clean_output` → `extract_final_reply`）。

    🔴 **必須在 `_maybe_report()` 之前做。** 過濾原本只掛在 TG 層（`handlers.py`），
    而報告管線在 router 裡 —— 順序反了會讓 MD/HTML **存進工具雜訊**
    （`I will run the following command: … (using tool: shell)`），
    而畫面上看起來是乾淨的，因為 TG 那層之後又清了一次。

    清乾淨後變空字串就回原文 —— 寧可讓人看到雜訊，也不要回一片空白。
    """
    if not raw:
        return ""
    from ark_bot_agent.bot.output_filter import clean_output, extract_final_reply

    return extract_final_reply(clean_output(raw)) or raw


@dataclass
class MessageContext:
    """一則訊息的路由輸入。

    刻意不吃 `telegram.Update` —— 套件不該綁定訊息從哪來
    （Web UI／CLI／測試都該能走同一條路由）。
    """

    text: str
    session: Any                                  # UserSession
    on_progress: ProgressFn | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def mention(self) -> tuple[str, str] | None:
        """`(目標, 剩餘內容)`；沒有 @mention 回 `None`。"""
        if m := _MENTION.match(self.text):
            target = m.group(1)
            rest = m.group(2).strip() or self.text
            return target, rest
        return None


@dataclass
class Reply:
    """路由結果。"""

    text: str | None = None
    agent_id: str | None = None                   # 誰回的（None = 娜娜）
    decision: str = ""                            # 給 trace 用的一句話
    report: Any = None                            # ReportResult（如有產報告）

    @property
    def ok(self) -> bool:
        return bool(self.text)


class ModeRouter:
    """預設三模式路由。消費端可繼承覆寫。"""

    def __init__(self, config: BotConfig | None = None):
        self._config = config

    @property
    def config(self) -> BotConfig:
        """延遲取設定 —— 讓 `get_config(reload=True)` 之後會生效。"""
        return self._config or get_config()

    # ── 對外入口 ────────────────────────────────────────────

    async def route(self, ctx: MessageContext) -> Reply:
        """依模式分派。**@mention 優先於任何模式**。"""
        if mention := ctx.mention:
            target, rest = mention
            if agent_id := self.resolve_agent(target):
                return await self.run_agent(ctx, agent_id, text=rest)
            return Reply(text=f"🤔 不認識「{target}」欸，用 /agents 看看有誰？",
                         decision="mention-unknown")

        kind = getattr(ctx.session, "mode_kind", "chat")
        if kind == "chat":
            return await self.run_chat(ctx)
        if kind == "team":
            return await self.run_team(ctx)
        return await self.run_agent(ctx, ctx.session.agent_name or self.config.modes.default_agent)

    def resolve_agent(self, target: str) -> str | None:
        """把使用者輸入的稱呼解析成 agent id。

        支援三種寫法：id（`coder`）、帶後綴（`coder-agent`）、代號（`碼哥`）。
        **`default`（娜娜）不算** —— 它不是可直送的對象。
        """
        agents = self.config.agents
        name = target.strip().removesuffix("-agent")
        if name in agents and name != "default":
            return name
        for aid, a in agents.items():
            if aid == "default":
                continue
            if target.strip() in {a.codename, a.name}:
                return aid
        return None

    # ── 三個模式的實作（消費端可各自覆寫）────────────────────

    async def run_chat(self, ctx: MessageContext) -> Reply:
        """💬 快答 —— 娜娜的 Gemini ReAct loop。"""
        from ark_bot_agent.llm.agent_loop import agent_loop
        from ark_bot_agent.llm.context_builder import build_default_system_prompt

        await self._tick(ctx, "想一下⋯")
        prompt = await build_default_system_prompt(query=ctx.text, session=ctx.session)
        chat = self.config.modes.chat
        result = await agent_loop(
            user_message=ctx.text,
            system_prompt=prompt,
            max_iterations=chat.max_iterations,
            # 白名單只在快答模式套用 —— agent 模式的 fallback 走全部工具
            allowed_tools=chat.tools,
        )
        dispatched = [t for t in (result.tool_calls_log or []) if t.get("tool") == "dispatch_to_agent"]
        targets = [t["args"].get("target_agent", "") for t in dispatched]
        reply = Reply(
            text=result.text,
            decision=f"派工→{targets[-1]}" if targets else "直答",
        )
        return await self._maybe_report(ctx, reply, mode="chat", agents=targets)

    async def run_agent(self, ctx: MessageContext, agent_id: str, *, text: str | None = None) -> Reply:
        """👑 管家 —— 單一 agent on kiro-cli。**不經 LLM provider。**

        kiro-cli 自己就是大腦（讀自己的 SOUL／skills／wiki／memory），
        套件只負責 spawn 與 IO。
        """
        from ark_bot_agent.agent.cli import agent_cli_chat, is_cli_available

        a = self.config.agent(agent_id)
        label = a.display if a else agent_id
        await self._tick(ctx, f"{label}思考中⋯")

        if not is_cli_available():
            return await self._agent_fallback(ctx, agent_id, text or ctx.text)

        res = await agent_cli_chat(text or ctx.text, agent_id=agent_id, session=ctx.session)
        if not res.is_ok():
            # [0.5.0] 失敗現在看得出來了 —— 舊版回 None，呼叫端只知道「沒東西」
            log.warning("run_agent %s 失敗：%s（retryable=%s, %dms）",
                        agent_id, res.error, res.retryable, res.elapsed_ms)
        reply = Reply(text=clean_cli_output(res.reply_text()), agent_id=agent_id,
                      decision=f"cli:{agent_id}")
        return await self._maybe_report(ctx, reply, mode="agent", agents=[agent_id])

    async def run_team(self, ctx: MessageContext) -> Reply:
        """⚔️ 團隊 —— 優先走 team_backend HTTP API，降級走本地 team_flow。"""
        from ark_bot_agent.agent.cli import is_cli_available

        cfg = self.config

        # [0.8.0] 優先走 team_backend（ark-team-agent headless API）
        if cfg.team_backend.enabled:
            from ark_bot_agent.agent.team_client import TeamClient
            client = TeamClient(url=cfg.team_backend.url, timeout=cfg.team_backend.timeout)
            await self._tick(ctx, "⚔️ 團隊派工中⋯")
            result = await client.dispatch(ctx.text)
            if result.ok:
                reply = Reply(text=clean_cli_output(result.reply),
                              agent_id=result.agent_id, decision=f"team-api:{result.agent_id}")
                return await self._maybe_report(ctx, reply, mode="team", agents=[result.agent_id])

            # 🔴 `queued` 不可降級 —— 訊息已經進 team-agent 的 overflow 佇列，
            # 會在 agent 就緒後投遞。再跑一次本地 team_flow 就是**同一件事做兩遍**。
            # 這是唯一「失敗但不該重試」的分類，靠 `status` 才分得出來（`ok` 分不出）。
            if result.status == "queued":
                log.info("team_backend 已排隊（agent 未就緒），不降級以免重複派工")
                return Reply(
                    text=f"⏳ 團隊成員尚未就緒，訊息已排入佇列（{result.agent_id or '團隊'}）"
                         "，就緒後會處理。",
                    agent_id=result.agent_id, decision="team-api:queued",
                )

            # 其餘失敗：降級走本地。log 帶 status / retryable，
            # 否則只看到 error 字串分不出「服務沒開」還是「agent 沒回」。
            log.warning("team_backend 失敗（status=%s retryable=%s http=%s）：%s"
                        " → 降級走本地 team_flow",
                        result.status, result.retryable, result.http_status, result.error)

        # 降級：原有本地 team_flow
        from ark_bot_agent.bot.team_flow import run_team_flow

        leader = cfg.modes.team_leader
        if not is_cli_available():
            log.warning("團隊模式需要 CLI backend，降級為單一 agent")
            return await self._agent_fallback(ctx, leader, ctx.text)

        await self._tick(ctx, "⚔️ 團隊派工中⋯")
        answer = await run_team_flow(
            ctx.text, session=ctx.session, leader_id=leader, on_progress=ctx.on_progress
        )
        reply = Reply(text=clean_cli_output(answer), agent_id=leader, decision=f"team:{leader}")
        members = [leader, *cfg.group_members(leader)]
        return await self._maybe_report(ctx, reply, mode="team", agents=members)

    # ── 報告管線（三模式共用）──────────────────────────────

    async def _maybe_report(
        self, ctx: MessageContext, reply: Reply, *, mode: str, agents: list[str]
    ) -> Reply:
        """夠長的回覆就產報告（MD → HTML → TG），並把降級說明附回去。

        **短回覆不走管線**（spec R-5）—— 一句結論產一份 HTML 只是噪音。
        門檻由 `report.min_chars` 決定。

        `send` 從 `ctx.extra["send_document"]` 取 —— 套件不知道呼叫端怎麼送檔，
        由呼叫端注入（`sender.DocumentSender` 協議）。
        """
        cfg = self.config
        if not cfg.report.enabled or not reply.text:
            return reply
        if len(reply.text) < cfg.report.min_chars:
            return reply

        from ark_bot_agent.report import deliver_report

        try:
            result = await deliver_report(
                title=self._report_title(ctx.text),
                body=reply.text,
                mode=mode,
                out_dir=cfg.report_dir,
                agents=agents,
                send=ctx.extra.get("send_document") if cfg.report.send_to_tg else None,
                render=cfg.report.render_html,
            )
        except OSError as e:
            # MD 寫入失敗 —— 報告沒了，但**對話回覆本身仍然有效**，不該連帶失敗
            log.error("報告 MD 寫入失敗，只回文字：%s", e)
            return reply

        reply.report = result
        if note := result.user_note():
            reply.text = f"{reply.text}\n\n{note}"
        return reply

    @staticmethod
    def _report_title(text: str, *, max_len: int = 30) -> str:
        """用使用者訊息的開頭當報告標題。

        刻意不叫 LLM 取標題 —— 那是一次額外的往返與費用，
        而檔名只要能讓人認出是哪次對話就夠了。
        """
        first = text.strip().splitlines()[0] if text.strip() else "對話報告"
        return first[:max_len].strip() or "對話報告"

    # ── 內部 ────────────────────────────────────────────────

    async def _agent_fallback(self, ctx: MessageContext, agent_id: str, text: str) -> Reply:
        """CLI 不可用時，用該 agent 的 SOUL 走 Gemini。

        這是**降級**不是等價替代 —— agent 的 skills 與 memory 都用不到。
        """
        from ark_bot_agent.llm.agent_loop import agent_loop

        a = self.config.agent(agent_id)
        soul = ""
        if a and (p := a.steering("SOUL.md")).is_file():
            soul = p.read_text(encoding="utf-8")
        result = await agent_loop(user_message=text, system_prompt=soul, max_iterations=3)
        return Reply(text=result.text, agent_id=agent_id, decision=f"fallback:{agent_id}")

    async def _tick(self, ctx: MessageContext, msg: str) -> None:
        """更新進度（失敗不影響主流程）。"""
        if ctx.on_progress:
            try:
                await ctx.on_progress(msg)
            except Exception:                      # noqa: BLE001
                pass


__all__ = ["MessageContext", "ModeRouter", "Reply"]
