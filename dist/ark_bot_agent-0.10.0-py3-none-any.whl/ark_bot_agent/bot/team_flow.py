"""⚔️ 團隊模式：leader 規劃 → Python 代為執行 → leader 收斂。

## 為什麼要兩段式

nana-bot 是個體模式，**leader 的 `mcp.json` 是空的**（0 個 server）——
它沒有任何跨 agent 通訊工具，只能在回覆裡「口頭說」該派給誰。
而唯一真正能派工的 `dispatch_to_agent` 是 Gemini function calling 的 tool，
只有 💬 快答模式（娜娜）用得到。

所以這裡把 ReAct 的迴圈搬到 Python 層：

    leader 出結構化計畫  →  Python 逐一執行  →  結果回給 leader 收斂

這是 nana-bot **不需要 function calling、也不需要自建 MCP server**
就能做多步協作的唯一方式。每一步都可觀測、可攔截。

## 已知的 kiro-cli 解析陷阱（ninja 專案踩過）

1. 輸出含 ANSI 控制碼 → 必須清洗
2. 模型中途改用工具時 kiro-cli 會**回顯工具參數**（也是 JSON）→ 一律取**最後一個**
3. 模型會自己編機器欄位 → **不要用 `setdefault` 補填**，缺就當它沒給
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Awaitable, Callable

log = logging.getLogger(__name__)

# [M3.2] 這四個參數原本是模組常數，改讀 `bot.yaml` 的 `modes.team`。
# 在函式內取（而非模組層）—— 這樣 `get_config(reload=True)` 之後會生效，
# 測試也能直接改設定而不用 monkeypatch 模組屬性。
#
# 預設值的來由（實測三人派工）：
#   data 37s ✅ / report 50s ✅ / ai-dev **123s**
#   前兩人早就好了，但 `asyncio.gather` 要等最慢的 → 使用者白等 73 秒。
#   所以 stage_deadline=100：到點就用**已完成的**去收斂。
#   member_reply_cap=2500：ai-dev 一次回 9426 chars，三人原文會讓收斂 prompt 破萬字。


def _team_cfg():
    """取 ⚔️ 團隊模式的設定（`modes.team`）。"""
    from ark_bot_agent.config import get_config

    return get_config().modes.team

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]")

ProgressFn = Callable[[str], Awaitable[None]]


def _strip_ansi(text: str) -> str:
    """清掉 ANSI 控制碼（kiro-cli 的輸出一定有）。"""
    return _ANSI_RE.sub("", text)


def extract_last_json(text: str) -> dict | None:
    """從純文字裡取出**最後一個**完整的 JSON object。

    為什麼取最後一個：模型中途改用工具時 kiro-cli 會回顯工具參數（也是 JSON），
    取第一個會拿到工具參數而不是最終答案。

    用括號配對掃描而非正則 —— JSON 可以嵌套，正則抓不對。
    """
    cleaned = _strip_ansi(text)
    candidates: list[dict] = []
    depth = 0
    start = -1
    in_str = False
    escaped = False

    for i, ch in enumerate(cleaned):
        if in_str:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            if depth > 0:
                depth -= 1
                if depth == 0 and start >= 0:
                    try:
                        obj = json.loads(cleaned[start:i + 1])
                    except json.JSONDecodeError:
                        pass
                    else:
                        if isinstance(obj, dict):
                            candidates.append(obj)
                    start = -1

    return candidates[-1] if candidates else None


def build_plan_prompt(text: str, members_desc: str) -> str:
    """階段 1 的 prompt：要 leader 判斷自己做或拆給誰，並輸出 JSON。"""
    return f"""【團隊模式 — 規劃階段】
使用者選擇由你統籌。先判斷這件事該**自己做**還是**拆給成員**。

可派工的成員（只能用下列 id，不要自己發明）：
{members_desc}

⚠️ 本階段**只做規劃，不要動手做事、不要寫檔**。
最後**只輸出一段 JSON**（前後可以有說明文字，但 JSON 必須是最後一個）：

自己做得完 →
{{"mode": "self", "answer": "你的完整回答"}}

需要拆給成員 →
{{"mode": "delegate",
 "note": "你的拆解理由與整體規劃（一兩句）",
 "assignments": [{{"agent": "成員id", "task": "給他的具體任務描述"}}]}}

規則：
- 一個成員最多派一項，任務描述要能獨立看懂（成員看不到這段對話）
- 單一職能的事就 `self`，不要為了用團隊而硬拆
- 最多 3 項，超過請自己收斂優先序

---
使用者訊息：
{text}"""


def build_synthesis_prompt(text: str, note: str, results: list[tuple[str, str, str]]) -> str:
    """階段 3 的 prompt：把成員回覆交回 leader 收斂成一份答覆。"""
    blocks = []
    for aid, codename, reply in results:
        body = reply.strip() or "（無回應）"
        cap = _team_cfg().member_reply_cap
        if len(body) > cap:
            body = body[:cap] + "…（已截斷）"
        blocks.append(f"### {codename}（{aid}）\n{body}")

    joined = "\n\n".join(blocks)
    return f"""【團隊模式 — 收斂階段】
你剛才的規劃已經執行完，以下是各成員的實際回覆。
請整合成**一份給使用者看的答覆**。

⚠️ 規則：
- 結論先行，繁體中文
- 標明哪個結論來自誰（用代號，如「碼哥」）
- **成員之間有矛盾要明講**，不要挑一個當定論
- 不要重複貼成員原文，也不要新增他們沒說過的結論
- 不要輸出 JSON

你原本的規劃：{note or "（未提供）"}

使用者原始訊息：
{text}

---
成員回覆：
{joined}"""


async def _run_member(
    aid: str, task: str, *, session=None, timeout: int | None = None
) -> tuple[str, str, str]:
    """執行單一成員的任務，回傳 `(agent_id, 代號, 回覆)`。

    失敗與超時都回空字串而不是拋例外 —— 單一成員掛掉不該讓整個團隊流程中止。
    """
    from ark_bot_agent.agent.cli import AVAILABLE_AGENTS, agent_cli_chat

    codename = (AVAILABLE_AGENTS.get(aid) or {}).get("codename", aid)
    timeout = timeout if timeout is not None else _team_cfg().member_timeout
    try:
        res = await asyncio.wait_for(
            agent_cli_chat(task, agent_id=aid, session=session), timeout=timeout
        )
    except asyncio.TimeoutError:
        log.warning("team_flow: %s 超時（%ds）", aid, timeout)
        return aid, codename, ""
    except Exception as e:
        log.error("team_flow: %s 失敗：%s", aid, e)
        return aid, codename, ""
    if not res.is_ok():
        # [0.5.0] 先前一律回空字串 —— 看不出是逾時、崩潰、還是 agent 真的沒話說
        log.warning("team_flow: %s 無效回覆（%s, %dms）", aid, res.error, res.elapsed_ms)
    # partial 也照用 —— 部分結果比沒結果好
    return aid, codename, res.reply_text()


async def _gather_with_deadline(
    items: list[tuple[str, str]],
    *,
    session=None,
    on_progress: ProgressFn | None = None,
) -> tuple[list[tuple[str, str, str]], list[str]]:
    """平行執行成員任務，**到 deadline 就收已完成的**。

    回傳 `(有回覆的結果, 逾期未完成的代號)`。

    為什麼不用 `asyncio.gather`：它要等最慢的那個。
    實測三人派工時最慢者比最快者多花 86 秒，使用者全程看不到任何進展。
    這裡改成每完成一個就更新進度，到點未完成的直接放掉。
    """
    from ark_bot_agent.agent.cli import AVAILABLE_AGENTS

    cfg = _team_cfg()
    sem = asyncio.Semaphore(cfg.max_concurrency)

    async def _guarded(aid: str, task: str):
        async with sem:
            return await _run_member(aid, task, session=session)

    tasks = {
        asyncio.create_task(_guarded(aid, task)): aid
        for aid, task in items
    }
    total = len(tasks)
    done_names: list[str] = []
    results: list[tuple[str, str, str]] = []

    pending = set(tasks)
    loop = asyncio.get_running_loop()
    deadline = loop.time() + cfg.stage_deadline

    while pending:
        remaining = deadline - loop.time()
        if remaining <= 0:
            break
        done, pending = await asyncio.wait(
            pending, timeout=remaining, return_when=asyncio.FIRST_COMPLETED
        )
        if not done:  # 逾時
            break
        for t in done:
            aid, codename, reply = t.result()
            if reply.strip():
                results.append((aid, codename, reply))
                done_names.append(f"{codename} ✓")
            else:
                done_names.append(f"{codename} ✗")
            if on_progress:
                try:
                    waiting = total - len(done_names)
                    tail = f"　⏳ 還有 {waiting} 人" if waiting else ""
                    await on_progress("⚔️ " + "　".join(done_names) + tail)
                except Exception:
                    pass

    # 逾期的取消，避免留下孤兒任務
    late: list[str] = []
    for t in pending:
        aid = tasks[t]
        late.append((AVAILABLE_AGENTS.get(aid) or {}).get("codename", aid))
        t.cancel()
    if late:
        log.warning(
            "team_flow: %d 人未在 %ds 內完成，改用已完成的 %d 份收斂：%s",
            len(late), cfg.stage_deadline, len(results), "、".join(late),
        )

    return results, late


async def run_team_flow(
    text: str,
    *,
    session=None,
    leader_id: str = "leader",
    on_progress: ProgressFn | None = None,
) -> str | None:
    """跑完整的團隊流程，回傳要給使用者的文字（失敗回 None）。

    Args:
        text: 使用者原始訊息
        session: UserSession，供 `agent_cli_chat` 注入對話脈絡
        leader_id: 統籌者的 agent id
        on_progress: 進度回饋（每階段呼叫一次）

    Returns:
        最終答覆文字；leader 完全沒回應時為 None。

    **降級策略**：任何一步解析失敗都不會整個失敗 ——
    解析不出 JSON 就把 leader 的原文當答案回（它通常已經寫了有用的內容），
    成員全部無回應就退回 leader 的規劃說明。
    """
    from ark_bot_agent.agent.cli import agent_cli_chat, describe_agents, get_group_members

    async def _tick(msg: str) -> None:
        if on_progress:
            try:
                await on_progress(msg)
            except Exception:  # 進度顯示失敗不影響主流程
                pass

    members = get_group_members(leader_id)
    if not members:
        log.warning("team_flow: %s 沒有可派工成員，退回單一 agent 模式", leader_id)
        return (await agent_cli_chat(text, agent_id=leader_id, session=session)).reply_text()

    # ── 階段 1：規劃 ──
    await _tick("🎯 隊長規劃中⋯")
    _plan_res = await agent_cli_chat(
        build_plan_prompt(text, describe_agents(members)),
        agent_id=leader_id,
        session=session,
        # [R5] 規劃不需要對話歷史 —— prompt 已含任務與成員清單。
        #      `skip_resume: false` 的 leader 每次會 `--resume` 重播整段累積歷史，
        #      而且**不會因此省下冷啟**（每則訊息本來就 spawn 新 process）。
        fresh=True,
    )
    raw_plan = _plan_res.reply_text()
    if not raw_plan:
        # [0.5.0] 現在分得出「leader 沒回」與「leader 掛了」
        log.warning("team_flow: 規劃階段無結果 —— %s（retryable=%s）",
                    _plan_res.error or "空回覆", _plan_res.retryable)
        return None

    plan = extract_last_json(raw_plan)
    if not plan:
        # 沒吐 JSON —— 但它的文字通常已經是答案，直接回，不要讓使用者看到失敗
        log.info("team_flow: leader 未輸出 JSON，降級為直接回覆")
        return _strip_ansi(raw_plan)

    if plan.get("mode") == "self":
        answer = (plan.get("answer") or "").strip()
        return answer or _strip_ansi(raw_plan)

    # ── 階段 2：執行 ──
    raw_items = plan.get("assignments") or []
    # 只留白名單內的成員，且不重複派給同一人（模型偶爾會重複）
    seen: set[str] = set()
    items: list[tuple[str, str]] = []
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        aid = str(it.get("agent", "")).replace("-agent", "").strip()
        task = str(it.get("task", "")).strip()
        if not aid or not task or aid in seen or aid not in members:
            if aid and aid not in members:
                log.warning("team_flow: leader 想派給非成員 %s，已忽略", aid)
            continue
        seen.add(aid)
        items.append((aid, task))

    note = (plan.get("note") or "").strip()
    if not items:
        log.info("team_flow: 計畫沒有有效派工項，回傳規劃說明")
        return note or _strip_ansi(raw_plan)

    from ark_bot_agent.agent.cli import AVAILABLE_AGENTS
    names = "、".join(
        (AVAILABLE_AGENTS.get(a) or {}).get("codename", a) for a, _ in items
    )
    await _tick(f"⚔️ {names} 執行中⋯（{len(items)} 人）")

    answered, late = await _gather_with_deadline(
        items, session=session, on_progress=on_progress
    )

    if not answered:
        log.warning("team_flow: %d 個成員全部無回應", len(items))
        return (note + "\n\n⚠️ 成員都沒回應，任務未完成。") if note else None

    # 有人逾期時要**明講**，不然使用者不知道這份答覆是部分結果
    late_note = (
        f"\n\n⏳ {('、'.join(late))} 還沒回（超過 {_team_cfg().stage_deadline} 秒），"
        "以下是其他人的結果。"
        if late else ""
    )

    # 只有一個人回 → 省掉收斂那次呼叫，直接組裝
    if len(answered) == 1:
        _, codename, reply = answered[0]
        head = f"{note}\n\n" if note else ""
        return f"{head}**{codename}**：\n{reply.strip()}{late_note}"

    # ── 階段 3：收斂 ──
    await _tick("🎯 隊長彙整中⋯")
    _final_res = await agent_cli_chat(
        build_synthesis_prompt(text, note, answered),
        agent_id=leader_id,
        session=session,
    )
    final = _final_res.reply_text()
    if final:
        return await _maybe_verify(_strip_ansi(final), text, leader_id, session) + late_note

    # 收斂失敗 → 自己組裝，不要讓已完成的工作白費
    log.warning("team_flow: 收斂階段無回應，改為直接組裝")
    parts = [note] if note else []
    parts += [f"**{c}**：\n{r.strip()}" for _, c, r in answered]
    return "\n\n".join(parts) + late_note


# ── [R8] 選配 verify（預設關）───────────────────────────────

def build_verify_prompt(question: str, answer: str) -> str:
    """驗證階段的 prompt —— 只找問題，不重寫答案。"""
    return f"""【團隊模式 — 驗證階段】

原始問題：
{question}

團隊產出的答覆：
{answer}

請檢查這份答覆有沒有**明確的錯誤或重大遺漏**。

- 沒問題 → 只回一個字：OK
- 有問題 → 用 3 行以內列出，每行一個問題

⚠️ 不要重寫答覆、不要補充你的看法、不要客套。只找錯。"""


async def _maybe_verify(answer: str, question: str, leader_id: str, session=None) -> str:
    """收斂後的可選驗證。**預設關**，且失敗不影響已完成的協作。

    做成 hook 而非第四階段的理由：ninja 的 verify 綁 OpenAI `o4-mini`
    —— 那是**政策不是機制**。做成階段會讓不用它的人也吃到階段管理的複雜度。

    🔴 **verify 失敗不得讓整個 team flow 失敗**（AC-8.3）——
    已經做完的協作不該因為驗證這一步而白費。
    """
    cfg = _team_cfg()
    if not getattr(cfg, "verify", False):
        return answer

    from ark_bot_agent.agent.cli import agent_cli_chat

    try:
        res = await agent_cli_chat(
            build_verify_prompt(question, answer),
            agent_id=leader_id,
            session=session,
            fresh=True,                 # 驗證也不需要歷史
        )
    except Exception as e:              # noqa: BLE001
        log.error("verify 階段異常（照回原答覆）：%s", e)
        return answer

    verdict = _strip_ansi(res.reply_text()).strip()
    if not res.is_ok() or not verdict:
        log.warning("verify 無結果（照回原答覆）：%s", res.error)
        return answer
    if verdict.upper().startswith("OK") or len(verdict) < 4:
        return answer

    # 有意見就附在後面 —— **不改寫答覆本身**（驗證者不是作者）
    return f"{answer}\n\n---\n🔍 **驗證意見**\n{verdict[:600]}"
