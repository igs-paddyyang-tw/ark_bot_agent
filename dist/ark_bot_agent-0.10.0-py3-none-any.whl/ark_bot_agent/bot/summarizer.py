"""TG 回覆摘要提取器。

從 agent 長文回覆中提取 ≤ 200 字摘要，用於 TG 卡片式呈現。
完整內容另存 MD 報告。

規則：
1. [DONE] summary= 標記 → 直接用（最精確）
2. Verdict / 結論段落
3. 含數字的行（KPI/統計）
4. 「下一步」/「建議」行
5. 不含：程式碼 fence、表格、檔案路徑、frontmatter
"""
from __future__ import annotations

import re


def summarize(text: str, max_chars: int = 200) -> str:
    """從結構化回覆提取摘要。"""
    if not text or not text.strip():
        return ""

    # 策略 1：[DONE] summary= 標記
    done_match = re.search(r"\[DONE\]\s*summary=(.+)", text)
    if done_match:
        summary = done_match.group(1).strip()
        if len(summary) <= max_chars:
            return summary

    lines = text.splitlines()
    candidates: list[str] = []

    in_code_block = False
    in_frontmatter = False
    frontmatter_count = 0

    for line in lines:
        stripped = line.strip()

        # 跳過 frontmatter
        if stripped == "---":
            frontmatter_count += 1
            if frontmatter_count <= 2:
                in_frontmatter = not in_frontmatter
                continue
        if in_frontmatter:
            continue

        # 跳過程式碼區塊
        if stripped.startswith("```"):
            in_code_block = not in_code_block
            continue
        if in_code_block:
            continue

        # 跳過空行
        if not stripped:
            continue

        # 跳過表格行
        if stripped.startswith("|") and "|" in stripped[1:]:
            continue
        # 跳過表格分隔線
        if re.match(r"^\|[\s\-:]+\|", stripped):
            continue

        # 跳過檔案路徑
        if re.match(r"^[/~][\w/\-\.]+\.\w+$", stripped):
            continue
        if re.match(r"^(src|agents|docs|tests|knowledge|artifacts)/", stripped):
            continue

        # 跳過 markdown 標題裝飾（但保留標題內容）
        if stripped.startswith("#"):
            title_text = stripped.lstrip("# ").strip()
            # Verdict 標題內容有價值
            if any(kw in title_text.lower() for kw in ("verdict", "結論", "摘要", "summary")):
                continue  # 標題本身跳過，下一行是內容
            continue

        # 跳過 Output Marker
        if re.match(r"^\[(DONE|ARTIFACT|PROGRESS|FAIL)\]", stripped):
            continue

        # 跳過引用來源行
        if stripped.startswith("📚 參考") or stripped.startswith("---"):
            continue

        candidates.append(stripped)

    if not candidates:
        # fallback：取原文前 max_chars 字
        clean = re.sub(r"\s+", " ", text).strip()
        return clean[:max_chars]

    # 優先選取策略
    priority_lines: list[str] = []
    normal_lines: list[str] = []

    for line in candidates:
        # 高優先：含結論關鍵字
        if re.match(r"^\*\*\w+\*\*", line):  # **verdict** — xxx
            priority_lines.append(line)
        elif any(kw in line for kw in ("✅", "❌", "⚠️", "完成", "失敗", "結論")):
            priority_lines.append(line)
        # 高優先：含數字（統計/KPI）
        elif re.search(r"\d+[./]\d+|\d+%|\$\d+|v\d+\.\d+", line):
            priority_lines.append(line)
        # 中優先：下一步/建議
        elif any(kw in line for kw in ("下一步", "建議", "待", "需要")):
            priority_lines.append(line)
        else:
            normal_lines.append(line)

    # 組裝摘要：優先行 + 普通行（補滿字數）
    result_lines: list[str] = []
    char_count = 0

    for line in priority_lines + normal_lines:
        if char_count + len(line) + 1 > max_chars:
            break
        result_lines.append(line)
        char_count += len(line) + 1

    if not result_lines and candidates:
        # 至少取第一行
        result_lines = [candidates[0][:max_chars]]

    return "\n".join(result_lines)


def should_summarize(text: str) -> bool:
    """判斷是否需要摘要（> 200 字）。"""
    return len(text.strip()) > 200


def should_send_report(text: str) -> bool:
    """判斷是否需要發 HTML 報告（> 4000 字）。"""
    return len(text.strip()) > 4000
