"""分頁列表元件（[R9]，自 ninja-bot 搬入）。

純 UI 工具。頁碼超界會**校正到最後有效頁**而不是報錯 ——
使用者連點「下一頁」是常態，不該因此看到錯誤。
"""
from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

_SEPARATOR = "━━━━━━━━━━━━━━━"
_DEFAULT_PER_PAGE = 5
_NOOP_CALLBACK = "noop"


def paginate(
    items: list,
    page: int = 1,
    per_page: int = _DEFAULT_PER_PAGE,
) -> tuple[list, int, int]:
    """依頁碼切片項目列表。

    Args:
        items: 完整項目列表
        page: 欲取得頁碼（1-based，超界會校正到最後有效頁）
        per_page: 每頁筆數

    Returns:
        (當頁 items, total_pages, total_items)
    """
    total_items = len(items)
    total_pages = max(1, (total_items + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))

    start = (page - 1) * per_page
    end = start + per_page
    return items[start:end], total_pages, total_items


def render_paginated_list(
    title: str,
    items: list[str],
    page: int,
    total_pages: int,
    total_items: int,
    resource: str = "list",
) -> tuple[str, InlineKeyboardMarkup]:
    """渲染分頁列表卡片（文字 + Inline Keyboard）。

    Args:
        title: 列表標題
        items: 當頁項目（已格式化的 HTML 字串），逐行列出
        page: 當前頁碼（1-based）
        total_pages: 總頁數
        total_items: 總筆數
        resource: callback_data 前綴

    Returns:
        (html_text, keyboard)
    """
    page = max(1, min(page, total_pages))

    lines = [f"📋 <b>{title}</b>", _SEPARATOR]
    lines.extend(items if items else ["（無資料）"])
    lines.append("")
    lines.append(f"第 {page} / {total_pages} 頁・共 {total_items} 筆")

    text = "\n".join(lines)

    prev_data = f"{resource}:p:{page - 1}" if page > 1 else _NOOP_CALLBACK
    next_data = f"{resource}:p:{page + 1}" if page < total_pages else _NOOP_CALLBACK

    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("◀️ 上一頁", callback_data=prev_data),
                InlineKeyboardButton(f"{page}/{total_pages}", callback_data=_NOOP_CALLBACK),
                InlineKeyboardButton("下一頁 ▶️", callback_data=next_data),
            ]
        ]
    )

    return text, keyboard
